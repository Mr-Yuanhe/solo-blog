title: HTML学习2
date: '2019-09-17 00:28:13'
updated: '2019-09-17 00:51:52'
tags: [HTML]
permalink: /articles/2019/09/17/1568651293523.html
---
# 1、div和span

- 元素分类

```
块级元素
行内元素
```

```
div 属于块级元素
span 属于行内元素
```

- w3c中的定义

```
<div> 定义文档中的节。 
<span> 定义文档中的节。 
把div和span都理解为是容器（盒子），其他东西（标签、内容）都可以放在容器中
```

- 注意点

```html
1、可以用<div>来实现换行，<br>是文字与文字换行
2、标签必须正确嵌套，行内元素不能够放块级元素，标题和段落不能混合使用
3、<div>中可以存放任意元素，<span>中只能放行内元素
```

# 2、html中的表格相关标签

- 基本标签

```
<table> 定义表格。
<thead> 定义表格中的表头内容。
<tr> 定义表格中的行。
<th> 定义表格中的表头单元格。
<tbody> 定义表格中的主体内容。 
<td> 定义表格中的数据单元格。 table data
<caption> 定义表格标题。
```

```html
<!-- <table> 定义表格。 -->
<!-- 属性border="1"，表示表示表格边框的宽度为1px -->
<table border="1">
  <!--<caption> 定义表格标题。 -->
  <caption>二阶段学生考试成绩</caption>
  <!-- <thead> 定义表格中的表头内容。  -->
  <thead>
    <!-- <tr> 定义表格中的行。  -->
    <tr>
      <!-- <th> 定义表格中的表头单元格。  -->
      <th>学号</th>
      <th>姓名</th>
      <th>性别</th>
      <th>考试成绩</th>
      <th>项目</th>
    </tr>
  </thead>
  <!-- <tbody> 定义表格中的主体内容。  -->
  <tbody>
    <tr>
      <!-- <td> 定义表格中的数据单元格。 table data -->
      <td>1001</td>
      <td>张三</td>
      <td>男</td>
      <td>80</td>
      <td>80</td>
    </tr>
  </tbody>
</table>
```

- 表格中的属性

```
border	规定表格边框的宽度。 
width 	规定表格的宽度。值有两个写法，一种是数值表示像素，还有一种是百分比表示占据父容器宽度
algin	规定表格相对周围元素的水平对齐方式。值：left、center、right
cellpadding 规定单元边沿与其内容之间的空白。 内边距
cellspacing 规定单元格与单元格之间的空白。 
# 重要的两个属性（单元格的属性）
colspan		列合并		
rowspan 	行合并
```

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
      /*让所有的td元素中的文本居中*/
      td{
        text-align: center;
      }
    </style>
  </head>
  <body>
    <!-- <table> 定义表格。 -->
    <!-- 属性border="1"，表示表示表格边框的宽度为1px -->
    <table border="1" width="30%" align="center" cellpadding="10" cellspacing="0">
      <!--<caption> 定义表格标题。 -->
      <caption>二阶段学生考试成绩</caption>
      <!-- <thead> 定义表格中的表头内容。  -->
      <thead>
        <!-- <tr> 定义表格中的行。  -->
        <tr>
          <!-- <th> 定义表格中的表头单元格。  -->
          <th>学号</th>
          <th>姓名</th>
          <th>性别</th>
          <th>考试成绩</th>
          <th>项目</th>
        </tr>
      </thead>
      <!-- <tbody> 定义表格中的主体内容。  -->
      <tbody>
        <tr>
          <!-- <td> 定义表格中的数据单元格。 table data -->
          <td>1001</td>
          <td>张三</td>
          <td>男</td>
          <td colspan="2">80</td>
          <!--<td>80</td>-->
        </tr>
        <tr>
          <td>1002</td>
          <td>李四</td>
          <td>女</td>
          <td>72</td>
          <td>98</td>
        </tr>
        <tr>
          <td>1003</td>
          <td>王五</td>
          <td rowspan="3">男</td>
          <td>75</td>
          <td>95</td>
        </tr>

        <tr>
          <td>1004</td>
          <td>赵六</td>
          <!--<td>男</td>-->
          <td>80</td>
          <td>90</td>
        </tr>
        <tr>
          <td>1005</td>
          <td>刘二狗</td>
          <!--<td>男</td>-->
          <td>59</td>
          <td>58</td>
        </tr>
      </tbody>
    </table>
  </body>
</html>
```

# 3、html中内联框架标签

- 可以在一个页面中嵌套一个页面
- 基于标签

```
<iframe>
```

- 基本语法

```
<iframe src="URL"></iframe>
```

- 属性

```
src		规定在 iframe 中显示的文档的 URL。 
width		定义 iframe 的宽度。 
frameborder	规定是否显示框架周围的边框。 值：1、0
```

```html
<body>
  <h1>iframe标签学习</h1>
  <iframe src="./success.html" width="100%" frameborder="0"></iframe>
</body>
```

- 使用内联框架实现某和网站基本布局

```html
<head>
  <style>
    *{
      padding: 0;
      margin: 0;
    }
    #header{
      height: 120px;
      text-align: center;
      line-height: 120px;
      font-size: 70px;
      background: yellowgreen;
    }
    #nav{
      background: deepskyblue;
      height: 700px;
      width: 200px;
      line-height: 40px;
      text-align: center;
      float: left;
    }
    #content{
      margin-left: 200px;
      height: 700px;
      background: pink;
    }
    #footer{
      background: purple;
      height: 50px;
    }
  </style>
</head>
<body>
  <div>
    <div id="header">某某某企业欢迎大佬光临~</div>
    <div id="nav">
      <ul type="none">
        <li><a href="./info.html" target="myFrame">公司简介</a></li>
        <li><a href="./course.html" target="myFrame">课程介绍</a></li>
        <li><a href="#">就业喜报</a></li>
        <li><a href="./company.html" target="myFrame">合作企业</a></li>
      </ul>
    </div>
    <div id="content">
      <iframe name="myFrame" src="./info.html" width="100%" height="100%" frameborder="0" ></iframe>
    </div>
    <div id="footer"></div>
  </div>
</body>
```

# 4、表单相关的标签

- 表单的作用

```
提交数据（把数据提交给另一个页面，或者服务器中）
```

- 具体的实际功能

```
登录，注册...
```

- 登录表单案例

```html
<!--<form>:表单标签-->
<form>
  <div>
    <!--<label> 定义 input 元素的标注。 -->
    <label>用户名</label>
    <!-- input叫控件，如果input的type属性值为text,则为文本输入框 -->
    <input type="text" >
  </div>
  <div>
    <label>密码</label>
    <!--如果input的type属性值为password,则为密码输入框-->
    <input type="password">
  </div>
  <div>
    <!--如果input的type属性值为submit,则为提交按钮，value属性的值就是input控件的默认值-->
    <input type="submit" value="登录">
  </div>
</form>
```

- 表单中先关的属性

```
# form标签中的属性
action="url": 设置表单的提交路径。
method="get/post":设置表单的提交方式。
# input控件中的属性
type="text/button/checkbox/file/hidden/password/radio/submit":规定 input 元素的类型。
name="field_name"：这个属性对于控件是必填的，如果不填，服务器获取不到数据 
```

```html
<form action="success.html" method="get">
  <div>
    <!--<label> 定义 input 元素的标注。 -->
    <label>用户名</label>
    <!-- input叫控件，如果input的type属性值为text,则为文本输入框 -->
    <input type="text" name="username">
  </div>
  <div>
    <label>密码</label>
    <!--如果input的type属性值为password,则为密码输入框-->
    <input type="password" name="pwd">
  </div>
  <div>
    <!--如果input的type属性值为submit,则为提交按钮，value属性的值就是input控件的默认值-->
    <input type="submit" value="登录">
  </div>
</form>
```

- http提交数据的方式有2种

```
get提交和post提交
```

- 两者有什么区别

|          | GET                                      | POST                                     |
| -------- | ---------------------------------------- | ---------------------------------------- |
| 后退按钮/刷新  | 无害                                       | 数据会被重新提交（浏览器应该告知用户数据会被重新提交）。             |
| 书签       | 可收藏为书签                                   | 不可收藏为书签                                  |
| 缓存       | 能被缓存                                     | 不能缓存                                     |
| 编码类型     | application/x-www-form-urlencoded        | application/x-www-form-urlencoded 或 multipart/form-data。为二进制数据使用多重编码。 |
| 历史       | 参数保留在浏览器历史中。                             | 参数不会保存在浏览器历史中。                           |
| 对数据长度的限制 | 是的。当发送数据时，GET 方法向 URL 添加数据；URL 的长度是受限制的（URL 的最大长度是 2048 个字符）。2KB | 无限制。                                     |
| 对数据类型的限制 | 只允许 ASCII 字符。                            | 没有限制。也允许二进制数据。                           |
| 安全性      | 与 POST 相比，GET 的安全性较差，因为所发送的数据是 URL 的一部分。在发送密码或其他敏感信息时绝不要使用 GET ！ | POST 比 GET 更安全，因为参数不会被保存在浏览器历史或 web 服务器日志中。 |
| 可见性      | 数据在 URL 中对所有人都是可见的。                      | 数据不会显示在 URL 中。                           |

- 注册表单案例

```
type="text/button/checkbox/file/hidden/password/radio/submit":规定 input 元素的类型。
```

```html
<form action="success.html" method="get">
  <div>
    <label>手机号码</label>
    <input type="text" name="phone">
  </div>
  <div>
    <label>密码</label>
    <input type="password" name="pwd">
  </div>
  <div>
    <label>确认密码</label>
    <input type="password" name="rePwd">
  </div>
  <div>
    <label>性别</label>
    <!--单选按钮-->
    <!--checked="checked"表示默认选中-->
    <input type="radio" name="gender" value="0">女
    <input type="radio" name="gender" value="1" checked="checked">男
  </div>
  <div>
    <label>爱好</label>
    <!--复选框-->
    <input type="checkbox" name="hobby" value="eat"> 吃
    <input type="checkbox" name="hobby" value="drink" checked="checked"> 喝
    <input type="checkbox" name="hobby" value="sleep" checked="checked"> 睡
  </div>

  <div>
    <label>地址</label>
    <!--下拉框-->
    <select name="address">
      <option value="0">---请选择一个地址---</option>
      <option value="025">江苏南京</option>
      <option value="0514">江苏扬州</option>
      <option value="0101">安徽合肥</option>
      <option value="110">广东东莞</option>
    </select>
  </div>
  <div>
    <label>个人说明</label>
    <!--文本域-->
    <textarea name="info"></textarea>
  </div>
  <div>
    <!--隐藏框-->
    <input type="hidden" name="userId"  value="10086">
  </div>
  <div>
    <label>头像</label>
    <!--文件操作控件-->
    <input type="file" name="phone">
  </div>
  <div>
    <!--提交按钮-->
    <input type="submit" value="修改1">
    <!--普通按钮，不能提交表单-->
    <input type="button" value="修改2">
  </div>
</form>
```

# 5、html5新特性

- 新特性有哪些

```
用于绘画的 canvas 元素 
用于媒介回放的 video 和 audio 元素 
对本地离线存储的更好的支持 
新的特殊内容元素，比如 article、footer、header、nav、section 
新的表单控件，比如 calendar、date、time、email、url、search 
```

# 6、canvas 元素

- 元素就是标签

```
canvas中文意思：画布（通过js来实现画布操作）
```

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
      canvas{
        background: yellowgreen;
      }
    </style>
  </head>
  <body>
    <canvas>该浏览器不支持html5新特性</canvas>
  </body>
</html>
```

#7、多媒体标签

- 有哪些

```
video：视频
audio：音频
```

- 目的

```
用来代替flash
```

- 视频的基本语法

```
<video src="url"></video>
<audio src="url"></audio>
```

```html
<!--controls controls 如果出现该属性，则向用户显示控件，比如播放按钮。 -->
<!--autoplay autoplay 如果出现该属性，则视频在就绪后马上播放。 -->
<!--loop loop 如果出现该属性，则当媒介文件完成播放后再次开始播放。 -->
<!--注意点：controls="controls"可以简写（只要是值和属性名一样，都可以简写一个属性名）-->
<video src="./media/fun.mp4" controls autoplay loop></video>
<audio src="./media/music.mp3" controls></audio>
```

# 8、web 存储

- web存储对象有两个

````
localStorage - 没有时间限制的数据存储 
sessionStorage - 针对一个 session 的数据存储
````

# 9、H5新的特殊内容元素

- 又称为：结构化元素


- 有哪些

```
 article、footer、header、nav、section....
```

- 这些标签的功能与div的功能一模一样
- 特殊作用

```
方便码农阅读代码
```

```html
<head>
  <style>
    *{
      padding: 0;
      margin: 0;
    }
    header{
      height: 120px;
      text-align: center;
      line-height: 120px;
      font-size: 70px;
      background: yellowgreen;
    }
    nav{
      background: deepskyblue;
      height: 700px;
      width: 200px;
      line-height: 40px;
      text-align: center;
      float: left;
    }
    article{
      margin-left: 200px;
      height: 700px;
      background: pink;
    }
    footer{
      background: purple;
      height: 50px;
    }
  </style>
</head>
<body>
  <div>
    <header></header>
    <nav></nav>
    <article></article>
    <footer></footer>
  </div>
</body>
```

# 10、H5新的表单控件

- 控件新类型

```
email	邮箱控件
url	网页控件
number	数字控件
range	范围控件
search	search控件
color 	颜色控件
时间控件 date、datetime-local、mouth、week
```

```html
<form action="success.html">
  <div>
    <label>邮箱</label>
    <!--email控件-->
    <input type="email" name="email">
  </div>
  <div>
    <label>网址</label>
    <!--url控件-->
    <input type="url" name="url">
  </div>
  <div>
    <label>年龄</label>
    <!--number控件-->
    <input type="number" name="age">
  </div>

  <div>
    <label>范围</label>
    <!--number控件-->
    <input type="range" name="range">
  </div>
  <div>
    <label>搜索</label>
    <!--search控件-->
    <input type="search" name="search">
  </div>
  <div>
    <label>颜色</label>
    <!--color控件-->
    <input type="color" name="color">
  </div>
  <div>
    <label>时间</label>
    <!--时间控件-->
    <input type="date" name="time1">
    <input type="datetime-local" name="time2">
    <input type="month" name="time3">
    <input type="week" name="time4">
  </div>
  <div>
    <input type="submit" value="提交数据">
  </div>
</form>
```

- 表单中新增的新属性

```
checked		表示单选按钮和复选框默认选中
selected	表示下拉框默认选中
disable		表示该控件禁用
readonly	表示只读，不可编辑
```

```
required 	表示必填
placeholder	属性提供一种提示（hint），描述输入域所期待的值
autofocus	表示自动获得焦点
min		表示最小值
max		表示最大值
step		表示步长
multiple	表示多个，一般用于下拉框
pattern 	表示希望的值匹配该模式所对应的的正则表达式
autocomplete表示自动h写入（该属性的值：on、off）
```

- 手机号码正则表达式

```
^1[3|4|5|7|8|9]\d{9}$
```

```html
<form action="success.html" method="get" autocomplete="off">
  <div>
    <label>手机号码</label>
    <input type="text" name="phone" placeholder="请输入一个正确的手机号码" pattern="^1[3|4|5|7|8|9]\d{9}$" autocomplete="on">
  </div>
  <div>
    <label>密码</label>
    <input type="password" name="pwd" required autofocus>
  </div>
  <div>
    <label>年龄</label>
    <input type="number" name="age" max="180" min="0" step="2">
  </div>
  <div>
    <label>性别</label>
    <!--checked="checked"表示默认选中，可以简写checked-->
    <input type="radio" name="gender" value="0">女
    <input type="radio" name="gender" value="1" checked>男
  </div>
  <div>
    <label>地址</label>
    <select name="address" multiple>
      <option value="0">---请选择一个地址---</option>
      <option value="025">江苏南京</option>
      <option value="0514" selected>江苏扬州</option>
      <option value="0101">安徽合肥</option>
      <option value="110">广东东莞</option>
    </select>
  </div>
  <div>
    <input type="submit" value="提交数据">
  </div>
</form>
```

# 11、html中的布局

- 目前对你们而言，布局只有两种方式

```
table布局
div布局（div+css布局）
```

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
        label{
            display: inline-block;
            width: 48px;
        }
    </style>

</head>
<body>
    <h1>div布局</h1>
    <form action="success.html" method="get">
        <div>
            <label>用户名</label>
            <input type="text" name="username">
        </div>
        <div>
            <label>密码</label>
            <input type="password" name="pwd">
        </div>
        <div>
            <input type="submit" value="登录">
        </div>
    </form>
  
    <hr>
  
    <h1>table布局</h1>
    <form action="success.html" method="get">
        <table>
            <tr>
                <td><label>用户名</label></td>
                <td><input type="text" name="username"></td>
            </tr>
            <tr>
                <td><label>密码</label></td>
                <td><input type="password" name="pwd"></td>
            </tr>
            <tr>
                <td colspan="2"><input type="submit" value="登录"></td>
            </tr>
        </table>
    </form>
</body>
</html>
```

- 注意点

```
1、目前只有极少数企业使用table布局,主流是div+css布局
2、table布局不符合w3c规范
3、table布局会存在bug,有的浏览器会自动给table渲染的时候添加一个tbody标签，导致dom操作异常
```
















