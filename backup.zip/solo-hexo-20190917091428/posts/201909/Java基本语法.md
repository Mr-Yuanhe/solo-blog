title: Java基本语法
date: '2019-09-15 15:06:28'
updated: '2019-09-15 15:08:50'
tags: [Java]
permalink: /articles/2019/09/15/1568531187918.html
---
# 基本语法

# 1. 工欲善其事必先利其器

- java开发工具
  - 记事本
  - editplus
  	 eclipse		开源免费,小巧，推荐使用eclipse
  - myeclipse       第三方公司在eclipse基础上，加入N多插件，使用功能更强大， 臃肿型，问题收费，价格不菲（2000台/年）  
  - intellij idea     收费的     后来者居上，前后端协同开发

# 2. 下载eclipse

[下载地址:](https://www.eclipse.org/downloads/packages/) 

选择相应的版本



![1.jpg](https://img.hacpai.com/file/2019/09/1-fcd34296.jpg)


再次选择jee版本，然后点击下载

![2.jpg](https://img.hacpai.com/file/2019/09/2-9db4be87.jpg)


# 3. 使用Eclipse改写HellWorld.java

3.1. 安装配置 

- Eclipse是绿色版本（压缩版），不需要安装，需要解压一下,即为安装


-  把（eclipse.exe）快捷方式发送到桌面，双击打开
- 第一次打开的时候会让我选择一个工作空间，工作空间即为所有项目的父目录，我们可以选一个工作空间，然后点记住我的选择，后面就不需要每次都提醒了
- 如果以后要修改工作空间，可以在File-->Switch workspace进行手动切换

 3.2. 切换成Java视图

- 在右上角的田字格（Open perspective-->java）

 3.3. 修改工作空间的编码

- window-->preferences-->general-->workspace-->Text file encoding-->GBK改成(UTF-8)

 3.4. 查看工作空间的jdk

- window-->preferences-->java -->installed JREs-->查看jdk版本（我们安装jdk的根目录）

 3.5. 创建一个Java Project

- src新建一个HelloWorld.java

-  开始编码

  ```java
  public class HelloWorld {
  	public static void main(String[] args) {
  		System.out.println("Hello World");
  	}
  }
  ```

- 运行

  - 文件--》右击--》run as -->java application
  - ctrl+F11  运行
  - f11 调试

 3.6. 修改字体 

- window-->preferences-->general-->appearance-->Color and fonts-->Basic-->text font-->edit-->16

# 4. 安装SVN插件

 4.1. 介绍

- SVN是一个开放源代码的版本控制系统
  - 一个项目分成N多模块，用N多人开发，最终应该合并一个项目源码
  - 我们在每一台自己的PC机中写部分模块代码，写完后提交代码至SVN服务器上，合并成一个项目源码

 4.2. 安装两种方式

- 本地安装	help-->install new software -->add-->name:(写名称svn)  | location:(选择site-1.8.18.zip路径)-->勾选两个选项 +取消联网更新--》下一步下一步的方式进行安装 -->eclipse需要重启
- 在线安装  help--> EclipseMarket space-->svn-->subclipse-->安装

 4.3. 两个场景 

- 如何把自己的项目在另一台电脑上打开
  - 把项目拷贝到另一台电脑中的目录中， 一般会放置在工作空间中
  - file-->import-->general-->existing projects into workspace-->选择项目名
- 如何打开老师的项目(提交到SVN服务器上)
  - file-->import-->svn-->从svn检出项目-->选择对应的项目根目录--》finish

# 5. 数据类型 

扫盲：计算机中的度量单位

bit      位             

byte  1字节=8位

kb    1k=1024byte

mb    兆    1m=1024k

g   	1g=1024m

t	1t=1024g

 5.1. 值类型

- 数值类型  (8个值类型)

  - 整数类型
    - byte		字节                       1字节     -128~127
    - short               短整型                   2字节  
    - int                   整型                        4字节
    - long                长整型                    8字节
  - 浮点类型
    - float                单精度浮点型         4字节  
    - double           双精度浮点型          8字节
    - 单精度和双精度的后面都加写上N多位数(随便有多少位小数)
    - 单精度有效位是6位
    - 双精度有效位是14位

- 非数值类型

  - 布尔值
    - boolean           true|false          1字节
  - 字符值
    - char                 'x'                         2字节

- 字符类型详解

  - 四种值类型

    - 字符
    - unicode编码
    - 数值(ASCII码值)
    - 转义字符(\打头)
      - 转义字符
        * `\\`   \
        	 \"	"
        	 \'	'
        	 \n 	换行
        	  \r	回车
         * \t   制表符  -> 整体占8个空格，如果前面是8位，\t独自占8位,如果前面超过8位，8位后整体占8位。

   - 示例

     ```java
     // 字符类型，在java采用的是unicode编码，占2个字节
     		char ch ='a';
     		char ch2 = '\u0000'; //空
     		char ch3 = 97; // 找ASCII码表  97 --》'a'   65--》'a'  48-->'0' 
     		/*
     		 * 转义字符
     		 * \\   \
     		 * \"	"
     		 * \'	'
     		 * \n 	换行
     		 * \r	回车
     		 * \t   制表符  -》整体占8个空格，如果前面是8位，\t独自占8位,如果前面超过8位，8位后整体占8位。
     		 * */
     		char ch4 = '\\';
     		String str ="123456789\t2";
     ```

     ​

 5.2. 引用类型

- 常见有: 类、数组、接口等...

# 6. 关键字和保留字

 6.1. 关键字: 

- 在现在的java程序中有着特殊意义的单词，比如public 、 static、 void ,一般全为小写
 6.2. 保留字:

- 在java保留这个单词，但在目前版本中尚未起使用，比如：const

 6.3. 常用的关键字

| [abstract](http://baike.baidu.com/item/abstract)     | [assert](http://baike.baidu.com/item/assert)             | [boolean](http://baike.baidu.com/item/boolean)     | break                                                | [byte](http://baike.baidu.com/item/byte)     |
| ---------------------------------------------------- | -------------------------------------------------------- | -------------------------------------------------- | ---------------------------------------------------- | -------------------------------------------- |
| case                                                 | [catch](http://baike.baidu.com/item/catch)               | [char](http://baike.baidu.com/item/char)           | [class](http://baike.baidu.com/item/class)           | const                                        |
| continue                                             | [default](http://baike.baidu.com/item/default)           | [do](http://baike.baidu.com/item/do)               | [double](http://baike.baidu.com/item/double)         | [else](http://baike.baidu.com/item/else)     |
| [enum](http://baike.baidu.com/item/enum)             | [extends](http://baike.baidu.com/item/extends)           | [final](http://baike.baidu.com/item/final)         | [finally](http://baike.baidu.com/item/finally)       | float                                        |
| [for](http://baike.baidu.com/item/for)               | goto                                                     | [if](http://baike.baidu.com/item/if)               | [implements](http://baike.baidu.com/item/implements) | import                                       |
| [instanceof](http://baike.baidu.com/item/instanceof) | [int](http://baike.baidu.com/item/int)                   | [interface](http://baike.baidu.com/item/interface) | long                                                 | native                                       |
| new                                                  | [package](http://baike.baidu.com/item/package)           | [private](http://baike.baidu.com/item/private)     | [protected](http://baike.baidu.com/item/protected)   | public                                       |
| [return](http://baike.baidu.com/item/return)         | [strictfp](http://baike.baidu.com/item/strictfp)         | [short](http://baike.baidu.com/item/short)         | [static](http://baike.baidu.com/item/static)         | [super](http://baike.baidu.com/item/super)   |
| [switch](http://baike.baidu.com/item/switch)         | [synchronized](http://baike.baidu.com/item/synchronized) | [this](http://baike.baidu.com/item/this)           | [throw](http://baike.baidu.com/item/throw)           | [throws](http://baike.baidu.com/item/throws) |
| [transient](http://baike.baidu.com/item/transient)   | try                                                      | [void](http://baike.baidu.com/item/void)           | [volatile](http://baike.baidu.com/item/volatile)     | while                                        |

6.3. 标识符:取名称的地方

 6.3.1 规则

- 只能包含数字、字母、下划线和美元符
- 开头只能包含字母、下划线和美元符
- 区分大小写
- 不能是java的关键字和保留字

 6.3.2 约定俗成

- 类名:帕斯卡命名【首字母大写，后面每个单词的首字母大写，其余的全是小写】HelloWorld
- 方法名和变量名: 驼峰命名 【首字母小写，后面每个单词的首字母大写，其余的全是小写】 showScore( )  
- 见名识义

# 7. 变量
 7.1. 语法

- 定义：不断变化的量称为变量，变量在内容中占有一个储存空间。（栈）
- 语法一：  先声明再赋值
  - 数据类型  变量名;
  - 变量名=值;
- 语法二: 声明时同时赋值
  - 数据类型 变量名=值;

 7.2. 示例

```java

/**
 * 变量的语法
 * 	数据类型 变量名=值;
 * 
 * @author think
 *
 */
public class VarDemo {

	public static void main(String[] args) {
		//定义变量
		byte b = 10;
		short s = 10;
		int i = 10;
		long l=10L;
		
		float f = 10.5F;
		double d = 10.5D;
		
		boolean bl = true;
		// 字符类型，在java采用的是unicode编码，占2个字节
		char ch ='a';
		char ch2 = '\u0000'; //空
		char ch3 = 97; // 找ASCII码表  97 --》'a'   65--》'a'  48-->'0' 
		/*
		 * 转义字符
		 * \\   \
		 * \"	"
		 * \'	'
		 * \n 	换行
		 * \r	回车
		 * \t   制表符  -》整体占8个空格，如果前面是8位，\t独自占8位,如果前面超过8位，8位后整体占8位。
		 * */
		char ch4 = '\\';
		
		String str ="123456789\t2";
		
		System.out.println("b="+b);
		System.out.println("s="+s);
		System.out.println("i="+i);
		System.out.println("l="+l);
		System.out.println("f="+f);
		System.out.println("d="+d);
		System.out.println("bl="+bl);
		System.out.println("ch="+ch);
		System.out.println("ch2="+ch2);
		System.out.println("ch3="+ch3);
		System.out.println("ch4="+ch4);
		System.out.println("123456789abcdefg");
		System.out.println(str);	
	}
}
```

 7.3. 注意事项

- 看到10就是int类型，看到10.5就是是double类型，但如果赋值给byte或short类开，会先判断是否在其值范围内，如果在则变成对应的类型。如果不在其范围，仍然是int类型
- 有三种类可以加上额外描述
  - long
    - 10 int
    - 10L   long
  - float
    - 10.5  double
    - 10.5F  float 
  - double
    - 10.5  double
    - 10.5D  double
- 变量在使用之前需要初始化

 7.4. 变量类型转换

- 自动转换(隐式转换)，下面情况满意任一种即可
  - 范围小的赋值给范围大的
  - 精度低的赋值给精度高的
  - char 和 int
- 强制转换（显式转换）==> (要转换的类型)值
  - 范围大的赋值给范围小的
  - 精度高的赋值给精度低的

# 8. 包

- 作用:
  - 避免命名冲突
  - 使代码具有条理性
- 语法:
  - 打包:  
    - 语法 : package 包名1.包名2;
    - 打包的语句必须在源码的最上面
    - 包在物理目录中对应的就是目录和子目录
  - 导包中的类:
    - 语法 :
      -  import 包名1.包名2.类1;
      -  import 包名1.包名2.*;
      - 导懈的语句必须在源码的最上面，但要放置在打包的语句下面
- 注:
  - 包名一般为公司域名的倒写+模块名
  - 包名为全小写

# 9. 运算符

 9.1. 算术运算符

- 一元 

  - ++ 自增
  - -- 自减
  - 注：
    - ++在前先自加再运算，++在后先运算再自加
    - --  在前先自减再运算，   --在后先运算再自减

- 二元

  - / 	*	 %(模)
  - `+     -`

- 算术运算符的结果只有四种类型 int long float double

  - 看到double一定是double类型
  - 否则看到float一定是float类型
  - 否则看到long一定是long类型
  - 否则为int类型

  ```java
  byte+byte-->int类型
  byte+short-->int类型
  byte+int-->int类型
  int+float-->float类型
  long+float--> float类型
  int+double-->double类型

  ```

- 示例

  ```java
  /**
  	一元
  */
  public static void main(String[] args) {
  		int i = 10;
  		i++;
  		++i;
  		System.out.println(i); //12
  		
  		int j=10;
  		j--;
  		--j;
  		System.out.println(j); //8
  		
  		
  		int sum=0;
  		i=5;
  		//    5      7
  		sum = i++ + ++i; //12
  		System.out.println(sum);
  		
  		i=5;
  		//    6     6      7    9 
  		sum = ++i + i++ + i++ + ++i; //28
  		System.out.println(sum);
  		
  		i=5;j=6;
  		//   6      6      5     5
  		sum= ++i + i++  - --j - j--;
  		System.out.println(sum);
  	}
  ```

  ```java
  /**
  二元运算符
  */
  public static void main(String[] args) {
  		// * / %
  		System.out.println(2*5); //10
  		System.out.println(2/4); //0
  		System.out.println(2%5); //2
  		
  		//+ - 
  		System.out.println(2+5); //7
  		System.out.println(2-5); //-3
  		
  		byte b1 = 1;
  		byte b2 = 2;
  		byte res = (byte) (b1+b2);
  	}
  ```

  ​

 9.2. 关系运算符，返回是一个boolean值

- 六种

```java
> 	>= 	< 	<=
== !=
```

- 示例

```java
public static void main(String[] args) {
		System.out.println(5>2); //true
		System.out.println(5>=2); //true
		System.out.println(5<2); //false
		System.out.println(5<=2); //false
		System.out.println(5==2); //false
		System.out.println(5!=2); //true
	}
```

 9.3. 逻辑运算符

- 三种

```java
!   
&&   逻辑与（短路与  前假后短路）    同真为真
||   逻辑或 （短路或 前真后短路）    同假为假
```

- 示例

```java
public static void main(String[] args) {
		//! 非
		System.out.println(!true);//false
		System.out.println(!(5>3));//false
		//&& 逻辑与(短路与)  同真为真
		System.out.println(true && true);//true
		System.out.println(true && false);//false
		//|| 逻辑或(短路或)  同假为假
		System.out.println(true || false);//true
		System.out.println(false || false);//false
		
		int i=5;
		if(false && ++i>0) {
			System.out.println("真真");
		}
		if(true || ++i>0) {
			System.out.println("真真");
		}
		System.out.println(i);
		
	}
```



 9.4. 赋值运算符

- 赋值和复合赋值

```java
=
*= /= %=
+= -=    
```

- 注:
  - 它是从右往左运算的
  - 赋值会覆盖之前的值
- 示例:

```java
public static void main(String[] args) {
		
		//赋值
		int i=10;
		
		//复合赋值
		i+=2; //可以理解成i = i+2;
		System.out.println(i);
		
		byte b = 5;
		b+=2;
		System.out.println(b);
		
		/*byte c =5;
		byte d =2;
		c=(byte) (c+d);*/
	}
```

 9.5. 位运算符

- 进制转换

  - 二进制  0~1
  - 十进制 0~9
  - 八进制 0~7
  - 十六进制 0~9A~F

  ```java
  10进制--》2进制(辗除法)
  10(10) --->?(2)
  ```

![6.png](https://img.hacpai.com/file/2019/09/6-ee4eeb94.png)



- 位运算

```java
&   位与 同1为1
|   位或 同0为0
~   取反 所有位取反
^   异或 相同为0
>> 有符号右移   符号位不变，右边溢出，左边补的是符号位
>>> 无符号右移
<< 有符号左移
```

- 运算规则
  - 左边第一个数为符号位，0表示正数，1表示负数
  - 运算都是以补码进行运算的
  - 正数的原反补，三码合一
  - 负数原码( 即原始二进制 )
  - 负数反码=>符号位不变，其它位取反
  - 负数补码：负数反码+1

```java
public static void main(String[] args) {
		System.out.println(true&true); //true
		System.out.println(false&true); //true
		System.out.println(3&5); //1
		System.out.println(3|5); //7
		System.out.println(~3); //-4
		System.out.println(3^5); //6
		System.out.println(-1>>2); //-1
		System.out.println(-1>>>2); //1073741823
		System.out.println(-1<<2); //-4
		
		System.out.println(8>>2);//2
		System.out.println(2<<2);//8
		
	}
```

- 图解

 ![7.png](https://img.hacpai.com/file/2019/09/7-03c23f79.png)


 9.6. 三元运算符

- 语法：条件?值1:值2
- 说明：条件为真返回值1，条件为假返回值2
- 示例

```java
char ch = 5>22?'a':'b';
System.out.println(ch);
```

 9.7. 运算符的优先级

- （）
- 一元: ++ -- !
- 算术
  - % / *
  - `+ -`
- 关系
  - < <= > >=
  - ==  !=
- 逻辑
  - &&
  - ||
- 赋值
  - =
- 示例

```java
// 能被400整数或能被4整数但不能被100整除
int year = 2008;
if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0)) {
    System.out.println("闰年");
}
```

# 10. 流程控制

 10.1. 默认流程

- java程序执行是找到程序入口 ，即main方法，main方法执行结束，则程序结束
- 大方向:从上而下，从左至右。赋值运算除外

10.2. 分支结构

 10.2.1. if结构

- 简单if结构

  - 语法

  ```java
  if(条件){
      语句块;
  }
  ```

  - 解读

    - 当条件为真时，执行if里的语句块，否则不执行

    - 注：当if后只有一条语句的时候，{}是可以省略的， 一般不省略

      ```java
      if(false)
      			System.out.println("aaa"); //不会打印
      			System.out.println("bbb"); //会打印，此语句不属性if
      ```

  - 示例

  ```java
  //创建一个Scanner对象
  Scanner input = new Scanner(System.in);

  System.out.println("请输入是否下雨");
  //接受用户录入
  boolean isXiaYu=input.nextBoolean();
  if(isXiaYu) {
      System.out.println("带伞");
  }
  ```

  ​


-  if-else结构

  - 语法

  ```java
  if(条件){
      语句1;
  }else{
      语句2;
  }
  ```

  - 当条件为真时，执行if里的语句块，否则执行else里语句
  - 示例

  ```java
  //创建一个Scanner对象
  Scanner input = new Scanner(System.in);

  System.out.println("请输入是否下雨");
  //接受用户录入
  boolean isXiaYu=input.nextBoolean();
  if(isXiaYu) {
      System.out.println("带伞");
  }else {
      System.out.println("不带伞");
  }
  ```

  ​

-  多重if结构

  - 语法

  ```java
  if(条件){
      语句;
  }else{
      if(条件){
          语句;
      }else{
          ...
      }
  }
  ```

  - 改写

  ```java
  if(条件){
      语句;
  }else if(条件){
          语句;
  }else{
      ...
  }
  ```

  - 示例

  ```java
  // 90及以上 A
  // 80~90 B
  // 70~80 C
  // 60~70 D
  // 60以下 E

  // 创建一个Scanner对象
  Scanner input = new Scanner(System.in);
  System.out.println("请输入成绩");
  // 接收用户的录入
  int score = input.nextInt();
  if (score >= 90) {
      System.out.println("A");
  } else {
      if (score >= 80) {
          System.out.println("B");
      } else {
          if (score >= 70) {
              System.out.println("C");
          } else {
              if (score >= 60) {
                  System.out.println("D");
              } else {
                  System.out.println("E");
              }
          }
      }
  }
  // 改写
  if (score >= 90) {
      System.out.println("A");
  } else if (score >= 80) {
      System.out.println("B");
  } else if (score >= 70) {
      System.out.println("C");
  } else if (score >= 60) {
      System.out.println("D");
  } else {
      System.out.println("E");
  }
  ```

  ​

- 嵌套if结构

  - 语法 

  ```java
  if(条件1){
      if(条件2){
          if(条件3){
                语句1;
          }
      }
    
  }
  ```

  - 改写

  ```java
  if(条件1 && 条件2 && 条件3){
                语句1;
  }
  ```

  - 示例

  ```java
  boolean gao=false;
  		boolean shuai=true;
  		boolean fu = true;
  		boolean isSuccess=false; //判断变量
  		if(gao) {
  			if(shuai) {
  				if(fu) {
  					System.out.println("咱们交朋友吧");
  					isSuccess=true;
  				}
  			}
  		}
  		
  		
  		if(!isSuccess) {
  			System.out.println("滚");
  		}
  ```

  - 改写

  ```java
  boolean gao = true;
  		boolean shuai = true;
  		boolean fu = true;
  		if (gao && shuai && fu) {
  			System.out.println("咱们交朋友吧");
  		} else {
  			System.out.println("滚");
  		}
  ```

 10.2.1.1. 流程图

- 开始和结束   （椭圆形）

- 输入和输出    （矩形）

- 流程判断          (凌形)           

- 流程线             (--->)

- if 流程图

  ```flow
st=>start: 开始
e=>end: 结束
op1=>operation: 输入值
op2=>operation: 带伞
cond=>condition: 是否下雨

st->op1->cond
cond(yes)->op2->e
  ```




  - if-else 流程图

  ```flow
st=>start: 开始
e=>end: 结束
op1=>operation: 输入值
op2=>operation: 带伞
op3=>operation: 不带伞
cond=>condition: 是否下雨

st->op1->cond
cond(yes)->op2->e
cond(no)->op3->e
  ```

  - 多重if

    ```flow
    st=>start: 开始
    e=>end: 结束
    op1=>operation: 输入分数
    opA=>operation: A
    opB=>operation: B
    opC=>operation: C
    opD=>operation: D
    opE=>operation: E
    cond=>condition: 是否>=90
    cond2=>condition: 是否>=80
    cond70=>condition: 是否>=70
    cond60=>condition: 是否>=60
    st->op1->cond
    cond(yes)->opA->e
    cond(no)->cond2
    cond2(yes)->opB->e
    cond2(no)->cond70
    cond70(yes)->opC->e
    cond70(no)->cond60
    cond60(yes)-->opD->e
    cond60(no)-->opE->e
    ```

  - 嵌套if

    ```flow
    st=>start: 开始
    e=>end: 结束
    opGao=>operation: 输入是否高
    opShuai=>operation: 输入是否帅
    opFu=>operation: 输入是否富
    opFriend=>operation: 交朋友吧
    opGun=>operation: 滚
    condGao=>condition: 是否高
    condShuai=>condition: 是否帅
    condFu=>condition: 是否富

    st->opGao->condGao
    condGao(no)->opGun->e
    condGao(yes)->opShuai->condShuai
    condShuai(no)->opGun->e
    condShuai(yes)->opFu->condFu
    condFu(no)->opGun->e
    condFu(yes)->opFriend->e
    ```

    ​

 10.2.2. switch-case 结构 

- 语法

```java
switch(表达式){
    case 值1:语句1;break;
    case 值2:语句2;break;
    case 值3:语句3;break;
    default:其它语句;break;
}
```

- 解读
  - 在jdk1.7之前只能支持char、int(byte、short) 和枚举
  - 在jdk1.7及之后可以支持char、int(byte、short)、枚举和String
  - 最简单的表达式为变量
  - case后的值是唯一的，它的值是表达式中可能出现的值
  - default当case值都不匹配时执行的语句
  - break:当满足case的值时，执行语句，break结束些流程。如果当前语句没有break，则会继续执行后面的语句，且不会再判断case的值，直接有break为止，都没有break，则执行到最后。
  - default后的break可以省略，但推荐不省略
- 示例

```java
//星期几
int num = 2;

switch(num){
    case 1:System.out.println("星期一");break;
    case 2:System.out.println("星期二");break;
    case 3:System.out.println("星期三");break;
    case 4:System.out.println("星期四");break;
    case 5:System.out.println("星期五");break;
    case 6:System.out.println("星期六");break;
    case 7:System.out.println("星期日");break;
    default:System.out.println("输入有误");break;
}
// switch的case后是一个值，表述区间不方便，下面表示方法很勉强
switch(num){
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:System.out.println("1~7");break;
    default:System.out.println("输入有误");break;
}
```

- 分析：

  - 对比上面if，我们发现swtich-case是多重if的一个翻版

  - swtich-case和多重if谁强大？(多重if更强大)

    ```java
    if(score>=90){
        *  	System.out.println("A");
        *  }else if(score>=80){
        *  	System.out.println("B");
        *  }
    *  
        *  如果是区间,switch就搞不定了，所以多重if更强大
    ```

  - swtich-case使用它的好外？(条件多，精简)

    - 当分支超2条时，使用swtich-case在代码篇幅上更精简一点

 10.3. 循环结构

 10.3.1. while循环

- 语法 

  ```java
  while(条件){
      语句;
      趋于条件结束的语句;
  }

  ```

- 解读

  - 当条件满足的条件，就执行语句块，条件不满足循环则结束
  - 如果条件一直满足，则是死循环，小心 

- 嵌套while循环

  ```java
  while(条件1){        //行
      while(条件2){    //列
          语句1;
          趋于条件2结束的语句;
      }
       趋于条件1结束的语句;
  }

  ```

-  示例

  ```java
  public static void main(String[] args) {
      int i=0;
      while(i<5) { //条件
          System.out.println("我爱你");
          i++; //趋于条件结束的语句
      }
  }
  public static void main(String[] args) {
      int i=0,j=0;
      while(i<3) { //行
          j=0;
          while(j<5) { //列
              System.out.print("*");
              j++;
          }
          System.out.println();
          i++;
      }
  }
  ```

 10.3.2. do-while循环

- 语法 

  ```java
  do{
      语句;
      趋于条件结束的语句;
  }while(条件); 

  ```

- 先做一次，再判断 ，后面条件满足则继续执行。当条件不满足，循环结束

- 对比while和do-while

  - 相同点:

    - 都能实现循环

  - 不同点：

    - while先判断再执行,do-while先执行再判断

    - 当开始条件为真，两者没有区别；当开始条件为假，do-while至少要比while多执行一次

    - ```java
      int j=5;
      while(j<5) {
          System.out.println("a");
          j--;
      }

      //-- 多做N回
      //++ 多做1回
      j=5;
      do {
          System.out.println("b");
          j--;
      }while(j<5);

      ```

- 应用场景 

  - 询问菜单是否继续

    ```java
    public static void main(String[] args) {
        //创建Scanner对象
        Scanner input = new Scanner(System.in);
        int ope;
        char ch ;
        do {

            System.out.println("=====================欢迎来到xx管理系统======================");
            System.out.println("1、增加学生");
            System.out.println("2、删除学生");
            System.out.println("3、修改学生");
            System.out.println("4、根据学号查询学生");
            System.out.println("5、查询所有学生");
            System.out.println("========================================================");
            System.out.println("请选择功能");
            //接收用户的录入	
            ope = input.nextInt();
            switch (ope) {
                case 1:System.out.println("正在增加...");break;
                case 2:System.out.println("正在删除...");break;
                case 3:System.out.println("正在修改...");break;
                case 4:System.out.println("正在按学号查询...");break;
                case 5:System.out.println("正在查询所有...");break;
                default:System.out.println("输入有误");break;
            }
            System.out.println("是否继续?(Y/N)");
            ch=input.next().charAt(0);

        }while(ch=='Y' || ch=='y');

    }
    ```

    ​

- do-while嵌套

  ```java
  do{
      do{
          语法 
          趋于条件2结束的语句;
      }while(条件2);
      趋于条件结束的语句;
  }while(条件1);
     

  ```

- 示例

  ```java
  public static void main(String[] args) {
      int i=0;
      do {
          System.out.println("i love you ");
          i++;
      }while(i<5);
  }
  public static void main(String[] args) {
      int i=0,j=0;
      do {
          j=0;
          do {
              System.out.print("*");
              j++;
          }while(j<5);
          System.out.println();
          i++;
      }while(i<3);
  }
  ```

  ​

 10.3.3. for循环

- 语法

  ```java
  for(初始化;条件;趋于条件结束的语句){
      语句;
  } 

  ```

- 示例

  ```java
  for(int i=0;i<5;i++) {
      System.out.println("i love you");
  }

  ```

- 流程理解

![10.png](https://img.hacpai.com/file/2019/09/10-6ff8bca1.png)


- 本质上for是对while的精简版

  ```java
  for(int i=0;i<5;i++) {
      System.out.println("i love you");
  }
  		
  int i=0;
  while(i<5) { //条件
      System.out.println("我爱你");
      i++; //趋于条件结束的语句
  }

  int j=0;
  for(;j<5;) {
      System.out.println("i love you");
      j++;
  }
  ```

- for嵌套

  ```java
  for(初始化1;条件1;趋于条件1结束的语句){
      for(初始化2;条件2;趋于条件2结束的语句){
          语法 ;
      }
  }
  ```

  ```java
  for(int i=0;i<3;i++) {
      for(int j=0;j<5;j++) {
          System.out.print("*");
      }
      System.out.println();
  }
  ```

 10.3.4. 流程图

```flow
st=>start: 开始
e=>end: 结束
op1=>operation: 输出我爱你
cond=>condition: 是否小于5

st->cond
cond(no)->e
cond(yes)->op1->cond

```


 10.3.5. 循环中的关键字（break和continue）

- break: 结束当前循环
- continue:  结束本次继续一下次
- 示例

```java
public static void main(String[] args) {
    //0~100之间偶数，且>50结束
    for(int i=0;i<100;i++) {
        if(i%2!=0) {
            continue;
        }
        System.out.println(i);
        if(i>=50) {
            break;
        }
    }

}
```

