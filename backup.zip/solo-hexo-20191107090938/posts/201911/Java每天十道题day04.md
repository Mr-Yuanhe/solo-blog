title: Java每天十道题 - day04
date: '2019-11-06 18:00:28'
updated: '2019-11-06 22:26:55'
tags: [Java-每天十道题]
permalink: /articles/2019/11/06/1573034428639.html
---
## 1.区分String s = "123"；与 String s1 = new String("123")

```
> String s = "123"; 在常量去先找“123”，如果找不到就创建一个“123”，如果能找到，则把这个“123”的引用赋值给s，这里面不涉及堆内存；

> String s=new String("123")，是在堆内存创建一个对象，对象的值指向常量去的“123”；然后把这个对象的地址赋值给s，这个里面涉及栈内存，堆内存以及常量区。
```
 
## 2.运行时异常是什么

异常分为运行时异常和编译时异常，编译时异常是指java编译器对java代码规范的的检查，如果不同，则会及时提示。如果不改过来就不会进行编译。运行时异常是指在代码编译时不会出错，但是在运行时则会抛出异常。是在运行之时才要处理的异常；例如

```
NullPointException 空指针异常
ArithmeticException  数学异常
ClassCastException  类型转换异常
IndexOutOfBoundsException 下标越界异常
NumberFormatException 数字格式化异常
```


## 3.oracle中的约束有哪几类.举例说明

```
1.主键约束（Primay Key Coustraint） 唯一性，非空性
2.唯一约束 （Unique Counstraint）唯一性，可以空，但只能有一个。一般用来约束账号，身份证号码具有特殊意义的列。
3.检查约束 (Check Counstraint) 对该列数据的范围、格式的限制（如：年龄、性别等）,受约束的列不能为空，一般是是来约束密码，状态等
4.默认约束 (Default Counstraint) 该数据的默认值
5.外键约束 (Foreign Key Counstraint) 被约束的列只能出现规定好的值，一般用于性别的约束
```

## 4.DQL、DML、DDL、DCL的区别是什么

```
> DDL: 数据库定义语言，create drop

> DCL: 数据控制语言，grant, revoke, commit, rollback

> DML: 数据操作语言 ，insert delete update

> DQL:数据查询语言 select
```

## 5.css的三种选择器是什么

```
标签选择器
类选择器
ID选择器
ID > 类 > 标签
```

## 6.有哪几种标签可以向后台发起数据请求

```
1.link标签的href属性
2.script标签的src属性
3.img标签的src属性
4.ajax发送请求
5.表单提交发送请求
6.a标签的href发送请求
7.iframe的src属性发送请求
```

## 7.tomcat的目录结构有哪些.分别代表什么作用；类似的容器还有哪些
![image.png](https://img.hacpai.com/file/2019/11/image-642924ce.png)

```
> bin:主要存放Tomcat的命令，以.sh和.bat结尾的文件

> conf:存放Tomcat的配置文件 如：server.xml设置端口，域名，ip；web.xml:设置Tomcat支持的文件类型；context.xml；配置数据源；tomcat-users.xml用来配置管理Tomcat的用户与权限。

> lib:用来存放jar包

> logs:用来存放Tomcat运行过程中产生的日志文件

> temp:用来存放Tomcat运行过程中产生的临时文件

> webapps:用来存放应用程序，可以以文件夹，war包，jar包的形式发布

> work:用来存放编译后的文件，源文件和.class文件
```

- __和Tomcat相似的容器：Jboss，weblogic，glassfish__

## 8.实现servlet有几种方式

- 实现Servlet接口，然后实现接口中的五个方法

- 继承GenericServlet，只需要实现一个方法：service

- 继承HttpServlet,重写doGet和doPost方法


## 9.log4j的作用是什么？有几种级别？一般再发布的时候修改为什么级别.为什么

- 作用

Log4j是用来打印日志文件的，记录Java运行时的具体操作的

- 级别

debug > info > warn > error > fatal

- 发布等级

一般发布时修改为error，减少io操作。

## 10.如何实现mybatis的二级缓存

	  缓存的目的是为了加快查询；mybatis中有一级缓存，它是默认打开的，是sqlsession范围；mybatis也支持二级缓存，它需要ehcache等的支持，范围是mapper。在找数据之时，先找一级缓存，再找二级缓存，最后才是数据库。不能因为缓存找不到而出错。缓存的失效一是时间到了，二是数据被改变。

- 实现二级缓存：

1. 在mybait的全局配置中启用二级缓存

```
<settring name="cacheEnabled" value="true"/>
```

2. 在对应的mapper.xml文件中配置cache节点

```
<cache type="" />
```

3. 使实体类实现Serializable接口，实现序列化

## 11.final, finally, finalize的区别； throw , throws的区别；break ,continue, return的区别； if else/ switch case defualt的区别；interface与抽象类的区别；重写与重载的区别；对象的上转型与面向接口编程的区别

- final, finally, finalize的区别

```
1.final是修饰符（关键字）
final 修饰的类叫最终类，该类不能被继承。
final 修饰的方法不能被重写。
final 修饰的变量叫常量，常量必须初始化，初始化之后值就不能被修改。也就是只能赋一次值。典型的例子就是String类型就是一个被final修饰的char数组。
```
- throw , throws的区别

```
1、throw用于方法内部，throws用于方法声明上  
2、throw后跟异常对象，throws后跟异常类型  
3、throw后只能跟一个异常对象，throws后可以一次声明多种异常类型
```
- break ,continue, return的区别

```
break：  
1、用于完全结束一个循环，跳出循环体执行循环后面的语句。  
2、当break出现在循环体中的switch语句体内时，其作用只是跳出该switch语句体。
continue：
跳过当次循环中剩下的语句，执行下一次循环。  
return：  
1、从当前方法中退出，返回调用的开始。  
2、返回一个值给调用该方法的语句，返回值的数据类型必须与方法的声明中的返回值的类型一致。
```
-  if else/ switch case defualt的区别

```
if else 
一个一个顺序的进行判断，找到就终止，找不到就判断到最后

switch...case会生成一个跳转表来指示case分支的地址，不用像if...else...if那样遍历条件分支直到命中条件，而只需访问对应索引号的表项从而到达定位分支的目的。时间效率较高，但需要较多的存储空间。  defualt是case中没有找到才执行的。

此外，switch...case只能处理case为常量的情况，并不能处理区间判断的情况。例如：if (a > 10 && a < 20)用switch...case是无法处理的。
```

- 对象的上转型与面向接口编程的区别

```
上转型对象不能操作子类新增的成员变量，不能调用子类新增的方法。
上转型对象可以访问子类继承和隐藏的成员变量，也可以调用子类继承的方法或子类重写的方法。


```













