title: SpringSpring MVC面试题
date: '2019-10-17 16:31:18'
updated: '2019-10-17 16:31:18'
tags: [Java面试题]
permalink: /articles/2019/10/17/1571301078556.html
---
# 144. 谈谈你对Spring 的理解

- Spring 是一个开源框架，为简化企业级应用开发而生。Spring 可以是使简单的JavaBean 实现以前只有EJB 才能实现的功能。Spring 是一个开源的控制反转（Inversion of Control，IoC）和面向切面（AOP）的容器框架。它的主要目的是使现有技术更加易用，推荐编码最佳实现，从而简化企业开发。
- Spring致力于Java EE 应用的各种解决方案，而不是仅仅专注于某一层面的方案。可以说，Spring是企业应用开发的“一站式”选择，Spring贯穿表示层、业务层、持久层。然而，Spring并不想取代那些已有的框架，而以高度的开发性与他们无缝整合。
- Spring 容器的主要核心是： 
  - 控制反转（IOC），传统的 java 开发模式中，当需要一个对象时，我们会自己使用 new 或者 getInstance 等直接或者间接调用构造方法创建一个对象。而在 spring 开发模式中，spring 容器使用了工厂模式为我们创建了所需要的对象，不需要我们自己创建了，直接调用spring 提供的对象就可以了，这是控制反转的思想。
  - 依赖注入（DI），spring 使用 javaBean 对象的 set 方法或者带参数的构造方法为我们在创建所需对象时将其属性自动设置所需要的值的过程，就是依赖注入的思想。
  - 面向切面编程（AOP），在面向对象编程（oop）思想中，我们将事物纵向抽成一个个的对象。而在面向切面编程中，我们将一个个的对象某些类似的方面横向抽成一个切面，对这个切面进行一些如权限控制、事物管理，记录日志等公用操作处理的过程就是面向切面编程的思想。AOP 底层是动态代理，如果是接口采用 JDK 动态代理，如果是类采用CGLIB 方式实现动态代理。

# 145. Spring 能帮我们做什么？

- Spring  能帮我们根据配置文件创建及组装对象之间的依赖关系。 
  - Spring  根据配置文件来进行创建及组装对象间依赖关系，只需要改配置文件即可 
- Spring 面向切面编程能帮助我们无耦合的实现日志记录，性能统计，安全控制。 
  - Spring 面向切面编程能提供一种更好的方式来完成，一般通过配置方式，而且不需要在现有代码中添加任何额外代码，现有代码专注业务逻辑。
- Spring 能非常简单的帮我们管理数据库事务。 
  - 采用 Spring，我们只需获取连接，执行 SQL，其他事物相关的都交给 Spring 来管理了。 
- Spring 还能与第三方数据库访问框架（如 Hibernate、JPA）无缝集成，而且自己也提供了一套 JDBC 访问模板，来方便数据库访问。 
- Spring 还能与第三方Web（如Struts、JSF）框架无缝集成，而且自己也提供了一套 Spring MVC 框架，来方便web 层搭建。
- Spring 能方便的与 Java EE（如Java Mail、任务调度）整合，与更多技术整合（比如缓存框架）

# 145. Spring 中的设计模式

- 单例模式——spring 中两种代理方式，若目标对象实现了若干接口，spring 使用jdk java.lang.reflect.Proxy  类代理。若目标兑现没有实现任何接口，spring 使用 CGLIB 库生成目标类的子类。单例模式——在 spring 的配置文件中设置 bean 默认为单例模式。
- 模板方式模式——用来解决代码重复的问题。
  - 比如：RestTemplate、JmsTemplate、JpaTemplate 
- 前端控制器模式——spring 提供了前端控制器DispatherServlet 来对请求进行分发。 
- 视图帮助（view helper）——spring 提供了一系列的 JSP 标签，高效宏来帮助将分散的代码整合在视图中。 
- 依赖注入——贯穿于 BeanFactory/ApplacationContext 接口的核心理念。 
- 工厂模式——在工厂模式中，我们在创建对象时不会对客户端暴露创建逻辑，并且是通过使用同一个接口来指向新创建的对象。Spring 中使用beanFactory 来创建对象的实例。

# 146. Spring 的常用注解

- 常用的注解： 
  - @Resource:  自动装配，java提供
  - @Autowired： 自动装配，spring提供
  - @Controller、@Service、@Repository、@Component

# 147. 简单介绍一下Spring bean 的生命周期

- bean 定义：在配置文件里面用<bean></bean>来进行定义。 
- bean 初始化：有两种方式初始化: 
  - 在配置文件中通过指定 init-method 属性来完成 
  - 实现 org.springframwork.beans.factory.InitializingBean 接口 ,知道一下，我们没讲
- bean 调用：有三种方式可以得到 bean 实例，并进行调用
- bean 销毁：销毁有两种方式
  - 使用配置文件指定的 destroy-method 属性
  - 实现org.springframwork.bean.factory.DisposeableBean 接口,知道一下，我们没讲

# 148. 什么是依赖，什么是依赖注入？

- **依赖：**两个元素中一个定义发生改变则会引起另一个元素发生改变，则称这两个元素之间存在依赖关系。

- **控制反转**(IoC)：在传统的程序设计过程中，都是在应用内部创建及维护依赖的对象。  控制反转就是应用本身不负责依赖对象的创建及维护，依赖对象的创建及维护是由外部容器负责的。这样控制权就由应用转移到外部容器，控制权的转移就是控制反转。

- **依赖注入：**是指 在运行期，由外部容器动态地将依赖对象注入到组件中。

  依赖注入让Bean与Bean之间以配置文件组织在一起，而不是以硬编码的方式耦合在一起。

# 149. Spring主要包含哪些模块?

- 核心容器：包括Core、Beans、Context、EL 模块。
  - Core 模块：封装了框架依赖的最底层部分，包括资源访问、类型转换及一些常用工具类。 
  - Beans 模块：提供了框架的基础部分，包括反转控制和依赖注入。其中 Bean Factory 是容器核心，本质是“工厂设计模式”的实现，而且无需编程实现“单例设计模式”，单例完全由容器控制，而且提倡面向接口编程，而非面向实现编程；所有应用程序对象及对象间关系由框架管理，从而真正把你从程序逻辑中把维护对象之间的依赖关系提取出来，所有这些依赖关系都由 BeanFactory 来维护。
  - Context 模块：以 Core 和 Beans 为基础，集成 Beans 模块功能并添加资源绑定、数据验证、国际化、Java EE 支持、容器生命周期、事件传播等；核心接口是 ApplicationContext。
  - EL 模块：提供强大的表达式语言支持，支持访问和修改属性值，方法调用，支持访问及修改数组、容器和索引器， 命名变量，支持算数和逻辑运算，支持从 Spring 容器获取 Bean，它也支持列表投影、选择和一般的列表聚合等。
- AOP、Aspects 模块：
  - AOP 模块：Spring AOP 模块提供了符合  AOP Alliance 规范的面向方面的编程（aspect-oriented programming）实现，提供比如日志记录、权限控制、性能统计等通用功能和业务逻辑分离的技术，并且能动态的把这些功能添加到需  要的代码中；这样各专其职，降低业务逻辑和通用功能的耦合。
  - Aspects 模块：提供了对AspectJ 的集成，AspectJ 提供了比 Spring ASP 更强大的功能。数据访问/集成模块：该模块包括了 JDBC、ORM、OXM、JMS 和事务管理。
- 事务模块：该模块用于 Spring 管理事务，只要是 Spring 管理对象都能得到 Spring 管理事务的好处，无需在代码中进行事务控制了，而且支持编程和声明性的事务管理。
- JDBC 模块：提供了一个 JBDC 的样例模板，使用这些模板能消除传统冗长的 JDBC 编码还有必须的事务控制，而且能享受到 Spring 管理事务的好处。
- ORM 模块：提供与流行的“对象-关系”映射框架的无缝集成，包括 Hibernate、JPA、MyBatis 等。而且可以使用 Spring 事务管理，无需额外控制事务。
- OXM 模块：提供了一个对 Object/XML 映射实现，将 java 对象映射成 XML 数据，或者将 XML 数据映射成 java对象，Object/XML 映射实现包括JAXB、Castor、XMLBeans 和 XStream。
- JMS 模块：用于JMS(Java Messaging Service)，提供一套 “消息生产者、消息消费者”模板用于更加简单的使用 JMS，JMS 用于用于在两个应用程序之间，或分布式系统中发送消息，进行异步通信。
- Web/Remoting 模块：Web/Remoting 模块包含了Web、Web-Servlet、Web-Struts、Web-Porlet 模块。
- Web 模块：提供了基础的 web 功能。例如多文件上传、集成 IoC 容器、远程过程访问（RMI、Hessian、Burlap）以及Web Service 支持，并提供一个 RestTemplate 类来提供方便的 Restful services 访问。
- Web-Servlet 模块：提供了一个 Spring MVC Web 框架实现。Spring  MVC 框架提供了基于注解的请求资源注入、更简单的数据绑定、数据验证等及一套非常易用的 JSP 标签，完全无缝与 Spring 其他技术协作。
- Web-Struts 模块：提供了与Struts 无缝集成，Struts1.x 和 Struts2.x 都支持
- Test 模块： Spring 支持 Junit 和 TestNG 测试框架，而且还额外提供了一些基于 Spring 的测试功能，比如在测试Web 框架时，模拟 Http 请求的功能。

# 150. ApplicationContext 的实现类有哪些?

- FileSystemXmlApplicationContext ：此容器从一个XML 文件中加载beans 的定义，XML Bean 配置文件的全路径名必须提供给它的构造函数。
- ClassPathXmlApplicationContext：此容器也从一个 XML 文件中加载 beans 的定义，这里，你需要正确设置
- classpath 因为这个容器将在 classpath 里找 bean 配置。 
- WebXmlApplicationContext：此容器加载一个 XML 文件，此文件定义了一个WEB 应用的所有 bean。

# 151. 有哪些不同类型的 IOC（依赖注入）方式？

Spring 提供了多种依赖注入的方式。

- Set 注入
- 构造器注入
- 静态工厂的方法注入
- 实例工厂的方法注入

# 152. 什么是Spring beans?

- Spring beans 是那些形成 Spring 应用的主干的 java 对象。它们被 Spring IOC 容器初始化，装配，和管理。这些 beans 通过容器中配置的元数据创建。比如，以 XML 文件中`<bean/>` 的形式定义。
- Spring 框架定义的beans 都是单例 beans。

# 153. 你怎样定义类的作用域

- 当定义一个`<bean>` 在 Spring 里，我们还能给这个 bean 声明一个作用域。它可以通过 bean 定义中的scope 属性来定义。如，当 Spring 要在需要的时候每次生产一个新的 bean 实例，bean 的 scope 属性被指定为 prototype。另一方面，一个 bean 每次使用的时候必须返回同一个实例，这个 bean 的scope 属性必须设为 singleton。

# 154. `<context:annotation-config> `和 `<context:component-scan>`的区别

- <context:annotation-config> **是用于激活那些已经在spring容器里注册过的bean**（无论是通过xml的方式还是通过package sanning的方式）上面的注解。
- <context:component-scan>除了具有<context:annotation-config>的功能之外，<context:component-scan>还可以在指定的package下扫描以及注册javabean 。

# 155. Spring 框架中的单例 bean 是线程安全的吗?  

- Spring 框架中的单例bean 不是线程安全的。

# 156. 什么是Spring 的内部 bean？

- 当一个 bean 仅被用作另一个 bean 的属性时，它能被声明为一个内部 bean，为了定义 inner bean，在
- Spring 的 基于 XML 的 配置元数据中，可以在 `<property/>`或` <constructor-arg/>` 元素内使用`bean/>` 元素，内部 bean 通常是匿名的，它们的 Scope 一般是 prototype。

# 157. 在 Spring 中如何注入一个 java 集合？ 

Spring 提供以下几种集合的配置元素：

- `<list>`类型用于注入一列值，允许有相同的值。 
- `<set>` 类型用于注入一组值，不允许有相同的值。 
- `<map>` 类型用于注入一组键值对，键和值都可以为任意类型。 
- `<props>`类型用于注入一组键值对，键和值都只能为 String 类型。

# 158. 什么是bean 的自动装配？

- 无须在 Spring  配置文件中描述javaBean  之间的依赖关系（如配置`<property>、<constructor-arg>`）。IOC  容器会自动建立javabean 之间的关联关系。

# 159. 为什么要使用 spring？

- spring 提供 ioc 技术，容器会帮你管理依赖的对象，从而不需要自己创建和管理依赖对象了，更轻松的实现了程序的解耦。
- spring 提供了事务支持，使得事务操作变的更加方便。
- spring 提供了面向切片编程，这样可以更方便的处理某一类的问题。
- 更方便的框架集成，spring 可以很方便的集成其他框架，比如 MyBatis、hibernate 等。

# 160. 解释一下什么是 aop？

aop 是面向切面编程，通过预编译方式和运行期动态代理实现程序功能的统一维护的一种技术。

简单来说就是统一处理某一“切面”（类）的问题的编程思想，比如统一处理日志、异常等。

# 161. AOP核心概念

- Aspect（切面）
  - 横切关注点，一般一个切面对应一个额外功能。
- Joinpoint（连接点）
  - 被拦截到的点，因为 Spring 只支持方法类型的连接点，所以在 Spring 中连接点指的就是被拦截到的方法，
- Advice（通知）
  - 通知，用于方法上，表示方法执行方位。共有5种
- Pointcut（切入点）
  - 切入点是一个或一组连接点，通知将在这些位置执行。可以通过表达式或匹配的方式指明切入点。
- Weaving（织入）
  - 织入，指将通知插入到目标对象。
- Target（目标对象）
  - 目标对象，指需要织入切面的对象。
- Proxy（代理对象）
  - 代理对象，指切面织入目标对象之后形成的对象。

# 162. Spring AOP原理

- Spring采用动态代理模式来实现AOP机制。
- Spring AOP采用动态代理的过程：
  - 将切面使用动态代理的方式动态织入到目标对象（被代理类），形成一个代理对象；
  - 目标对象如果没有实现代理接口，那么Spring会采用CGLib来生成代理对象，该代理对象是目标对象的子类；
  - 目标对象如果是final类，并且也没实现代理接口，就不能运用AOP。

# 163. 解释一下什么是 ioc？

ioc：Inversionof Control（中文：控制反转）是 spring 的核心，对于 spring 框架来说，就是由 spring 来负责控制对象的生命周期和对象间的关系。

简单来说，控制指的是当前对象对内部成员的控制权；控制反转指的是，这种控制权不由当前对象管理了，由其他（类,第三方容器）来管理。

# 164. spring 有哪些主要模块？

- spring core：框架的最基础部分，提供 ioc 和依赖注入特性。
- spring context：构建于 core 封装包基础上的 context 封装包，提供了一种框架式的对象访问方法。
- spring dao：Data Access Object 提供了JDBC的抽象层。
- spring aop：提供了面向切面的编程实现，让你可以自定义拦截器、切点等。
- spring Web：提供了针对 Web 开发的集成特性，例如文件上传，利用 servlet listeners 进行 ioc 容器初始化和针对 Web 的 ApplicationContext。
- spring Web mvc：spring 中的 mvc 封装包提供了 Web 应用的 Model-View-Controller（MVC）的实现。

# 165. spring 常用的注入方式有哪些？

- setter 属性注入
- 构造方法注入
- 注解方式注入

# 166. spring 中的 bean 是线程安全的吗？

spring 中的 bean 默认是单例模式，spring 框架并没有对单例 bean 进行多线程的封装处理。

实际上大部分时候 spring bean 无状态的（比如 dao 类），所有某种程度上来说 bean 也是安全的，但如果 bean 有状态的话（比如 view model 对象），那就要开发者自己去保证线程安全了，最简单的就是改变 bean 的作用域，把“singleton”变更为“prototype”，这样请求 bean 相当于 new Bean()了，所以就可以保证线程安全了。

- 有状态就是有数据存储功能。
- 无状态就是不会保存数据。

# 167. spring 支持几种 bean 的作用域？

spring 支持 5 种作用域，如下：

- singleton：spring ioc 容器中只存在一个 bean 实例，bean 以单例模式存在，是系统默认值；
- prototype：每次从容器调用 bean 时都会创建一个新的示例，既每次 getBean()相当于执行 new Bean()操作；
- Web 环境下的作用域：
- request：每次 http 请求都会创建一个 bean；
- session：同一个 http session 共享一个 bean 实例；
- global-session：用于 portlet 容器，因为每个 portlet 有单独的 session，globalsession 提供一个全局性的 http session。

注意： 使用 prototype 作用域需要慎重的思考，因为频繁创建和销毁 bean 会带来很大的性能开销。

# 168. spring 自动装配 bean 有哪些方式？

- no：默认值，表示没有自动装配，应使用显式 bean 引用进行装配。
- byName：它根据 bean 的名称注入对象依赖项。
- byType：它根据类型注入对象依赖项。
- 构造函数：通过构造函数来注入依赖项，需要设置大量的参数。
- autodetect：容器首先通过构造函数使用 autowire 装配，如果不能，则通过 byType 自动装配。

# 169. Spring自动装配的优缺点

- 优点：
  - 自动装配能显著减少配置的数量。不过，采用bean模板（见这里）也可以达到同样的目的。
  - 自动装配可以使配置与java代码同步更新。例如，如果你需要给一个java类增加一个依赖，那么该依赖将被自动实现而不需要修改配置。因此强烈推荐在开发过程中采用自动装配，而在系统趋于稳定的时候改为显式装配的方式。
- 缺点：
  - 尽管自动装配比显式装配更神奇，但是，正如上面所提到的，Spring会尽量避免在装配不明确的时候进行猜测，因为装配不明确可能出现难以预料的结果，而且Spring所管理的对象之间的关联关系也不再能清晰的进行文档化。
  - 对于那些根据Spring配置文件生成文档的工具来说，自动装配将会使这些工具没法生成依赖信息。

# 170. spring 事务实现方式有哪些？

- 声明式事务：声明式事务也有两种实现方式，基于 xml 配置文件的方式和注解方式（在类上添加 @Transaction 注解）。
- 编码方式：提供编码的形式管理和维护事务。

# 171. Spring的事务机制

- Spring支持声明式事务。声明式事务管理采用非侵入式的设计，可以分离业务逻辑和事务管理逻辑，具有良好的适应性。
- Spring使用事务服务代理和事务管理器（如HibernateTransactionManager）来支持事务服务。
- 相对于EJB规范，Spring对事务的边界多了一种嵌套事务（PROPAGATION_NESTED）。
- PROPAGATION_NESTED含义：
  - 如果客户端启动了事务T1，那么Bean启动一个嵌套在T1中的子事务T2；
  - 如果客户端没有启动事务，那么Bean会启动一个新的事务，类似于REQUIRED_NEW

# 172. 说一下 spring 的事务隔离？

spring 有五大隔离级别，默认值为 ISOLATION_DEFAULT（使用数据库的设置），其他四个隔离级别和数据库的隔离级别一致：

- ISOLATION_DEFAULT：用底层数据库的设置隔离级别，数据库设置的是什么我就用什么；
- ISOLATION*READ*UNCOMMITTED：未提交读，最低隔离级别、事务未提交前，就可被其他事务读取（会出现幻读、脏读、不可重复读）；
- ISOLATION*READ*COMMITTED：提交读，一个事务提交后才能被其他事务读取到（会造成幻读、不可重复读），SQL server 的默认级别；
- ISOLATION*REPEATABLE*READ：可重复读，保证多次读取同一个数据时，其值都和事务开始时候的内容是一致，禁止读取到别的事务未提交的数据（会造成幻读），MySQL 的默认级别；
- ISOLATION_SERIALIZABLE：序列化，代价最高最可靠的隔离级别，该隔离级别能防止脏读、不可重复读、幻读。
- 脏读 ：表示一个事务能够读取另一个事务中还未提交的数据。比如，某个事务尝试插入记录 A，此时该事务还未提交，然后另一个事务尝试读取到了记录 A。
- 不可重复读 ：是指在一个事务内，多次读同一数据。
- 幻读 ：指同一个事务内多次查询返回的结果集不一样。比如同一个事务 A 第一次查询时候有 n 条记录，但是第二次同等条件下查询却有 n+1 条记录，这就好像产生了幻觉。发生幻读的原因也是另外一个事务新增或者删除或者修改了第一个事务结果集里面的数据，同一个记录的数据内容被修改了，所有数据行的记录就变多或者变少了。

# 173. 说一下 spring mvc 运行流程？

- spring mvc 先将请求发送给 DispatcherServlet。
- DispatcherServlet 查询一个或多个 HandlerMapping，找到处理请求的 Controller。
- DispatcherServlet 再把请求提交到对应的 Controller。
- Controller 进行业务逻辑处理后，会返回一个ModelAndView。
- Dispathcher 查询一个或多个 ViewResolver 视图解析器，找到 ModelAndView 对象指定的视图对象。
- 视图对象负责渲染返回给客户端。

# 174. spring mvc 有哪些组件？

- 前置控制器 DispatcherServlet。
- 映射控制器 HandlerMapping。
- 处理器 Controller。
- 模型和视图 ModelAndView。
- 视图解析器 ViewResolver。

# 175. @RequestMapping 的作用是什么？

将 http 请求映射到相应的类/方法上。

# 176. @Autowired 的作用是什么？

@Autowired 它可以对类成员变量、方法及构造函数进行标注，完成自动装配的工作，通过@Autowired 的使用来消除 set/get 方法。

# 177. Spring中的通知类型？

1）  before：前置通知，在一个方法执行前被调用。

2）  after: 在方法执行之后调用的通知，无论方法执行是否成功。

3）  after-returning: 仅当方法成功完成后执行的通知。

4）  after-throwing: 在方法抛出异常退出时执行的通知。

5）  around: 在方法执行之前和之后调用的通知。

# 178.  Spring对持久层的支持

 JDBC，O/R Mapping（Hibernate，TopLink等）

Spring对持久层支持采用的策略：

- Spring对持久层“不发明重复的轮子”，即没有重新实现新的持久层方案，对现有持久层方案做封装，更利于使用。
- 采用DAO模式
- 提供了大量的模板类来简化编程（JdbcTemplate等）
- 重新设计了一套完善的异常体系结构
  - 类型丰富，细化异常类型
  - 全都是运行时异常（RuntimeException）

# 179.  实际开发过程中为什么拆分Spring配置文件？ 

- 当项目规模大的时候，配置文件可读性、可维护性差，庞大的Spring配置文件难以阅读。
- 团队开发时，多人修改同一配置文件容易发生冲突，降低开发效率。

# 180. 采用何种策略拆分Spring配置文件？

- 如每个开发人员负责一模块采用**公用配置**（包含数据源、事务等）+**每个系统模块一个单独配置文件**（包含dao、service及action）形式
- 如采用分层负责或者DAO配置代码由代码生成工具生成时，我们采用**公用配置**（包含数据源、事务等）+ **DAO Bean**配置 + **业务逻辑**Bean配置 + **Action Bean**配置形式

# 
