title: CSS学习
date: '2019-09-17 00:35:24'
updated: '2019-09-17 00:35:24'
tags: [CSS]
permalink: /articles/2019/09/17/1568651723977.html
---
# 1、CSS概念

- CSS是什么?

```
CSS 指层叠样式表 (Cascading Style Sheets) 
样式定义如何显示 HTML 元素 
样式通常存储在样式表中 
把样式添加到 HTML 4.0 中，是为了解决内容与表现分离的问题 
外部样式表可以极大提高工作效率 
外部样式表通常存储在 CSS 文件中 
多个样式定义可层叠为一 
```

- CSS与HTML有什么区别

```
HTML:注重的是内容
CSS:注重的是表现（以上的背景、字体的颜色、字体的大小、边框....）
```

- css的基本语法

```css
selector{
  property1:value1;
  property2:value2;
  property3:value3;
  ....
}
selector：选择器
property：样式的属性
value：样式的值
```

- 一般css代码写在style标签中

```
注意点：
1、style标签中只能写入样式代码
2、通常<style></style>建议放在head标签中
```

# 2、基本选择器

- 有三种

```
标签选择器
类选择器（class选择器）
id选择器
```

```html
<head>
  <meta charset="UTF-8">
  <title>Title</title>
  <style>
    /*css的注释与html不一样，ctrl  /*/
    /*标签选择器：标签*/
    p{
      /*字体颜色为红色*/
      color: red;
      /*背景色为#ccc色*/
      background: #ccc;
    }
    /*类选择器： .类名*/
    .c1{
      /*字体大小为40像素*/
      font-size: 40px;
    }

    /*id选择器：#id值*/
    #p1{
      /*边框的宽度为2xp、实线、蓝色*/
      border: 2px solid blue;
    }
  </style>
</head>
<body>
  <h2>静夜思</h2>
  <p>作者：李白</p>
  <p class="c1">床前明月光，</p>
  <p>疑是地上霜。</p>
  <p>举头望明月，</p>
  <p id="p1">低头思故乡。</p>
  <div class="c1">
    这首古诗经常被用来撩妹！
  </div>
</body>
```
# 3、样式的使用范围

- 三种使用范围

```
行内样式
当前页样式
外部引入样式
```

- 行内样式

```
样式写在标签中就是行内样式
```

```html
<p style="color: #f00;background: #ccc">作者：李白</p>
```

- 当前页样式

```
样式写在当前页的style标签中，就是当时样式
```

```html
<head>
    <style>
        #p1{
            font-size: 30px;
            /*字体样式加粗*/
            font-weight: bold;
        }
    </style>
</head>
<body>
    <p id="p1">低头思故乡。</p>
</body>
```

- 外部引入的样式

```
# html文件中引入css文件，css文件中的样式，就是外部引入样式
# 引入外部css文件的方式有两种
1、<link rel="stylesheet" href="url">标签映入
2、import:"url"语法导入
```

```html
<head>
    <!--引入外部样式的方式1-->
    <!--<link rel="stylesheet" href="./css/base.css">-->
    <style>
        @import "css/base.css";
    </style>
</head>
<body>
    <h2>静夜思</h2>
    <p class="c1">床前明月光，</p>
    <p>疑是地上霜。</p>

    <div class="c1">
        这首古诗经常被用来撩妹！
    </div>
</body>
```

- 两种引入外部样式的方式存在一定的区别

```
1、link属于html标签，而@import是css提供的。
2、页面被加载时，link会同时被加载，而@import引用的css会等到页面加载结束后加载。
3、link是html标签，因此没有兼容性，而@import只有IE5以上才能识别。
4、link方式样式的权重高于@import的。  
5、link方式引入的样式可以给dom操作，而import引入的样式不能够给dom操作使用
```

# 4、样式优先级

- 样式具有优先级


- 选择器优先级

```
id选择器>class选择器>标签选择器
```

- 注意点：

```
同一个优先级：样式会被覆盖，后面的样式覆盖前面的样式
```

```html
<head>
  <style>
    .c2{
      color: red;
    }
    #p1{
      color: blue;
    }
    p{
      color: green;
    }
    #p1{
      color: #ccc;
    }
  </style>
</head>
<body>
  <h2>静夜思</h2>
  <p>举头望明月，</p>
  <p id="p1" class="c2">低头思故乡。</p>
</body>
```

- 使用范围的优先级

```
行内样式>当前页>~外部引入（就近原则）
有一定的前提
1、外部引入的样式必须在当前的样式之前（link标签必须在style标签之前）
2、外部引入的样式，就相当于把外部的样式代码写在当前页的style标签中
```

```html
<head>
  <!--引入外部样式的方式1-->
  <link rel="stylesheet" href="./css/base.css">
  <style>
    .c1{
      color: blue;
    }
  </style>
</head>
<body>
  <h2>静夜思</h2>
  <p>举头望明月，</p>
  <p id="p1" class="c1" >低头思故乡。</p>
</body>
```

- important是样式的最高优先级

```css
.c1{
  color:red !important;
}
```

# 5、样式的继承

- 子标签可以继承父标签的样式
- 有些样式默认继承

```
color、font-开头、text-开头、line-开头
```

```html
<head>
  <style>
    /*默认继承样式学习*/
    #box1{
      color: red;
      /*文本装饰：下划线*/
      text-decoration: underline;
      /*字体系列:楷体*/
      font-family: "楷体";
      /*行高：80px*/
      line-height: 80px;
    }
    /*行高(一行的高)的学习*/
    #box2{
      font-size: 40px;
      border: 3px solid red;
      /*技巧：行高可以让一行的文字，垂直居中*/
      line-height: 300px;
      height: 300px;
    }
  </style>
</head>
<body>
  <div id="box1">
    我是div中的文字
    <h1>样式的继承</h1>
    <p>今天是星期五~，晚上可以浪~~</p>
  </div>
  <!--html中的文字换行相当于空格-->
  <div id="box2">
    我是div中的文字我是div中的文字我是div中的文字我是div中的文字我是div中的文字我是div中的文字
  </div>
</body>
```

- 其他样式可以通过属性的inherit值，手动继承

```html
<head>
  <style>
    #box1{
      color: red;
      border: 2px solid blue;
    }
    h1{
      border: inherit;
    }
    p{
      border: inherit;
    }
  </style>
</head>
<body>
  <div id="box1">
    我是div中的文字
    <h1>样式的继承</h1>
    <p>今天是星期五~，晚上可以浪~~</p>
  </div>
  <p>明天周末，没事约约小姐姐~</p>
</body>
```

# 6、复合选择器

```
由多个基本选择器组成的选择器
```

- 后代选择器（空格）


- 直接子代选择器（>）

```html
<head>
  <meta charset="UTF-8">
  <title>Title</title>
  <style>
    /*后代选择器（空格）*/
    #box p{
      color: red;
    }
    /*直接子代选择器、亲儿子（>）*/
    #box>p{
      background: #ccc;
    }
  </style>
</head>
<body>
  <div id="box">
    <h2>静夜思</h2>
    <p>床前明月光，</p>
    <p>疑是地上霜。</p>
    <div>
      <p>举头望明月，</p>
      <p>低头思故乡。</p>
    </div>
  </div>
</body>
```

- 交集选择器

```
注意点：选择器靠着选择器,正常情况下，都是标签选择器与其他选择器交，且标签选择器放在最前面
```

- 并集选择器

```html
<head>
  <style>
    /*交集选择器（选择器靠着选择器,正常情况下，都是标签选择器与其他选择器交，且标签选择器放在最前面）*/
    p.c1{
      color: red;
      background: #ccc;
    }
    /*并集选择器（,）*/
    h2,p,.c2{
      border: 3px solid red;
    }
  </style>
</head>
<body>

  <h2>静夜思</h2>
  <h2 class="c1">唐·李白</h2>
  <p class="c1">床前明月光，</p>
  <p>疑是地上霜。</p>
  <p>举头望明月，</p>
  <p>低头思故乡。</p>
  <div class="c2">
    我是div
  </div>
</body>
```

- 通配选择器

```
"*"就是选择器,可以选中页面上所有的元素（*就是通配符）\

注意：在优先级中，它的优先级是最低的
```

```css
*{
  border: 3px solid red;
}
```

# 7、样式的权重

- 当多个复合选择器同时选中某个元素的时候，就需要考虑样式的权重
- 权重是如何考虑的

```
数基本选择器的个数（id选择器的个数，类选择器的个数，标签选择器的个数）
```

```html
<head>
  <style>
    /*1,1,1==111*/
    #d1 .c2 p{
      color: red;
    }

    /*1,0,3==103*/
    div div div #p1{
      color: blue;
    }

    /*0,3,4==34*/
    div.c1 div.c2 div.c3 p{
      color: yellow;
    }
  </style>
</head>
<body>
  <div id="d1" class="c1">
    <div id="d2" class="c2">
      <div id="d3" class="c3">
        <p id="p1">猜猜我是什么颜色！</p>
      </div>
    </div>
  </div>
</body>
```

# 8、常用样式

- 字体样式

```
font 是简写属性，它把所有的字体样式集成到一个font属性中。 

font-family 规定文本的字体系列。
font-size 规定文本的字体尺寸。 
font-style 规定文本的字体样式。 
font-weight 规定字体的粗细。 
```

```html
<head>
  <style>
    #d1{
      font-size: 32px;
      /*字体系列*/
      font-family: "楷体";
      /*字体粗细*/
      font-weight: bold;
      /*字体风格：normal、italic*/
      font-style: italic;
    }
    
    #d2{
      /*font可以设置多个值，按顺序（风格、粗细、大小、系列）*/
      font: italic bold 32px "楷体";
    }
  </style>

</head>
<body>
  <div id="d1">
    我们一起学习字体样式属性111
  </div>
  <div id="d2">
    我们一起学习字体样式属性222
  </div>

</body>
```

- 文本样式

```
color 设置文本的颜色。
line-height 设置行高。 
text-align 规定文本的水平对齐方式。 
text-decoration 规定添加到文本的装饰效果。
text-indent 规定文本块首行的缩进。 
letter-spacing 设置字符间距。
```

- css中的长度单位

```
px:像素
em:一个中文汉字的大小(如果该元素的文字大小为30px,则1em==30px)
```

```html
<head>
  <style>
    #d1{
      font-size: 30px;
      /*文本水平对齐方式:left、center、right*/
      text-align: left;
      /*文本装饰：none、underline 、overline*/
      text-decoration: underline;
      /*文本的首行缩进：2个字符*/
      text-indent: 2em;
      /*设置字符间距*/
      letter-spacing: 10px;
    }
  </style>
</head>
<body>
  <div id="d1">
    江苏万和计算机培训中心创立于1993年，是江苏省成立最早、规模最大的IT教育专业机构。二十多年来一直坚持不懈的努力做好IT教育，通过规范化、标准化、专业化服务流程实施，硕果斐然，已成功为社会培养各类中高级专业技术人才超过100000人，被誉为江苏省国际服务外包人才培训基地、南京市国际服务外包人才培训机构及南京市软件人才培训基地，中国十大IT培训品牌之一！
  </div>
</body>
```

# 9、链接样式

- 链接有四种伪状态

```
a:link - 普通的、未被访问的链接 
a:visited - 用户已访问的链接 
a:hover - 鼠标指针位于链接的上方 
a:active - 链接被点击的时刻 
```

```
# 清除浏览器缓存的快捷键：ctrl + shift   delete
```

```html
<head>
  <style>
    /*需求：把链接改成一下要求（没有访问过的时候是深灰色，鼠标放在上面是蓝色，鼠标点击的时候是红色，访问过的连接变为淡灰色）*/

    /*a:link - 普通的、未被访问的链接   "深灰色#555"  */
    /*a:visited - 用户已访问的链接*   "淡灰色#eee"/
    /*a:hover - 鼠标指针位于链接的上方 "蓝色blue"*/
    /*a:active - 链接被点击的时刻    "红色red" */
    a {
      text-decoration: none;
    }
    a:link{
      color: #555;
    }
    a:visited{
      color: #eee;
    }
    a:hover{
      color: blue;
    }
    a:active{
      color: red;
    }
  </style>
</head>
<body>
  <a href="https://www.baidu.com/">百度</a>
  <a href="https://www.taobao.com/">淘宝</a>
</body>
```

- 注意点：四种状态有顺序

```
a:hover 必须位于 a:link 和 a:visited 之后 
a:active 必须位于 a:hover 之后 

记忆技巧：lv-hao
```

# 10、背景

- 背景色

```
background-color 设置元素的背景颜色。
```

- 背景图片

```
background 在一个声明中设置所有的背景属性。 
background-image 设置元素的背景图像。 
background-position 设置背景图像的开始位置。 
background-repeat 设置是否及如何重复背景图像。 
background-size 规定背景图片的尺寸。
```

```html
<head>
  <style>
    div {
      height: 200px;
      width: 500px;
      border: 3px solid #ccc;
    }
    #d1 {
      /*简写背景色写法*/
      /*background: yellowgreen;*/
      /*标准背景色写法*/
      background-color: deepskyblue;
    }
    #d2{
      font-size: 80px;
      /*设置背景图片*/
      background-image: url("./img/bg.gif");
      /*背景图片不重复*/
      background-repeat: no-repeat;
      /*设置背景图片的位置:距离左边50px(向右),距离上边100px(向下移)*/
      background-position: 50px 100px;
    }
    #d3{
      font-size: 80px;
      /*背景图片的简写*/
      background: url("./img/bg.gif") no-repeat 50px 100px;
    }
    #d4{
      font-size: 80px;
      /*背景图片的简写*/
      background: url("./img/bg.gif") no-repeat 0px 0px;
      /*设置背景图片的大小*/
      background-size: 100% 100%;
    }
  </style>
</head>
<body>
  <div id="d1"></div>
  <div id="d2">设置背景图片</div>
  <div id="d3">设置背景图片</div>
  <div id="d4">设置背景图片</div>
</body>
```

# 11、列表样式

- 去除无序列表中的点
- 通过列表样式，用图片代替无序列表的点

```html
<head>
  <style>
    ul{
      /*设置无序列表的小点点：disc、none、square、circle*/
      /*list-style: none;*/

      /*用图片代替列表样式*/
      list-style-image: url("./img/bg.gif");
    }
  </style>
</head>
<body>
  <ul>
    <li>苹果</li>
    <li>芒果</li>
    <li>百香果</li>
    <li>奇异果</li>
    <li>火龙果</li>
    <li>牛油果</li>
  </ul>
</body>
```






























