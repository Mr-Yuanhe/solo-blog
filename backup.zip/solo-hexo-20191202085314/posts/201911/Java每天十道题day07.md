title: Java每天十道题 - day07
date: '2019-11-11 13:49:41'
updated: '2019-11-19 13:47:13'
tags: [Java-每天十道题, Java面试题]
permalink: /articles/2019/11/11/1573451381102.html
---
## 1.如何自定义异常

- 为什么要自定义异常：
```
1.首先，在工作中，项目是分模块或者分功能开发的，不会一个人开发一整个项目，使用自定义异常就统一了对外异常展示的方式。

2.有时候我们遇到需要校验或者问题时，需要直接结束掉当前的请求，这时可以通过抛出自定义异常来处理。

3.自定义异常可以在我们项目中某些特殊业务逻辑中使用，比如性别中"性".equals(sex)，性别等于中性时我们要抛出异常，而Java是不会有这种异常的。这种异常符合java语法，但是不符合我们的规范，所以需要进一步编辑。

4.自定义异常继承相关的异常来抛出处理后的异常信息可以隐藏底层的异常，更安全。
比如：抛出空指针异常时，可以抛出**为空，不需要抛出堆栈信息。
```
- 如何使用：
```
1.所有异常都是Throwable的子类

2.如果希望写一个检查性异常类，则需要继承Exception类

3.如果写一个运行时异常，需要继承RuntimeException
```

## 2.protected与默认的有什么区别

- 1.对类而言：

> public、对所有包中均可见
> default、只在该类所在的包可见
> 类不能用protected、private修饰

- 2.对成员变量和方法而言：

> public：对所有包均可见
> protected：包内所有类均可见
> private:只在同一个类中可见(且可调用)
> default(默认)

>protected修饰限定符的作用意义，,和private一样具有保护属性和方法的作用,但是它和private稍有不同,通俗的说,它提供了给外部包中的类访问的机会,相应地增加了程序之间的联系,提供了更多样的方

```
  注意：在同一个包中，尽管是protected的方法和属性，包内的任何类都可以访问到。 在父类和子类不在同一包的前提下，对于子类来说，子类继承了父类所有的方法和属性(任何访问修饰符)，虽然对从父类继承的protected的属性和方法可见，但是只能在子类的内部进行访问，即：(this.)方法名、(this.)属性名进行访问和操作，而无法再外部对子类进行实例化，并用子类对象.protected方法或属性访问。
```

## 3.接口当中有什么都是默认的

```
1.接口中成员变量默认都是public、static、final类型，必须被显式初始化
2.接口中的方法默认为public、abstract类型
3.接口中没有构造方法，不能被实例化，在接口中定义构造方法是非法的
4.一个接口不能实现另一个接口，但是可以继承多个接口
5.接口没有方法体
6.为类实现某个接口时，它必须实现接口中所有的抽象方法，否则这个类必须定义为抽象类
```

## 4.oracle当中如何创建用户.修改密码.锁住用户以及解锁用户

```sql
创建用户：create user 用户名 identified by "密码"

修改密码：alter user user01 identified by user10;

锁定用户：alter user test account lock

解锁用户；alter user test account unlock;
```

## 5.如何拷贝一张表的结构与其中的数据

```sql
拷贝表结构：
create table B like A;
create table B as select * from A where 1=2;

复制数据：
原表存在：insert into A select * from B
不存在 ：create table 新表名 as select * from 旧表名;
```


## 6.jsp当中的内置对象有哪些

1.request对象：
```
代表客户端请求信息，主要接收通过HTTP协议到服务器的数据，作用域是一次请求
```
2.response对象：
```
代表客户端的响应，将Jsp容器处理过的对象传到客户端，作用域：Jsp页面有效
```
3.Session对象：
```
由服务器自动创建的与用户请求相关的对象，服务器为每个用户都生成一个session对象，用于保存该用户的信息，跟踪用户的操作状态。session对象内部使用Map类来保存数据，因此保存数据的格式为 “Key/value”。 session对象的value可以使复杂的对象类型，而不仅仅局限于字符串类型。
```
4.application对象：
```
application 对象可将信息保存在服务器中，直到服务器关闭，否则application对象中保存的信息会在整个应用中都有效。类似于系统的"全局变量"
```
5.out 对象：
```
out 对象用于在Web浏览器内输出信息，并且管理应用服务器上的输出缓冲区。待数据输出完毕后，要及时关闭输出流。
```
6.pageContext 对象：
```
pageContext 对象的作用是取得任何范围的参数，通过它可以获取 JSP页面的out、request、reponse、session、application 等对象。pageContext对象的创建和初始化都是由容器来完成的，在JSP页面中可以直接使用 pageContext对象。
```
7.config 对象：
```
config 对象的主要作用是取得服务器的配置信息。通过 pageConext对象的 getServletConfig() 方法可以获取一个config对象。开发者可以在web.xml 文件中为应用程序环境中的Servlet程序和JSP页面提供初始化参数。
```
8.page 对象：
```
page 对象代表JSP本身，只有在JSP页面内才是合法的。 page隐含对象本质上包含当前 Servlet接口引用的变量，类似于Java编程中的 this 指针。
```
9.exception 对象：
```
exception 对象的作用是显示异常信息，只有在包含 isErrorPage="true" 的页面中才可以被使用，在一般的JSP页面中使用该对象将无法编译JSP文件。
```

## 7.常用的监听器有哪些

常用接口：
```java
ServletContextListener
ServletContextAttributeListener
ServletRequestListener
ServletRequestAttributeListener
HTTPSessionListener
HTTPSessionAttributeListener
HTTPSessionActivationListener
HTTPSessionBindingListener
```
种类：

Log4jConfigListener：
```
Spring提供，本身就能通过web.xml中配置来指定位置加载log4j配置文件和log输出路径，但是该 listener需要放在spring的Listener之前
```
ContextLoaderListener：
```
启动Web容器时，自动装配ApplicationContext的配置信息。
```

## 8.如何完成自定义标签
```
1.定义一个继承SimpleTagSupport类的子类，重写doTag()方法
2.定义一个tld文件，将文件放在WEB-INF目录下，容器在加载时会自动加载
3.前台JSP页面中以taglib的形式引入自定义的标签，进行使用

注：如果需要在标签中加入属性，需要在标签的实现类中为每个属性加入getter,setter方法，并在tld文件的<tag>标签中加入<attribute>标签
```

## 9.项目流程有哪些

```
可行性分析 --> 项目立项 --> 需求分析 --> 概要设计 --> 详细设计 --> 编码 --> 单元测试 --> 系统测试 --> 集成测试 --> 验收测试 --> 项目上线
```


## 10.spring生命周期

```
singleton
prototype
request
session
global-session
```

```
1.实例化。Spring通过new关键字将一个Bean进行实例化，JavaBean都有默认的构造函数，因此不需要提供构造参数。
2.填入属性。Spring根据xml文件中的配置通过调用Bean中的setXXX方法填入对应的属性。 
3.事件通知。Spring依次检查Bean是否实现了BeanNameAware、BeanFactoryAware、ApplicationContextAware、BeanPostProcessor、InitializingBean接口，如果有的话，依次调用这些接口。
4.使用。应用程序可以正常使用这个Bean了。
5.销毁。如果Bean实现了DisposableBean接口，就调用其destroy方法。
```
