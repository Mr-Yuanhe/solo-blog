title: Java每天十道题 - day11
date: '2019-11-15 13:43:15'
updated: '2019-11-15 13:43:15'
tags: [Java-每天十道题, Java面试题, Java笔记, Java]
permalink: /articles/2019/11/15/1573796595273.html
---
## 1.什么是对象的上转型？

```
把子类的对象赋给父类的引用，用这个引用去调用方法，真正执行的是子类里面已经重写的方法。这就是对象的上转型，多态的一个体现。
```

## 2.什么是接口回调

```
可以把实现某一接口的类创建的对象的引用赋值给该接口声明的接口变量，那么该接口变量就可以调用被类实现的接口方法。不同的类在实现同一个接口时可能具有不同的实现方式，那么接口变量就在回调接口方法时可能具有多种形态。
```

## 3.为什么匿名类也能说成是多态的体现

```
java不允许多继承，但是允许接口多实现。在接口之外，我们可以使用多个匿名类来完成类似的多态的效果，同一个接口有不同的实现。
```

## 4.简述一下垃圾回收器

```
java中有构造函数，没有析构函数。java中回收内存是用垃圾回收器gc。当一个对象没有被引用指向时，这个对象就成为被回收的对象，但并不会被马上回收，因为gc的执行频率取决于当前java虚拟机空闲内存的大小，如果java虚拟机还有很多内存，那么gc不会执行，如果java虚拟机内存已经很紧张，则gc会高频率执行。
```

## 5.什么是泛型

```
集合具备可变长度这一特性，但是集合中可以放入任意类型的对象，即放入的对象在重新取出来时，会变成Object，把Object变成它之前的类型，需要强转，而强转是有风险的。因此引入泛型，约束了这个集合中只能存储这种类型。泛型是一种安全机制。
```

## 6.什么是AOP?通常用来做什么事情？解释切面（aspect）、连接点(Joinpoint)、通知(advice)、切入点(pointcut)、目标对象(target object)、AOP代理(aop proxy)、织入(weaving)

```
AOP是面向切面编程，也就是说面向某个功能模块编程，AOP适合于具有横切逻辑的应用：性能监测，访问控制，事务管理、缓存、对象池管理以及日志记录。
```
```
1.切面（aspect）：横切关注点被模块化的对象---功能模块化组成的对象；

2.连接点（Joinpoint）：就是程序执行的某个特定位置，例如方法前方法后，也是通知所关心的位置；

3.通知（advice）：就是切面需要完成的功能---就是功能的实现方法；

4.切入点(pointcut) ：符合切点表达式的连接点，也就是真正被切入的地方；

5.目标对象（target object）：被通知的对象，也是连接点所在的对象；

6.AOP代理(aop proxy): 向目标对象应用通知之后创建的对象；

7.织入(weaving)：织入是将增强添加到目标类具体连接点上的过程
```

## 7.通知类型有哪些？Around有什么特殊之处

```
1.前置通知[Before advice]：在连接点前面执行，前置通知不会影响连接点的执行，除非此处抛出异常。

2.返回通知[After (finally) advice]：在连接点执行完成后执行，不管是正常执行完成，还是抛出异常，都会执行返回通知中的内容。

3.正常返回通知[After returning advice]：在连接点正常执行完成后执行，如果连接点抛出异常，则不会执行。

4.异常返回通知[After throwing advice]：在连接点抛出异常后执行。

5.环绕通知[Around advice]：表示包围一个函数，也就是可以在函数执行前做一些事情，也可以在函数执行后做一些事情

环绕通知的方法的参数是ProcedingJoinpoint类型，用来调用proceed()方法。
```

## 8.JdbcTemplate的用法是什么？

```
JDBC（Java DataBase Connectivity,java数据库连接）是一种用于执行SQL语句的Java API，可以为多种关系数据库提供统一访问，它由一组用Java语言编写的类和接口组成，
而JDBCTemplate就是Spring对JDBC的封装,通俗点说就是Spring对jdbc的封装的模板。
```

```sql
1.查询一行数据并返回int型结果
    jdbcTemplate.queryForInt("select count(*) from test"); 
2.查询一行数据并将该行数据转换为Map返回
    jdbcTemplate.queryForMap("select * from test where name='name5'");
3.查询一行任何类型的数据，最后一个参数指定返回结果类型  
    jdbcTemplate.queryForObject("select count(*) from test", Integer.class);  
4.查询一批数据，默认将每行数据转换为Map       
    jdbcTemplate.queryForList("select * from test");  
5.只查询一列数据列表，列类型是String类型，列名字是name  
    jdbcTemplate.queryForList("select name from test where name=?", new Object[]{"name5"}, String.class);  
6.查询一批数据，返回为SqlRowSet，类似于ResultSet，但不再绑定到连接上  
    SqlRowSet rs = jdbcTemplate.queryForRowSet("select * from test");  
```

## 9.springmvc中如何处理静态资源？为什么要处理静态资源？

```
1.激活Tomcat的defaultServlet来处理静态文件

<Servlet-Mapping>
    <Servlet-name>default</>
    <url-patting>*.css</>
</Servlet-Mapping>

2. 在spring3.0.4以后版本提供了
<mvc:resources >

3.使用
<mvc:default-servlet-handler/>

 如果不处理静态资源，那么会因为”<url-pattern>/<url-pattern>“的存在而让所有的静态资源都出现404错误。
```

## 10.如何接受前台传过来的“201-7-7”.并且把它转化为Date类型？

```
@initBinder
public void initBinder(WebDataBinder binder){
    SimpleDateFormate sdf=new SimpleDateFormate("yyyy-MM-dd"); 
    //true表示允许空值，false不允许
    binder.registerCustomEditor(Date.class,new CustomDateEditor(sdf,true));
}
```

