title: Java每天十道题 - day10
date: '2019-11-14 23:39:14'
updated: '2019-11-19 13:46:57'
tags: [Java-每天十道题, Java面试题]
permalink: /articles/2019/11/14/1573745954174.html
---
## 1.jsp与html的区别是什么

- 概述
```
HTML（Hypertext Markup Language）文本标记语言，它是静态页面，和JavaScript一样解释性语言。
JSP（Java Server Page）是Java服务端的页面，所以它是动态的，它是需要经过JDK编译后把内容发给客户端去显示，我们都知道，Java文件编译后会产生一个class文件，最终执行的就是这个class文件，JSP也一样，它也要编译成class文件！JSP不止要编译，它还得要转译，首先把JSP转译成一个Servlet文件，然后在编译成class文件，最终执行的就是这个class文件
```
- 区别
```
1.最简单的区别就是，HTML能直接打开，jsp只能发布到Tomact等服务器上才能打开  
2.定义上HTML页面是静态页面可以直接运行，JSP页面是动态页它运行时需要转换成servlet  
3.他们的表头不同，这个是JSP的头“ <%@ page language="java" import="java.util.*" pageEncoding="gbk"%>”在表头中有编码格式和导入包等  
4.也是很好区分的在jsp中用<%%>就可以写Java代码了，而html没有<%%>
```
## 2.jsp的指令有哪些

```
1.page指令：用于设定整个JSP页面的属性和相关功能
    语法结构：<%page %>
2.include指令：表示在JSP编译时插入一个包含文件或者代码的文件，是一种静态包含 
    语法结构：<%include file=" "%>:file中添加我们要引入文件的url。
3.taglib指令：声明JSP文件使用了标签库
    语法结构：<%@taglib uri="" prefix="">
```

## 3.中文乱码有哪些解决方式

![clipboard.png](https://img.hacpai.com/file/2019/11/clipboard-db93df52.png)

```
还可以在tomcat的server.xml中的Connector标签增加属性URIEncoding="UTF-8"
```

## 4.el表达式与spel的区别

- EL 全名为Expression Language。EL主要作用：

```
1.获取数据
    EL表达式主要用于替换JSP页面中的脚本表达式，以从各种类型的web域 中检索java对象、获取数据。(某个web域 中的对象，访问javabean的属性、访问list集合、访问map集合、访问数组)
2.执行运算
    利用EL表达式可以在JSP页面中执行一些基本的关系运算、逻辑运算和算术运算，以在JSP页面中完成一些简单的逻辑运算。${user==null}
3.获取web开发常用对象
    EL 表达式定义了一些隐式对象，利用这些隐式对象，web开发人员可以很轻松获得对web常用对象的引用，从而获得这些对象中的数据。
4.调用Java方法    EL表达式允许用户开发自定义EL函数，以在JSP页面中通过EL表达式调用Java类的方法。
````

- spring3.0引入了spring expression language(spel)语言,通过spel我们可以实现

```
1.通过bean的id对bean进行引用
2.调用方法以及引用对象中的属性
3.计算表达式的值
4.正则表达式的匹配
5.集合的操作
```

## 5.maven的作用

```
进行项目管理（清理、编译、测试、打包、发布）、依赖管理以及一些插件的使用例如tomcat
```

## 6.JSR303与Hibernate Validator的区别和联系

```
1.JSR303是java为Bean数据合法性校验提供的一个标准规范，是一个运行时的数据校验框架，在验证后会存错误信息马上返回。例如 Min,Max，Length等

2.Hibernate Validator是JSR303的一个参考实现，除了支持所有标准的校验注解之外，还扩展了一些注解校验。例如Email
```

## 7.spring中异常处理有哪些方式

```
1.@ResponseStatus :
    SpringMVC中@ExceptionHandler注解用来处理异常，我们使用这个注解来标注controller方法。
2.@ExceptionHandler :
    @ResponseStatus可以用在定义的类或者controller方法上，它包含两个元素，value和reason。Value用于设置response的状态码，例如404,200等，reason用于响应，可以是内容语句。
3.HandlerExceptionResolver :
    HandlerExceptionResolver是各个执行时异常处理的接口，可以进行全局的异常控制
4.@ControllerAdvice处理异常：
    @ControllerAdvice注解是在classpath扫描时自动检测的，java配置时我们须要使用@EnableWebMvc。Spring中使用@ControllerAdvice与@ExceptionHandler做全局异常处理，使用@ControllerAdvice注解定义的类，@ExceptionHandler注解定义类中的方法。
<errorpage>
```

## 8.静态资源有哪些？springmvc如何处理

> html,js,css,image，tfl等
```
1.激活Tomcat的defaultServlet来处理静态文件
<Servlet-Mapping>
         <Servlet-name>default</>
         <url-patting>*.css</>
</Servlet-Mapping>
2. 在spring3.0.4以后版本提供了<mvc:resources 
3.使用<mvc:default-servlet-handler/>
```

## 9.restful的意义

```
1.每一个URI代表一种资源；
2.客户端和服务器之间，传递这种资源的某种表现层；
3.客户端通过四个HTTP动词(put,get,post,delete)，对服务器端资源进行操作，实现"表现层状态转化"。
```

## 10.外部属性文件的好处是什么？截止目前.我们学过哪些外部文件可以引入

```
在Spring配置文件中配置数据源或邮件服务器等资源数据时，会直接把账号密码直接写在配置文件中，一种更好的做法是把这些配置信息独立到一个外部属性文件中，并在Spring文件中通过${username}这样的方式来引用属性文件中的属性项。  
```
 - 好处：
```
一是如果多个应用公用一个资源配置信息，一旦资源信息修改，只需要修改属性文件一处，而不用修改多处Spring配置文件。
二是维护和部署方便，如果需要修改某个参数，不需要关注结构复杂信息量大的Spring配置文件 
```
- 常用的外部文件
```
    db.properties
    log4j.properties
    jdbc.properties
```
