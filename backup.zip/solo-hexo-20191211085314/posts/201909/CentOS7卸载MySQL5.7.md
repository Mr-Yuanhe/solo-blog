title: CentOS 7 卸载MySQL 5.7
date: '2019-09-16 14:50:52'
updated: '2019-09-16 14:50:52'
tags: [Linux, MySQL]
permalink: /articles/2019/09/16/1568616652854.html
---
1. 查看mysql 安装了哪些东西
```
rpm  -qa | grep -i mysql
```
如果返回空值，说明没有安装mysql  
若返回如下情况，说明存在mysql

![image.png](https://img.hacpai.com/file/2019/09/image-cfacba2c.png)

2.卸载
```
yum  remove mysql-community-libs-5.7.27-1.el7.x86_64
yum  remove mysql -community-server-5.7.27-1.el7.x86_64                                                                               
yum  remove mysql57-community-release-el7-8.noarch                                                                                   
yum  remove mysql-community-common-5.7.27-1.el7.x86_64                                                                               
yum  remove mysql-community-client-5.7.27-1.el7.x86_64                                                                               
yum  remove mysql-community-libs-compat-5.7.27-1.el7.x86_64
```

3. 查看是否卸载干净

```
rpm  -qa | grep -i mysql
```

4. 查找mysql 的目录
```
find  / -name mysql
```
![image.png](https://img.hacpai.com/file/2019/09/image-d069827c.png)

5. 删除
```
rm  -rf /etc/logrotate.d/mysql
rm  -rf /etc/selinux/targeted/active/modules/100/mysql
rm  -rf /var/lib/mysql
rm  -rf /var/lib/mysql/mysql
rm  -rf /usr/bin/mysql
rm  -rf /usr/lib64/mysql
rm  -rf /usr/share/mysql
rm  -rf /usr/local/mysql
```

6. 注意：卸载后 /etc/my.cnf 不会删除，需要进行手工删除

```
rm  -rf /etc/my.cnf
```

7. 删除 /var/log/mysqld.log（如果不删除这个文件，会导致新安装的 mysql 无法生存新密码，导致无法登陆）

```
rm -rf /var/log/mysqld.log
```
卸载完成，安装教程在这[CentOS 7 安装 MySQL 5.7](http://106.54.54.131/articles/2019/09/16/1568611730681.html)
