title: 'Java整合FreeMarker '
date: '2019-12-08 20:02:10'
updated: '2019-12-08 20:19:54'
tags: [Java]
permalink: /articles/2019/12/08/1575806530476.html
---
# 1. FreeMarker介绍

- FreeMarker是一款模板引擎： 即一种基于**模板**和**数据模型**，生成输出文本（HTML网页、电子邮件、配置文件、源代码等）的通用技术。

- FreeMarker是免费的，基于Apache许可证2.0版本发布。其模板编写为FreeMarker Template Language（FTL）。

  ![](img/_image4.png)

# 2. 模板+数据模型=输出

- 来自官方的例子：(https://freemarker.apache.org/docs/dgui_quickstart_basics.html) 

  - 数据模型：

    ![](http://yuanheweb.com/img/freemarker/_image5.png)

  - 模板：

    ![](http://yuanheweb.com/img/freemarker/_image6.png)

  - 输出：

    ![](http://yuanheweb.com/img/freemarker/_image7.png)

# 

# 3.  FreeMarker快速入门

- 需要创建Spring Boot+Freemarker工程用于测试模板。

## 3.1 创建测试工程

创建一个test-freemarker 的测试工程专门用于freemarker的功能测试与模板的测试。

pom.xml如下

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>2.1.9.RELEASE</version>
        <relativePath/> <!-- lookup parent from repository -->
    </parent>
    <groupId>net.wanho</groupId>
    <artifactId>008_springboot_freemarker</artifactId>
    <version>1.0</version>
    <packaging>war</packaging>
    <name>008_springboot_freemarker</name>
    <description>Demo project for Spring Boot</description>

    <properties>
        <java.version>1.8</java.version>
    </properties>

    <dependencies>
<!--        FreeMarker-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-FreeMarker</artifactId>
        </dependency>

<!--        web-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>

<!--        lombok-->
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
            <scope>provided</scope>
        </dependency>

<!--        tomcat-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-tomcat</artifactId>
            <scope>provided</scope>
        </dependency>

<!--        test-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
            <exclusions>
                <exclusion>
                    <groupId>org.junit.vintage</groupId>
                    <artifactId>junit-vintage-engine</artifactId>
                </exclusion>
            </exclusions>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>

</project>

```

## 3.2.  application.yml和logback.xml

- application.yml

```yaml
server:
  port: 8088
spring:
  FreeMarker:
    cache: false
    settings:
      template_update_delay: 0

```

- logback.xml拷贝之前项目

## 3.3. po类

```java
@Data
@ToString
public class Student {
    private String name;//姓名
    private int age;//年龄
    private Date birthday;//生日
    private Float money;//钱包
    private List<Student> friends;//朋友列表
    private Student bestFriend;//最好的朋友
} 
```

## 3.4. 创建模板

在 src/main/resources下创建templates，此目录为FreeMarker的默认模板存放目录。 在templates下创建模板文件test1.ftl，模板中的${name}最终会被FreeMarker替换成具体的数据。

```html
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Hello World!</title>
</head>
<body>
		Hello ${name}!
</body>
</html>  
```

## 3.5. 创建controller

创建Controller类，向Map中添加name，最后返回模板文件。

```java
@RequestMapping("/FreeMarker")
@Controller
public class FreemarkerController {
  	@RequestMapping("/test1")
    public String FreeMarker(Map<String, Object> map){
        //向数据模型放数据
        map.put("name","万和在线");
        return "test1";
    }
}
```

## 3.6. 创建启动类

```java
@SpringBootApplication
public class FreemarkerTestApplication {
  public static void main(String[] args) {
    SpringApplication.run(FreemarkerTestApplication.class,args);
  } 
}
```

## 3.7.  测试

请求：http://localhost:8088/FreeMarker/test1

屏幕显示：Hello 万和在线!

# 4. FreeMarker基础

## 4.1. 核心指令

### 4.1.1.  数据模型

FreeMarker静态化依赖数据模型和模板，下边定义数据模型： 下边方法形参map即为FreeMarker静态化所需要的数据模型，在map中填充数据：

```java
Student stu1 = new Student();
stu1.setName("小明");
stu1.setAge(18);
stu1.setMondy(1000.86f);
stu1.setBirthday(new Date());

Student stu2 = new Student();
stu2.setName("小红");
stu2.setMondy(200.1f);
stu2.setAge(19);
//        stu2.setBirthday(new Date());

List<Student> friends = new ArrayList<>();
friends.add(stu1);
stu2.setFriends(friends);
stu2.setBestFriend(stu1);

List<Student> stus = new ArrayList<>();
stus.add(stu1);
stus.add(stu2);

//向数据模型放数据
map.put("stus",stus);

//准备map数据
HashMap<String,Student> stuMap = new HashMap<>();
stuMap.put("stu1",stu1);
stuMap.put("stu2",stu2);

//向数据模型放数据
map.put("stu1",stu1);

//向数据模型放数据
map.put("stuMap",stuMap);

//返回模板文件名称
return "test1";
```

### 4.1.2. List指令

本节定义FreeMarker模板，模板中使用FreeMarker的指令，关于FreeMarker的指令需要知道：

1、注释，即`<#-- 注释内容 -->`，介于其之间的内容会被FreeMarker忽略 

2、插值(Interpolation):即`${..}`部分,FreeMarker会用真实的值代替${..} 

3、FTL指令:和HTML标记类似，名字前加#予以区分，FreeMarker会解析标签中的表达式或逻辑。 

4、文本，仅文本信息，这些不是FreeMarker的注释、插值、FTL指令的内容会被FreeMarker忽略解析，直接输出内 容。

在test1.ftl模板中使用list指令遍历数据模型中的数据：

```html
<table>
    <tr>
        <td>序号</td>
        <td>姓名</td>
        <td>年龄</td>
        <td>钱包</td>
    </tr>
    <#list stus as stu>
        <tr>
            <td>${stu_index + 1}</td>
            <td <#if stu.name =='小明'>style="background:red;"</#if>>${stu.name}</td>
            <td>${stu.age}</td>
            <td >${stu.mondy}</td>
        </tr>
    </#list>

</table>
```

3、输出：

```java
序号	姓名		年龄		钱包
1		小明（红）18		1,000.86
2		小红		19		200.1
```

说明: 
`_index`:得到循环的下标，使用方法是在stu后边加"_index"，它的值是从0开始

### 4.1.3. 遍历Map数据

1、数据模型 

使用map指令遍历数据模型中的stuMap。 

2、模板

```html
输出map中stu1的学生信息：<br/>
姓名：${stuMap['stu1'].name}<br/>
年龄：${stuMap['stu1'].age}<br/>

输出map中stu1的学生信息：<br/>
姓名：${stuMap.stu1.name}<br/>
年龄：${stuMap.stu1.age}<br/>

遍历map输出两个学生信息：<br/>
<table>
    <tr>
        <td>序号</td>
        <td>姓名</td>
        <td>年龄</td>
        <td>钱包</td>
    </tr>
<#list stuMap?keys as k>
<tr>
    <td>${k_index + 1}</td>
    <td>${stuMap[k].name}</td>
    <td>${stuMap[k].age}</td>
    <td >${stuMap[k].mondy}</td>
</tr>
</#list>
</table>
</br>
```

3、输出

```html
输出map中stu1的学生信息：
姓名：小明
年龄：18
输出map中stu1的学生信息：
姓名：小明
年龄：18
遍历map输出两个学生信息：
序号	姓名	年龄	钱包
1	小红	19	200.1
2	小明	18	1,000.86
```

### 4.1.4. if指令

if 指令即判断指令，是常用的FTL指令，FreeMarker在解析时遇到if会进行判断，条件为真则输出if中间的内容，否 则跳过内容不再输出。

1、数据模型： 

使用list指令中测试数据模型。 

2、模板：

```html
<table>
    <tr>
        <td>序号</td>
        <td>姓名</td>
        <td>年龄</td>
        <td>钱包</td>
    </tr>
    <#list stus as stu>
        <tr>
            <td>${stu_index + 1}</td>
            <td <#if stu.name =='小明'>style="background:red;"</#if>>${stu.name}</td>
            <td>${stu.age}</td>
            <td <#if (stu.money > 3000)>style="background:red;"</#if>>${stu.money}</td>
        </tr>
    </#list>
</table>
```

通过阅读上边的代码，实现的功能是：如果姓名为"小明"则背景色显示为红色

## 4.2. 其它指令

### 4.2.1. 运算符

1、算数运算符 

FreeMarker表达式中完全支持算术运算,FreeMarker支持的算术运算符包括:+, - , * , / , % 

2、逻辑运算符 

逻辑运算符有如下几个: 逻辑与:&& 逻辑或:|| 逻辑非:! 

3、 比较运算符 

表达式中支持的比较运算符有如下几个: 

1 =或者==:判断两个值是否相等. 

2 !=:判断两个值是否不等. 

3 >或者gt:判断左边值是否大于右边值 

4 >=或者gte:判断左边值是否大于等于右边值 

5 <或者lt:判断左边值是否小于右边值 

6 <=或者lte:判断左边值是否小于等于右边值

### 4.2.2. 空值处理

1、判断某变量是否存在使用 "??" 用法为:variable??,如果该变量存在,返回true,否则返回false 例：为防止stus为空报错可以加上判断如下：

```html
<#if stus??>
    <#list stus as stu>
           ......
    </#list>
</#if>
```

2、缺失变量默认值使用 "!" 使用

!要以指定一个默认值，当变量为空时显示默认值。 例： ${name!''}表示如果name为空显示空字符串。

如果是嵌套对象则建议使用（）括起来。

例： ${(stu.bestFriend.name)!''}表示，如果stu或bestFriend或name为空默认显示空字符串。

### 4.2.3. 内建函数

内建函数语法格式： 变量+?+函数名称

1、和到某个集合的大小

```java
${集合名?size}
```

 2、日期格式化

```html
显示年月日: ${today?date} 
显示时分秒:${today?time} 
显示日期+时间:${today?datetime} <br> 
自定义格式化: ${today?string("yyyy年MM月")}
```

3、内建函数c 

map.put("point", 102920122);point是数字型，使用${point}会显示这个数字的值，不并每三位使用逗号分隔。 如果不想显示为每三位分隔的数字，可以使用c函数将数字型转成字符串输出

```java
${point?c}
```

4、eval将json字符串转成对象 一个例子：

其中用到了 assign标签，assign的作用是定义一个变量。

```php+HTML
<#assign str="{'bank':'工商银行','account':'10101920201920212'}" />
<#assign jsonObject=str?eval />
开户行:${jsonObject.bank} 账号:${jsonObject.account}
```

### 4.2.4. 完整的模板

上边测试的模板内容如下，可自行进行对照测试。

```html
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Hello World!</title>
</head>
<body>
Hello ${name}!
<br/>
<table>
    <tr>
        <td>序号</td>
        <td>姓名</td>
        <td>年龄</td>
        <td>钱包</td>
    </tr>
    <#list stus as stu>
        <tr>
            <td>${stu_index + 1}</td>
            <td <#if stu.name =='小明'>style="background:red;"</#if>>${stu.name}</td>
            <td>${stu.age}</td>
            <td >${stu.mondy}</td>
        </tr>
    </#list>

</table>
<br/><br/>
输出map中stu1的学生信息：<br/>
姓名：${stuMap['stu1'].name}<br/>
年龄：${stuMap['stu1'].age}<br/>

输出map中stu1的学生信息：<br/>
姓名：${stuMap.stu1.name}<br/>
年龄：${stuMap.stu1.age}<br/>

遍历map输出两个学生信息：<br/>
<table>
    <tr>
        <td>序号</td>
        <td>姓名</td>
        <td>年龄</td>
        <td>钱包</td>
    </tr>
<#list stuMap?keys as k>
<tr>
    <td>${k_index + 1}</td>
    <td>${stuMap[k].name}</td>
    <td>${stuMap[k].age}</td>
    <td >${stuMap[k].mondy}</td>
</tr>
</#list>
</table>
</br>

输出stu1的学生信息：<br/>
姓名：${stu1.name}<br/>
年龄：${stu1.age}<br/>
<table>
    <tr>
        <td>姓名</td>
        <td>年龄</td>
        <td>出生日期</td>
        <td>钱包</td>
        <td>最好的朋友</td>
        <td>朋友个数</td>
        <td>朋友列表</td>
    </tr>
    <#if stus??>
    <#list stus as stu>
        <tr>
            <td>${stu.name!''}</td>
            <td>${stu.age}</td>
            <td>${(stu.birthday?date)!''}</td>
            <td>${stu.mondy}</td>
            <td>${(stu.bestFriend.name)!''}</td>
            <td>${(stu.friends?size)!0}</td>
            <td>
                <#if stu.friends??>
                    <#list stu.friends as firend>
                        ${firend.name!''}<br/>
                    </#list>
                </#if>
            </td>
        </tr>
    </#list>
    </#if>

</table>
<br/>
<#assign text="{'bank':'工商银行','account':'10101920201920212'}" />
<#assign data=text?eval />
开户行：${data.bank}  账号：${data.account}
</body>
</html>
```






















