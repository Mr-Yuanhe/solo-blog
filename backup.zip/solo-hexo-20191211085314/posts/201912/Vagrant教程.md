title: Vagrant教程
date: '2019-12-04 19:50:39'
updated: '2019-12-09 17:29:24'
tags: [Linux, 安装教程]
permalink: /articles/2019/12/04/1575460239079.html
---
# 1. Vagrant 简介概述

## 1.1. Vagrant 简介

- Vagrant 是一个用来**构建和管理虚拟机环境**的工具，为了方便的实现虚拟化环境而设计的，使用 Ruby 开发，

  提供了一个可配置、轻量级的便携式虚拟开发环境。

- Vagrant 运行需要**依赖**某项具体的**虚拟化技术**，最常见的有**VirtualBox以及VMWare**两款，早期，Vagrant只

  支持VirtualBox，后来才加入了VMWare的支持。

# 2. 准备工作，安装Virtual Box

下载地址：<https://www.virtualbox.org/wiki/Downloads>

## 2.1. windows安装方式

安装过程很简单，傻瓜式的一步一步点下去。

# 3. 准备工作，安装Vagrant

下载地址：<https://www.vagrantup.com/downloads.html>

## 3.1. windows安装方式

安装过程依旧没什么难的，跟着提示一步一步next。

# 4. 通过vagrant安装centos7虚拟机

## 4.1. 打开cmd窗口，测试vagrant是否成功

```shell
# 查看vagrant版本
vagrant -v 
```

## 4.2. 查看当前系统中拥有的box

```shell
# 查看box列表,查看结果为空
vagrant box list  
```

## 4.3. 下载box

```shell
# 在线下载，速度非常慢
vagrant box add centos/7
```

## 4.4. 挂载已经下载好box

```shell
vagrant box add centos7(box起个名) 
路径/名称.box  （注意这个是/不是\）
# 查看box列表,查看结果为挂载好的版本
vagrant box list  
```

## 4.5. 初始化

```shell
cd d:/vagrant
vagrant init
# 会创建一个名称为Vagrantfile文件
```

## 4.6. 编加Vagrantfile

```shell
Vagrant.configure("2") do |config|

 # 定义redis服务器
  config.vm.define :redis do |redis|
  	# 使用基于virtualbox虚拟化
    redis.vm.provider "virtualbox" do |v|
          v.customize ["modifyvm", :id, "--name", "redis", "--memory", "512"]
    end
    # 使用box，必须先挂载好
    redis.vm.box = "centos7"
    # 主机名称
    redis.vm.hostname = "redis"
    # 公有网络
    redis.vm.network :public_network, ip: "192.168.67.2"
    # 私有网络
    redis.vm.network :private_network, ip: "11.11.11.2"
  end
end  
```

## 4.7. 创建虚拟机

```shell
vagrant up
```

![](img/QQ20190814-205721@2x.png)

## 4.8. 使用ssh连接虚拟机，注意此时xshell远程连接不上，需要开放密码连接，需要使用root用户权限

```shell
# 连接reids服务器
vagrant ssh redis
# 切换用户su 输入vagrant密码
vi /etc/ssh/sshd_config
# vi命名==》编辑文本
# 三个模式
	# 命令模式 esc
	# 末行模式 :wq（保存退出） :q!(不保存退出)
	# 输入模式 a  o
# 启用密码登录
PasswordAuthentication yes
# 重启
systemctl restart sshd
```

# 5. 命令

## 5.1. Vagrant box命令

- 列出本地环境中所有的box

  ```shell
  vagrant box list
  ```

- 添加box到本地vagrant环境

  ```shell
  vagrant box add box-name  box-url
  ```

- 更新本地环境中指定的box

  ```shell
  vagrant box update box-name
  ```

- 删除本地环境中指定的box

  ```shell
  vagrant box remove box-name
  ```

- 重新打包本地环境中指定的box

  ```shell
  vagrant box repackage box-name
  ```

- 在线查找需要的box

  官方网址：<https://app.vagrantup.com/boxes/search>

## 5.2. Vagrant基本命令

- 在空文件夹初始化虚拟机

  ```shell
  vagrant init [box-name]
  ```

- 在初始化完的文件夹内启动虚拟机

  ```shell
  vagrant up
  ```

- 登录启动的虚拟机

  ```shell
  vagrant ssh
  ```

- 挂起启动的虚拟机

  ```shell
  vagrant suspend
  ```

- 重启虚拟机

  ```shell
  vagrant reload
  ```

- 关闭虚拟机

  ```shell
  vagrant halt
  ```

- 查找虚拟机的运行状态

  ```shell
  vagrant status
  ```

- 销毁当前虚拟机

  ```shell
  vagrant destroy
  ```

- 唤醒虚拟机

  ```shell
  vagrant resume
  ```

- 挂起虚拟机

  ```shell
  vagrant suspend
  ```

# 6. 非正常关机后，xshell连不上的解决方案

- 执行命令

```shell
vagrant reload --provision
```

# 7. 打包自己的box, 加载自己打包好的box

```shell
# 先打包  --base 要打包的虚拟机名称 --output 打包后的包名
vagrant package --base centos7 --output centos7.box
# 加载 
vagrant box add --name newcentos7 /boxpath/centos.box
```

- 加载自己打包好的box,在vagrantfile中加多两行，否则会报一个权限问题

```shell
  # 定义mysql服务器
  config.vm.define :mysql do |mysql|
    # mysql
    mysql.vm.provider "virtualbox" do |v|
          v.customize ["modifyvm", :id, "--name", "mysql", "--memory", "512"]
    end
    mysql.vm.box = "centos"
    mysql.vm.hostname = "mysql"
    mysql.vm.network :public_network, ip: "192.168.67.3"
    mysql.vm.network :private_network, ip: "11.11.11.3"
	# 加上下面两行
    mysql.ssh.password = "vagrant"
    mysql.ssh.insert_key = false
   
  end 
```

# 8.  常见错误

```shell
Vagrant was unable to mount VirtualBox shared folders. This is usually
because the filesystem "vboxsf" is not available. This filesystem is
made available via the VirtualBox Guest Additions and kernel module.
Please verify that these guest additions are properly installed in the
guest. This is not a bug in Vagrant and is usually caused by a faulty
Vagrant box. For context, the command attempted was:
```
- 执行
```shell
 vagrant plugin  install  vagrant-vbguest
```






















