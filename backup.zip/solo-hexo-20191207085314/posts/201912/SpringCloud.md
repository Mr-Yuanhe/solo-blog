title: Spring Cloud
date: '2019-12-05 14:08:27'
updated: '2019-12-05 14:14:08'
tags: [Spring]
permalink: /articles/2019/12/05/1575526107787.html
---
# 1. 集群、分布式和微服务

## 1.1. 单机

- 概念：整个项目所有的服务都由一台服务器提供。这就是单机结构。
- 优点：部署简单
- 缺点：随着访问量的增大，硬件资源就越来越不足，这时候就需要集群。

## 1.2. 集群

- 概念：单机处理到达瓶颈的时候，你就把单机复制几份，这样就构成了一个“集群”
- 缺点：
  - 多台较好服务器比较贵
  - 当服务器的数量超过一定程度时，集群本身也需要消耗性能

![](http://yuanheweb.com/img/springcloud/20170213132417777.png)

## 1.3. 分布式

- 概念：分布式结构就是将一个完整的系统，按照业务功能，拆分成一个个独立的子系统，在分布式结构中，每个子系统就被称为“服务”。这些子系统能够独立运行在web容器中，它们之间通过RPC方式通信。

![](http://yuanheweb.com/img/springcloud/01.png)

## 1.4. 微服务  

- 微服务是一种架构风格，一个大型复杂软件应用由一个或多个微服务组成。系统中的各个微服务可被独立部

  署，各个微服务之间是松耦合的。每个微服务仅关注于完成一件任务并很好地完成该任务。在所有情况下，每

  个任务代表着一个小的业务能力。  

- 微服务与分布式的细微差别是，微服务的应用不一定是分散在多个服务器上，他也可以是同一个服务器。 

- 服务与服务之间调用采用REST方式

![](http://yuanheweb.com/img/springcloud/c5Al4E6mFd.png)





# 2. 微服务与微服务架构 

微服务是什么

业界大牛马丁.福勒（Martin Fowler） 这样描述微服务：

微服务的概念源于2014年3月Martin Fowler所写的章“Microservices”http://martinfowler.com/articles/microservices.html

就目前而言，对于微服务业界并没有一个统一的、标信的定义（Whilethere is no precise definition of this architectural syle）

- In short, the microservice architectural style is an approach to developing a single application as a **suite of small services**, each **running in its own process** and communicating with lightweight mechanisms, often an HTTP resource API. These services are **built around business capabilities** and **independently deployable** by fully automated deployment machinery. There is a **bare minimum of centralized management** of these services, which may be written in different programming languages and use different data storage technologies. 
- 通常而言，微服务架构是一种架构模式或者说是一种架构风格，它提倡将单一应用程序划分一组小的服务，每个服务运行在其独立的自己的进程中，服务之间互相协调、互相配合，为用户提供最终价值。服务之间采用轻量级的通信机制互相沟通（通常是基于HTTP的RESTful API）。每个服务都围绕着具体业务进行构建，并且能够被独立地部署到生产环境、类生产环境等。另外应尽量避免统一的，集中的服务管理机制，对具体的一个服务而言，应根据业务上下文，选择合适的语言、工具对其进行构建，可以有一个非常轻量级的集中管理来协调这些服务，可以使用不同的语言来编写服务，也可以使用不同的数所存储。

# 3. 服务直接调用

- 直接调用图解如下：

  ![](http://yuanheweb.com/img/springcloud/91.png)

- 图中，客户端的一个接口，需要调用服务A-N。客户端必须要知道所有服务的网络位置的，以往的做法是配置是配置文件中，或者有些配置在数据库中。这里就带出几个问题：

  - 需要配置N个服务的网络位置，加大配置的复杂性
  - 服务的网络位置变化，都需要改变每个调用者的配置
  - 集群的情况下，难以做负载（反向代理的方式除外）

- 总结起来一句话：服务多了，配置很麻烦，问题多多

## 3.1. 新建父工程Project 

- 新建父工程01_springcloud_direct_parent，切记是packaging是pom模式

  主要是定义POM文件，将后续各个子模块公用的jar包等统一提出来，类似一个抽象父类

  ```xml
  <?xml version="1.0" encoding="UTF-8"?>
  <project xmlns="http://maven.apache.org/POM/4.0.0"
           xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
           xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
      <modelVersion>4.0.0</modelVersion>
  
      <!--current module-->
      <groupId>net.wanho</groupId>
      <artifactId>_001_springcloud_parent</artifactId>
      <version>1.0</version>
      <packaging>pom</packaging>
  
      <modules>
         <module>microservice-provider-6001</module>
          <module>microservice-consumer-7001</module>
      </modules>
  
  </project>
  ```

## 3.2. microservice-provider-6001 服务提供者

- 新建 microservice-provider-6001

- pom.xml

  ```xml
  lombok
  web
  ```

- yml

  ```yaml
  server:
    port: 6001
  ```

- 主启动类MicroservicecloudProviderApplication.java

  ```java
  @SpringBootApplication
  @RestController
  public class MicroserviceProvider6001Application {
  
      public static void main(String[] args) {
          SpringApplication.run(MicroserviceProvider6001Application.class, args);
      }
      
  	@Value("${server.port}")
      private String port;
  
      @GetMapping("/provider")
      public String provider(){
          return "provider"+port;
      }
  }
  ```

- 测试

  http://localhost:6001/provider

## 3.3.  microservice-consumer-7001服务消费者

- 新建 microservice-consumer-7001

- POM

  ```xml
  lombok
  web
  ```

- yml

  ```yaml
  server:
    port: 7001
  ```

- net.wanho.config.MyAppConfig（类似spring里面的applicationContext.xml写入的注入Bean）

  ```java
  @Configuration
  public class RestConfig {
  
      @Bean
      public RestTemplate getRestTemplate(){
          return new RestTemplate();
      }
  }
  ```

- 主启动类 MicroservicecloudConsumerApplication.java

  ```java
  @SpringBootApplication
  @RestController
  public class MicroserviceConsumer7001Application {
  
      @Autowired
      private RestTemplate restTemplate;
  
      @GetMapping("/consumer")
      public String consumer(){
          //通过rest方式直接调用provider服务，硬编码
          String object = restTemplate.getForObject("http://localhost:6001/provider", String.class);
          return "consumer"+object;
      }
  
      public static void main(String[] args) {
          SpringApplication.run(MicroserviceConsumer7001Application.class, args);
      }
  
  }
  
  ```

- 测试

  http://localhost:7001/consumer



# 4. 服务中心调用

![](http://yuanheweb.com/img/springcloud/92.png)

## 4.1. 服务治理种类

- 要解决直接访问服务的问题，就需要服务注册与发现

- 与之前一张不同的是，加了个服务发现模块。图比较简单，这边文字描述下。服务A-N把当前自己的网络位置注册到服务发现模块（这里注册的意思就是告诉），服务发现就以K-V的方式记录下，K一般是服务名，V就是IP:PORT。服务发现模块定时的轮询查看这些服务能不能访问的了（这就是健康检查）。客户端在调用服务A-N的时候，就跑去服务发现模块问下它们的网络位置，然后再调用它们的服务。这样的方式是不是就可以解决上面的问题了呢？客户端完全不需要记录这些服务网络位置，客户端和服务端完全解耦！
- 这个过程大体是这样，当然服务发现模块没这么简单。里面包含的东西还很多。这样表述只是方便理解。
- 做服务发现的框架常用的有
  - zookeeper (dubbo中用过)
  - eureka（下面来看）
  - consul （下下面来看）
  - etcd （不看啦）

## 4.2. 是什么：服务注册中心：Eureka

![image-20190318095230610](http://yuanheweb.com/img/springcloud/20.png)

Spring Cloud Eureka来实现服务治理(服务注册和发现)

![1. 服务注册于发现.png](http://yuanheweb.com/img/springcloud/3.png)

- Eureka Server 提供服务注册和发现
- Service Provider服务提供方将自身服务注册到Eureka，从而向Server提供服务
- Service Consumer服务发现方将服务从Eureka，从而使用向Server获取服务

## 4.3. 创建工程 _010_springcloud_eureka_parent

### 4.3.1. eureka-server-5001三步曲

- pom

  ```xml
  lombok
  web
  eureka-server
  ```

- @EnableEurekaServer注解

  ```java
  @EnableEurekaServer
  ```

- yml

  在默认设置下，该服务注册中心也会将自己作为客户端来尝试注册它自己，所以我们需要禁用它的客户端注册行为，只需要在`application.yml`配置文件中增加如下信息：

  ```yaml
  server:
    port: ${PORT:5001}
  eureka:
    instance:
      hostname: localhost
    client:
      # eureka服务不需要 注册到eureka服务中心
      register-with-eureka: false
      # 不获取
      fetch-registry: false
      service-url:
        defaultZone: ${EUREKA_SERVER:http://localhost:5001/eureka/}
  ```

- 通过参数设置启动参数

  ![](http://yuanheweb.com/img/springcloud/QQ截图20191203104625.png)

- ![](http://yuanheweb.com/img/springcloud/QQ截图20191203104520.png)



### 4.3.2. eureka-provider-6001三步曲

- pom

  ```xml
  <dependency>
      <groupId>org.springframework.cloud</groupId>
      <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
  </dependency>
  ```

- @EnableEurekaClient或@EnableDiscoveryClient注解

  在应用主类中通过加上 @EnableEurekaClient，但只有Eureka 可用，你也可以使用@EnableDiscoveryClient。需要配置才能找到Eureka注册中心服务器

  ```java
  @SpringBootApplication
  @EnableEurekaClient
  @RestController
  public class MicroserviceProvider6001Application {
  
      @Value("${server.port}")
      private String port;
  
      @GetMapping("/provider")
      public String provider(){
          return "provider:"+port;
      }
  
      public static void main(String[] args) {
          SpringApplication.run(MicroserviceProvider6001Application.class, args);
      }
  
  }
  ```

- yml

  ```yaml
  server:
    port: 6001
  eureka:
    client:
      service-url:
        defaultZone: http://localhost:5000/eureka/
    instance:
  #    显示ip
      prefer-ip-address: true
  #    Status显示名
      instance-id: microservice-provider-6001
  spring:
    application:
  #    Application名称，服务名只能用中划杠
      name: eureka-provider
  ```


### 4.3.3. eureka-consumer-7001 三步曲

- pom

  ```xml
   <!--eureka 它里包含了rabbion-->
  <dependency>
      <groupId>org.springframework.cloud</groupId>
      <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
      <version>2.1.1.RELEASE</version>
  </dependency>
  ```

- 注解

  ```java
  @SpringBootApplication
  @EnableEurekaClient
  @RestController
  public class MicroserviceConsumer7001Application {
  
      @Autowired
      private RestTemplate restTemplate;
  
      @GetMapping("/consumer")
      public String consumer(){
          //直接调用
  //        String url = "http://localhost:6001/provider";
          String url = "http://MICROSERVICE-PROVIDER/provider";
          return "consumer"+restTemplate.getForObject(url,String.class);
      }
  
      public static void main(String[] args) {
          SpringApplication.run(MicroserviceConsumer7001Application.class, args);
      }
  }
  ```

- yml

  ```yaml
  server:
    port: 7001
  spring:
    application:
      name: microservice-consumer
  eureka:
    client:
      service-url:
        defaultZone: http://localhost:5001/eureka/
    instance:
      prefer-ip-address: true
      instance-id: microservice-consumer-7001
  ```

- 创建RestTemplate必须使用@LoadBalanced注解 

  ```java
  @Bean
  @LoadBalanced
  public RestTemplate getRestTemplate(){
      return new RestTemplate();
  }
  ```


# 5. 服务接口调用(Feign 调用服务)

## 5.1. 概述

### 5.1.1. 读音

![image-20190318102452423](http://yuanheweb.com/img/springcloud/23.png)

### 5.1.2. 什么是Feign？

- Feign是一个声明式的Web服务客户端，使得编写Web服务客户端变得非常容易，只需要创建一个接口，然后在上面添加注解即可
- Spring Cloud 集成 Ribbon 和 Eureka 提供的负载均衡的HTTP客户端 ，而Feign也集成了Ribbon
- Spring Cloud Netflix 官网文档http://www.xyuu.cn/spring-cloud-netflix-zhcn.html

## 5.2. 引出三种方式

```java
//直接调用 
private static final String url="http://localhost:7001/provider";
restTemplate.getForObject(url,String.class)
    
//通过服务名调用 
private static final String url="http://EUREKA-PROVIDER/provider";
restTemplate.getForObject(url,String.class)
    
//通过接口调用 
@FeignClient("EUREKA-PROVIDER")
public interface ProviderClient {
    @GetMapping("/provider")
    public String provider();
}
```

## 5.3. 新建_03_springlcoud_fegin_parent的maven父工程

把之前的03_springlcoud_ribbon_parent项目复制过来

- eureka-server-5001不变

- eureka-provider-6001 不变


- eureka-consumer-7001修改

- fegin使用三步曲

  - pom.xml

    ```xml
    <dependency>
        <groupId>org.springframework.cloud</groupId>
        <artifactId>spring-cloud-starter-openfeign</artifactId>
    </dependency>
    ```

  - @EnableFeignClients

    ```java
    @SpringBootApplication
    @EnableEurekaClient
    @EnableFeignClients
    @RestController
    public class EurekaConsumerFegin7001Application {
    
        @Autowired
        private ProviderClient providerClient;
    
        @GetMapping("/consumer")
        public String consumer(){
            //通过feign调用provider服务
            String object = providerClient.getProvider();
            return "consumer"+object;
        }
    
        public static void main(String[] args) {
            SpringApplication.run(EurekaConsumerFegin7001Application.class, args);
        }
    
    }
    ```

  - @FeignClient

    ```java
    @FeignClient("EUREKA-PROVIDER")
    public interface ProviderClient {
    
        @GetMapping("/provider")
        public String getProvider();
    }
    
    ```

# 6.  Ribbon负载均衡

## 6.1. 概述

- 是什么
  - Spring Cloud Ribbon是基于Netflix Ribbon实现的一套客户端负载均衡的工具。

- pom.xml ,**也可以不需要下载**，因为eureka中已经集成了ribbon,且Feign也集成ribbon

## 6.2. Ribbon负载均衡算法

Ribbon默认提供的是轮询的负载均衡算法，完整了还有如下

| 名称                      | 说明                                                         |
| ------------------------- | ------------------------------------------------------------ |
| RoundRobinRule            | 轮询                                                         |
| RandomRule                | 随机                                                         |
| AvaliabilityFilteringRule | 会先过滤由于多次访问故障而处于断路器跳闸的状态的服务和并发的连接数量超过阈值的服务，然后对剩余的服务列表按照轮询策略 |
| WeightedResponseTimeRule  | 根据平均响应时间计算所有服务的权重，响应时间越快服务权重越大 |
| RetryRule                 | 先按照RoundRobinRule策略获取服务，如果获取服务失败会在指定时间内重试 |
| BestAvailableRule         | 会先过滤掉由于多次访问故障二处于断路器跳闸状态的服务，然后选择一个并发量最小的服务 |
| ZoneAvoidanceRule         | 默认规则，复合判断server所在的区域的性能和server的可用性选择服务器 |

## 6.3.  Ribbon负载均衡算法使用方法

在客户端的配置类ConfigBean.java中添加IRule的实现

1、配置轮询的负载均衡算法

```java
@Configuration
public class RestConfig {

    @Bean
    @LoadBalanced
    public RestTemplate getRestTemplate(){
        return new RestTemplate();
    }

    @Bean
    public IRule getRule(){
        return new RandomRule();
    }
}
```

## 6.4. 示例工程 _02_springcloud_eureka_parent

- eureka-server-5001不变

- eureka-consumer-7001不变
- microservice-provider-6001 不变，但复制
- microservice-provider-6002 =>shift+f6=>修改模块名=>pom.xml名称=>yml端口号和status的名字

- 观察发现consumer是轮询的方式访问provider

## 6.5. 同一个项目，启动多次(status,port值不一样)

![](http://yuanheweb.com/img/springcloud/QQ截图20191203155847.png)

# 7. eureka自我保护

- 故障现象

  ![image-20190318094711680](http://yuanheweb.com/img/springcloud/18.png)

![image-20190318094718537](http://yuanheweb.com/img/springcloud/19.png)

- 导致原因：springboot 自我保护模式？

  - 默认情况下，如果EurekaServer在一定时间内没有接收到某个微服务实例的心跳，EurekaServer将会注销该实例（默认90秒）。但是当网络分区故障发生时，微服务与EurekaServer之间无法正常通信，以上行为可能变得非常危险了——因为微服务本身其实是健康的，此时本不应该注销这个微服务。Eureka通过“自我保护模式”来解决这个问题——当EurekaServer节点在短时间内丢失过多客户端时（可能发生了网络分区故障），那么这个节点就会进入自我保护模式。一旦进入该模式，EurekaServer就会保护服务注册表中的信息，不再删除服务注册表中的数据（也就是不会注销任何微服务）。当网络故障恢复后，该Eureka Server节点会自动退出自我保护模式。
  - 在自我保护模式中，Eureka Server会保护服务注册表中的信息，不再注销任何服务实例。当它收到的心跳数重新恢复到阈值以上时，该Eureka Server节点就会自动退出自我保护模式。它的设计哲学就是宁可保留错误的服务注册信息，也不盲目注销任何可能健康的服务实例。一句话讲解：好死不如赖活着
  - 综上，自我保护模式是一种应对网络异常的安全保护措施。它的架构哲学是宁可同时保留所有微服务（健康的微服务和不健康的微服务都会保留），也不盲目注销任何健康的微服务。使用自我保护模式，可以让Eureka集群更加的健壮、稳定。
  - 一句话：某时刻某一个微服务不可用了，eureka不会立刻清理，依旧会对该微服务的信息进行保存
  - 在Spring Cloud中，可以使用eureka.server.enable-self-preservation = false 禁用自我保护模式。

- 关闭自我保护

  ```shell
  server:
  	enable‐self‐preservation: false #是否开启自我保护模式
  	eviction‐interval‐timer‐in‐ms: 60000 #服务注册表清理间隔（单位毫秒，默认是60*1000）
  ```

  

  ![](G:/java课程/step7/笔记/02_springcloud/笔记/http://yuanheweb.com/img/springcloud/image4.png)

  说明：

  ```shell
  上图红色提示信息：
  THE SELF PRESERVATION MODE IS TURNED OFF.THIS MAY NOT PROTECT INSTANCE EXPIRY IN CASE OF
  NETWORK/OTHER PROBLEMS.
  自我保护模式被关闭。在网络或其他问题的情况下可能不会保护实例失效。
  ```

  Eureka Server有一种自我保护模式，当微服务不再向Eureka Server上报状态，Eureka Server会从服务列表将此 服务删除，如果出现网络异常情况（微服务正常），此时Eureka server进入自保护模式，不再将微服务从服务列 表删除。

  在开发阶段建议关闭自保护模式。

# 8. 高可用Eureka-Server

- Eureka Server 高可用环境需要部署两个Eureka server，它们互相向对方注册。如果在本机启动两个Eureka需要 注意两个Eureka Server的端口要设置不一样，这里我们部署一个Eureka Server工程，将端口可配置，制作两个 Eureka Server启动脚本，启动不同的端口，如下图：

![](http://yuanheweb.com/img/springcloud/image5.png)

1、在实际使用时Eureka Server至少部署两台服务器，实现高可用。 

2、两台Eureka Server互相注册。

3、微服务需要连接两台Eureka Server注册，当其中一台Eureka死掉也不会影响服务的注册与发现。

4、微服务会定时向Eureka server发送心跳，报告自己的状态。

 5、微服务从注册中心获取服务地址以RESTful方式发起远程调用。

 配置如下：

1、端口可配置

```yaml
server:
  port: ${PORT:5001} #服务端口
```

2、Eureka服务端的交互地址可配置

```yaml
eureka:
  client:
    registerWithEureka: true #服务注册，是否将自己注册到Eureka服务中
    fetchRegistry: true #服务发现，是否从Eureka中获取注册信息
    serviceUrl: #Eureka客户端与Eureka服务端的交互地址，高可用状态配置对方的地址，单机状态配置自己（如果不配置则默认本机8761端口）
      defaultZone: ${EUREKA_SERVER:http://eureka02:5002/eureka/}
```

3、配置hostname

- Eureka 组成高可用，两个Eureka互相向对方注册，这里需要通过域名或主机名访问，这里我们设置两个Eureka服 务的主机名分别为 eureka01、eureka02。

- C:\Windows\System32\drivers\etc\hosts

  ```java
  127.0.0.1 eureka01
  127.0.0.1 eureka02
  ```

完整的eureka配置如下：

```yaml
eureka:
  client:
    registerWithEureka: true #服务注册，是否将自己注册到Eureka服务中
    fetchRegistry: true #服务发现，是否从Eureka中获取注册信息
    serviceUrl: #Eureka客户端与Eureka服务端的交互地址，高可用状态配置对方的地址，单机状态配置自己（如果不配置则默认本机8761端口）
      defaultZone: ${EUREKA_SERVER:http://eureka02:5002/eureka/}
  server:
    enable-self-preservation: false #是否开启自我保护模式
    eviction-interval-timer-in-ms: 60000 #服务注册表清理间隔（单位毫秒，默认是60*1000）
  instance:
    hostname: ${EUREKA_DOMAIN:eureka01}
```

4、在IDEA中制作启动脚本启动1：

启动2：

![](http://yuanheweb.com/img/springcloud/image7.png)

运行两个启动脚本，分别浏览：

http://localhost:50101/

http://localhost:50102/

Eureka主画面如下：

![](http://yuanheweb.com/img/springcloud/QQ20191009-063706@2x.png)

# 9. Hystrix断路器

## 9.1. 概述

### 9.1.1. 读音

![](http://yuanheweb.com/img/springcloud/QQ截图20190911100907.png)

### 

### 9.1.2. 什么是断路器和hystrix

- 断路器模式源于Martin Fowler的Circuit Breaker一文。“断路器”本身是一种开关装置，用于在电路上保护线路过载，当线路中有电器发生短路时，“断路器”能够及时的切断故障电路，防止发生过载、发热、甚至起火等严重后果。

### 9.1.3.  服务之间调用存在问题： 服务雪崩

- 多个微服务之间调用的时候，假设微服务A调用微服务B和微服务C，微服务B和微服务C又调用其它的微服务，这就是所谓的“扇出”。

- 如果扇出的链路上某个微服务的调用响应时间过长或者不可用，对微服务A的调用就会占用越来越多的系统资源，进而引起系统崩溃，所谓的“雪崩效应”. **一个服务挂了后续的服务跟着不能用了，这就是雪崩效应**

### 9.1.4. 断路器示意图 

- SpringCloud Netflix实现了断路器库的名字叫Hystrix. 在微服务架构下，通常会有多个层次的服务调用. 下面是微服架构下, 浏览器端通过API访问后台微服务的一个示意图：

  ![](http://yuanheweb.com/img/springcloud/93.png)

- 一个微服务的超时失败可能导致瀑布式连锁反映，下图中，Hystrix通过自主反馈实现的断路器， 防止了这种情况发生。

  ![](http://yuanheweb.com/img/springcloud/94.png)

- 图中的服务B因为某些原因失败，变得不可用，所有对服务B的调用都会超时。当对B的调用失败达到一个特定的阀值(5秒之内发生20次失败是Hystrix定义的缺省值), 链路就会被处于open状态， 之后所有所有对服务B的调用都不会被执行， 取而代之的是由断路器提供的一个表示链路open的Fallback消息. Hystrix提供了相应机制，可以让开发者定义这个Fallbak消息.

## 9.2. 示例

### 9.2.1. 新建 _05_springcloud_hystrix_parent父工程

### 9.2.2. 拷贝 _04_springcoud_fegin_parent

- 其中
  - eureka_server_5000
  - eureak_provider_6001
  - eureak_provider_6002
  - eureak_provider_6003 都不需要改变

### 9.2.3. 修改 eureka_consumer-7001，方法级熔断

- pom.xml

```xml
 <!-- hystrix 断路器 -->
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-netflix-hystrix</artifactId>
</dependency>
```

- application.java

```java
@SpringBootApplication
@EnableEurekaClient
@RestController
@EnableFeignClients
@EnableHystrix
public class EurekaConsumer7001Application {

    public static void main(String[] args) {
        SpringApplication.run(EurekaConsumer7001Application.class, args);
    }

    @Autowired
   private ProviderClient providerClient;

    // 当前方法使用熔断
    @GetMapping("/consumer")
    @HystrixCommand(fallbackMethod = "handler")
    public String consumer(){
        return providerClient.provider();
    }

    //熔断方法
    public String handler(){
        return "hystrix触发了，providerClient中的服务挂了";
    }

}
```

### 9.2.4. 修改 eureka_consumer-7001，在fegin中使用熔断

- application.java->注释方法熔断

  ```java
  @SpringBootApplication
  @EnableEurekaClient
  @RestController
  @EnableFeignClients
  @EnableHystrix
  public class EurekaConsumer7001Application {
  
      public static void main(String[] args) {
          SpringApplication.run(EurekaConsumer7001Application.class, args);
      }
  
      @Autowired
     private ProviderClient providerClient;
  
      // 当前方法使用熔断
      @GetMapping("/consumer")
      //@HystrixCommand(fallbackMethod = "handler")
      public String consumer(){
          return providerClient.provider();
      }
  
      //熔断方法
      public String handler(){
          return "hystrix触发了，providerClient中的服务挂了";
      }
  
  }
  ```

- application.yml中启用feign熔断

```yaml
feign:
  hystrix:
    enabled: true
```

- api/ProviderClient

  ```java
  /**
   * 在fegin可以配置熔断处理，对所有的请求都会生效
   *      必须在yml中启动fegin.hystrix.enable=true
   *      fallbackFactory所在的工厂要加上@Component注解
   *      fallbackFactory所在的工厂要继承FallbackFactory<当前接口类型>
   */
  @FeignClient(value="EUREKA-PROVIDER",fallbackFactory = HystrixFactory.class)
  public interface ProviderClient {
  
      @GetMapping("/provider")
      @LoadBalanced
      public String provider();
  }
  ```

  ```java
  @Component
  public class HystrixFactory implements FallbackFactory<ProviderClient> {
      @Override
      public ProviderClient create(Throwable throwable) {
          return ()-> "服务提供者又挂了";
      }
  }
  ```

### 9.2.5. 修改 eureka_consumer-7001，在fegin中使用熔断

- application.java->注释方法熔断

  ```java
  @SpringBootApplication
  @EnableEurekaClient
  @RestController
  @EnableFeignClients
  @EnableHystrix
  public class EurekaConsumer7001Application {
  
      public static void main(String[] args) {
          SpringApplication.run(EurekaConsumer7001Application.class, args);
      }
  
      @Autowired
     private ProviderClient providerClient;
  
      // 当前方法使用熔断
      @GetMapping("/consumer")
      //@HystrixCommand(fallbackMethod = "handler")
      public String consumer(){
          return providerClient.provider();
      }
  
      //熔断方法
      public String handler(){
          return "hystrix触发了，providerClient中的服务挂了";
      }
  
  }
  ```

- application.yml中启用feign熔断

```yaml
feign:
  hystrix:
    enabled: true
```

- api/ProviderClient

  ```java
  /**
   * 在fegin可以配置熔断处理，对所有的请求都会生效
   *      必须在yml中启动fegin.hystrix.enable=true
   *      fallbackFactory所在的工厂要加上@Component注解
   *      fallbackFactory所在的工厂要继承FallbackFactory<当前接口类型>
   */
  @FeignClient(value="EUREKA-PROVIDER",fallbackFactory = HystrixFactory.class)
  public interface ProviderClient {
  
      @GetMapping("/provider")
      @LoadBalanced
      public String provider();
  }
  ```

  ```java
  @Component
  public class HystrixFactory implements FallbackFactory<ProviderClient> {
      @Override
      public ProviderClient create(Throwable throwable) {
          return ()-> "服务提供者又挂了";
      }
  }
  ```








