title: 华为 HCIA-Big Data 单选题
date: '2019-11-01 08:53:36'
updated: '2019-11-01 08:54:56'
tags: [HCIA-BigData]
permalink: /articles/2019/11/01/1572569616402.html
---
#### 1.Spark 是用以下哪种编程语言实现的 ? D /Users/mac/Desktop/选择题.txt

```
A. C
B. C++ 
C. JAVA 
D. Scala
```

#### 2.FusionInsight Manager 对服务的管理操作，下面说法错误的是 ?C 

```
A. 可对服务进行启停重启操作
B. 可以添加和卸载服务
C. 可设置不常用的服务隐藏或显示
D. 可查看服务的当前状态
```

#### 3.FusionInsight HD 的 Loader 在创建作业时，连接器( Connector )有什么作用 ?C 

```
A. 确定有哪些转换步骤
B. 提供优化参数，提高数据导入导出性能
C. 配置作业如何与外部数据源进行连接
D. 配置作业如何与内部数据源进行连接
```

#### 4.下列哪个 HDFS 命令可用于检测数据块的完整性 ?A

```
A. hdfs fsck /
B. hdfs fsck / -delete
C. hdfs dfsadmin -report
D. hdfs balancer-threshold 1
```

#### 5.YARN 中设置队列 QueueA 的最大使用资源量，需要配置哪个参数 ?D 

```
A. yarn.scheduler.capacity.root.QueueA.user-limit-factor
B. yarn.scheduler.capacity.root.QueueA.minimum-user-limit-percent
C. yarn.scheduler.capacity.root.QueueA.state
D. yarn.scheduler.capacity.root.QueueA.maxirnum-capacity
```



#### 6.FusionInsight Manager 对服务的配置功能说法不正确的是 ?C 

```
A. 服务级别的配置可对所有实例生效
B. 实例级别的配置只针对本实例生效
C. 实例级别的配置对其他实例也生效
D. 配置保存后需要重启服务才能生效
```

#### 7.关于 FusionInsight HD 安装流程正确的是 ?B

```
A. 安装 Manager -> 执行 preinstall -> LLD 工具进行配置 -> 安装集群 -> 安装后检查 -> 安装后配置
B. LLD 工具进行配置 -> 执行 preinstall -> 安装 Manager -> 安装集群 -> 安装后检查 -> 安装后配置
C. 安装 Manager -> LLD 工具进行配置 -> 执行 preinstall -> 安装集群 -> 安装后检查 -> 安装后配置
D. LLD 工具进行配置 -> 执行 preinstall -> 安装集群 -> 安装 Manager -> 安装后检查 -> 安装后配置
```
#### 8. 关于 Kerberos 部署，描述正确的是 ?B

```
A. Kerberos 仅有一个角色
B. Kerberos 服务在同一个节点上有两个实例
C. Kerberos 服务采用主备模式部署
D. Kerberos 服务必须和 LDAP 服务部署在同一个节点
```
#### 9. 某银行规划的 FusionInsight HD 集群有 90 个节点，如果控制节点规划了 3 个，那集 群中数据节点推荐规划多少最为合理 ?A

```
A. 87 B. 85 C. 90 D. 86
```


#### 10.客户 IT 系统中 FusionInsight HD 集群有 150 个节点，每个节点 12 块磁盘(不做 Raid ，不包括 OS 盘)，每块磁盘大小 1T ，只安装 HDFS ，按照默认配置最大可存储多少 数据 ?D

```
A. 1764TB B. 1800TB C. 600TB D. 588TB
```
#### 11.FusionInsight HD 节点不支持哪种主机操作系统 ?D 

```
A. Suse 11.1
B. RedHat 6.5
C. CentOS 6.4
D. Ubuntu 11.04
```
#### 12.FusionInsight HD 中，如果需要查看当前登录 HBase 的用户和权限组，可以在 HBase shell 中执行什么命令 ?B

```
A. use_permission 
B. whoami
C. who
D. get_user
```

#### 13.FusionInsight HD Manager 界面 Hive 日志收集，哪个选项不正确 ?D

```
A. 可指定实例进行日志收集，比如指定单独收集 MetaStore 的日志
B. 可指定时间段进行日志收集，比如只收集 2016-1-1 到 2016-1-10 的日志 
C. 可指定节点 IP 进行日志收集，例如仅下载某个 ip 的日志
D. 可指定特定用户进行日志收集，例如仅下载 userA 用户产生的日志
```


#### 14.FusionInsight HD 三层组网适合多少节点的集群规模 ?D 

```
A. 30 节点以下
B. 100 节点以上
C. 100~200 节点
D. 200 节点以上
```


#### 15.Hadoop 系统中关于客户端向 HDFS 文件系统上传文件说法正确的是 ?B

```
A. 客户端的文件数据经过 NameNode 传递给 DataNode
B. 客户端将文件划分为多个 Block ，根据 DataNode 的地址信息，按顺序写入每一个 DataNode 中
C. 客户端根据 DataNode 的地址信息，按顺序将整个文件写入每一个 DataNode 中，然后 由 DataNode 将文件划分为多个 Block
D. 客户端只上传数据到一个 DataNode ，然后由 NameNode 负责 Block 复制 
```
#### 16.FusionInsight HD 系统中 HBase 的最小处理单元是 Region ， User Region 和 RegionServer 之间的路由信息是保存在哪 ?D

```
A. ZooKeeper 
B. HDFS
C. Master
D. meta 表
```


#### 17.通过 FusionInsight Manager 不能完成以下哪个操作 ?D

```
A. 安装部署 B. 性能监控 C. 权限管理 D. 虚拟机分配
```

#### 18.关于 HBase 的 Region 分裂流程 Split 的描述不正确的是 ?C

```
A. Split 过程中并没有真正的将文件分开，仅仅是创建了引用文件
B. Split 为了减少 Region 中数据大小，从而将一个 Region 分裂成两个 Region 
C. Split 过程中该表会暂停服务
D. Split 过程中被分裂的 Region 会暂停服务
```



#### 19.关于 FusionInsight Manager 关键特性或操作说法正确的是 ?B

```
A. 能够针对整个集群或者某个服务进行健康检查，不能够针对某个节点进行健康检查
B. Manager 引入角色的概念，采用 RBAC 的方式对系统进行权限管理
C. 整个系统使用 Kerberos 管理用户，使用 LDAP 进行用户认证，通过 CAS 实现单点登
录
D. 对于健康检查结果，不能够导出检查报告，只能够在线查看
```


#### 20.查看 Kafka 某 Topic 的 Partition 详细信息时，使用如下哪个命令 ?C 

```
A. bin/kafka-topics.sh --create
B. bin/kafka-topics.sh --list
C. bin/kafka-topics.sh --describe
D. bin/kafka-topics.sh –delete
```
#### 21.Fuslonlnslght Hadoop 集群中，在某节点上通过 df -hT 查询，看到的分区包含以下几个:
/var/log
/srv/BigData
/srv/BigData/hadoop/data 5
/srv/BigData/solr/solrserver3
/srv/BigData/dbdata_om
这些分区所对应磁盘最佳 Raid 级别的规划组合是 ?B

```
A. Raid0 Raid1 Raid0 Non-Raid Raid1
B. Raid1 Raid1 Non-Raid Non-Raid Raid1
C. Raid0 Raid0 Raid0 Raid0 Raid0
D. Non-Raid Non-Raid Non-Raid Non-Raid Raid1
```
#### 22.FusionInsight HD 系统中 HDFS 默认 Block Size 是多少 ?C 

```
A. 32MB
B. 64MB
C. 128MB
D. 256MB
```
#### 23.FusionInsight HD 部署时，同一集群内的 Flume server 节点建议至少部署几个 ?B

```
A. 1 B. 2 C. 3 D. 4
```
#### 24.FusionInsight HD 系统审计日志不可以记录下面哪些操作 ?D

``` 
A. 手动清除告警
B. 启停服务实例
C. 删除服务实例
D. 查询历史监控
```

#### 25.Hadoop 的 HBase 不适合哪些数据类型的应用场景 ?A 

```
A. 大文件应用场景
B. 海量数据应用场景
C. 高吞吐率应用场景
D. 半结构化数据应用场景
```


#### 26.安装 FusionInsight HD 的 Streaming 组件时， Nimbus 角色要求安装几个节点 ?B

```
A. 1 B. 2 C. 3 D. 4
```
#### 27.关于 FusionInsight HD 中 Loader 作业描述正确的是 ?B

```
A. Loader 将作业提交到 Yarn 执行后，如果此时 Loader 服务出现异常，则此作业执行失
败。
B. Loader 将作业提交到 Yarn 执行后，如果某个 Mapper 任务执行失败，能够自动进行重
试。
C. Loader 作业执行失败后将会产生垃圾数据，需要用户手动清除。
D. Loader 将一个作业提交至 Yarn 执行后，该作业执行完成前，不能再提交其他作业。
```

#### 28.Hadoop 平台中，要查看 YARN 服务中一个 application 的信息，通常需要使用什么命 令 ?D

```
A. container
B. applicationattempt 
C. jar
D. application
```
#### 29.在 FusionInsight 集群规划部署时，建议管理节点最好部署()个，控制节点最少需要 部署()数据节点最少需要部署()个。D

```
A. 1 ， 2 ， 2
B. 1 ， 3 ， 2 
C. 2 ， 3 ， 1 
D. 2 ， 3 ， 3
```

#### 30.FusionInsight HD 安装过程中，执行 preinstall 不能完成哪项功能 ?B

```
A. 修改 OS 配置，确保 OS 满足 FusionInsight HD 的安装要求 
B. 安装 Manager
C. 格式化分区
D. 安装 OS 缺失的 RPM 包
```
#### 31.SoIrCloud 模式是集群模式，在此模式下 Solr 服务强依赖于以下哪个服务 ?C

```
A. HBase
B. HDFS
C. ZooKeeper 
D. Yarn
```


#### 32.Hadoop 中 MapReduce 组件擅长处理哪种场景的计算任务 ?B 

```
A. 迭代计算
B. 离线计算
C. 实时交互计算
D. 流式计算
```


#### 33.以下哪类数据不属于半结构化数据 ?C

```
A. HTML B. XML C. 二维表 D. JSON
```
#### 34. 关于 FusionInsight HD Streaming 的 Supervisor 描述正确的是 ?B

```
A. Supervisor 负责资源分配和任务调度
B. Supervisor 负责接受 Nimbus 分配的任务，启动和停止属于自己管理的 worker 进程 C. Supervisor 是运行具体处理逻辑的进程
D. Supervisor 是一个 Topology 中接收数据然后执行处理的组件
```

#### 35.关于 FusionInsight Manager 说法错误的是 ?C

```
A. NTP Server/Client 负责集群内各节点的时钟同步
B. 通过 FusionInsight Manager 可以对 HDFS 进行启停控制、配置参数
C. FusionInsight Manager 所有维护操作只能通过 Web UI 来完成，没有提供 Shell 维护命
令
D. 通过 FusionInsight Manager 可以向导式安装集群，缩短集群部署时间
```


#### 36.FusionInsight HD 系统中如果修改了服务的配置项，不进行服务重启，该服务的配置状态 是什么状态 ?B

```
A. SYNCHRONIZED B. EXPIRED
C. CONFIGURING D. UNKNOWN
```



#### 37.Spark 应用在运行时， Stage 划分的依据是哪个 ?D

```
A. task
B. taskSet 
C. action 
D. shuffle
```


#### 38.采用 Flume 传输数据过程中，为了防止因 Flume 进程重启而丢失数据，推荐使用以下 哪种 channel 类型 ?B

```
A. Memory Channel 
B. File Channel
C. JDBC Channel
D. HDFS Channel
```


#### 39.FusionInsight HD 的 HBase 中的一张表包含以下几个 Region [10 ， 20 )， [20 ， 30 )， [30 ，+∞] ，分别编号为 1 ，2 ，3 ，那么，11 ，20 ，222 分别属于哪个 Region?C

```
A. 113 B. 123 C. 122 D. 112
```

#### 40.关于 Hive 建表基本操作，描述正确的是 ?A 

```
A. 创建外部表时需要指定 external 关键字
B. 一旦表创建好，不可再修改表名
C. 一旦表创建好，不可再修改列名
D. 一旦表创建好，不可再增加新列
```


#### 41.FusionInsight HD 系统部署时，如果 Solr 索引默认存放在 HDFS 上时，以下理解正确的 有 ?D

```
A. 不需要考虑各 SoIrServer 实例上创建了多少 Shard
B. 为保证数据可靠性，创建索引时必须创建多 Replica
C. 通过 HDFS 读取索引时占用磁盘 IO ，因此不建议 Solr 实例与 DataNode 部署在同一
节点上
D. 当 Solr 服务参数 INDEX_STORED_ON_HDFS 值为 HDFS 时，创建 Collection 的索引就默认存储在 HDFS 上
```



#### 42.关于 Kerberos 的 TGT 以下说法错误的是 ?B

```
A. TGT 全称为票据授权票据，主要由 KDC 服务器生成
B. TGT 一次生成之后，可以无限期使用
C. TGT 在客户端的存在方式可以是在内存中存储，也可以在本地以文件的形式存储
D. TGT 中主要的信息有当前该票据的有效时长和授予该 TGT 的服务端 IP 以及分发给的客户端名称
```
#### 43.HBase 中如果发生一个 Region 的 Split ，将一个 HFile 文件真正分开到两个 Region 的 过程发生在以下什么阶段 ?C

```
A. Split 过程中
B. Flush 过程中
C. Compaction 过程中 
D. HFile 分开过程中
```

#### 44.哪个不是 Flume 的 channel 类型 ?D

```
A. Memory Channel 
B. File Channel
C. JDBC Channel
D. HDFS Channel
```
#### 45.FusionInsight HD 中 Loader 实例必须与哪个实例部署在一起 ?D 

```
A. DataNode
B. RegionServer
C. ResourceManager
D. NodeManager
```
#### 46.Hadoop 平台中 HBase 的 Region 是由哪个服务进程来管理 ?C

```
A. HMaster
B. DataNode
C. RegionServer 
D. ZooKeeper
```
#### 47.FusionInsight HD 系统中 HDFS 的 Block 默认保存几份 ?A

``` 
A. 3 份
B. 2 份
C. 1 份
D. 不确定
```
#### 48.Hadoop 中，如果将yarn.scheduler.capacity.root.QueueA.minimum-user-limit-percent 设 置为 50 ，下面说法错误的是 ?B

```
A. 一个用户提交任务，可以使用 QueueA 的 100% 的资源
B. QueueA 中的每个用户最多只能获得 50% 的资源
C. 如果 QueueA 中已经有 2 个用户的任务运行，这时第 3 个用户提交的任务需要等待
释放资源
D. QueueA 中必须保障每个用户至少得到 50% 的资源
```

#### 49.Spark 组件中哪个选项不属于 transformation 操作 ?D

```
A. join
B. distinct
C. reduceByKey
D. reduce
```
#### 50. 关于 Hive 与 Hadoop 其他组件的关系，以下描述错误的是 ?D

```
A. Hive 最终将数据存储在 HDFS 中
B. Hive SQL 其本质是执行 MapReduce 任务 
C. Hive 是 Hadoop 平台的数据仓库工具
D. Hive 对 HBase 有强依赖
```


#### 51.FusionInsight Manager 用户权限管理不支持哪个配置 ?D

```
A. 给用户配置角色 
B. 给角色配置权限 
C. 给用户组配置角色 
D. 给用户组配置权限
```

#### 52.FusionInsight HD 的 Manager 界面对 Loader 的操作不包括下列哪个 ?D

```
A. 启动 Loader 实例
B. 查看 Loader 服务状态 
C. 配置 Loader 参数
D. 查看 Loader 运行日志
```



#### 53.FusionInsight HD 集群规划中，管理节点 & 控制节点 & 数据节点合一部署方案适合什 么样的场景 ?A

```
A. 30 节点以下 B. 100 节点以上 C. 100~200 节点 D. 200 节点以上
```
#### 54.FusionInsight HD 系统中，以下选项哪一个不是 HBase 写数据流程涉及的角色或服 务 ?C

```
A. ZooKeeper
B. HDFS
C. HMaster
D. RegionServer
```


#### 55.关于 FusionInsight Manager 中的 Controller 和 NodeAgent ，说法正确的是 ?B 

```
A. Controller 每隔 3 秒向 NodeAgent 发送心跳
B. NodeAgent 接受 Costroller 下发的命令，执行具体的动作
C. 每个节点都必须部署 Controller
D. NodeAgent 是开源增强的
```
#### 56. 哪个模块是负责 FusionInsight Manager 用户数据存储的 ?D

```
A. CAS
B. AOS
C. Kerberos 
D. LDAP
```

#### 57.FusionInsight HD 中 HBase 的某张表的 RowKey 划分 SplitKey 为 9 ， E ， a ， z ， 请问该表有几个 Region?C

```
A. 3 B. 4 C. 5 D. 6
```
#### 58. 哪一项不属于 FusionInsight HD 中 Hive 的流控特性的描述 ?C 

```
A. 支持对已经建立的总连接数做阈值控制
B. 支持对每个用户已经建立的连接数做阈值控制
C. 支持对某个特定用户已经建立的连接数做阈值控制
D. 支持对单位时间内所建立的连接数做阈值控制 
```
#### 59. 以下关于 Solr 角色描述正确的是 ?B

```
A. SolrServerAdmin 属于管理角色，需要部署在管理节点上。
B. SoIrServer 负责提供创建索引和全文检索等服务，是 Solr 集群中的数据计算和处理单元。
C. HBaseIndexer 是 Solr 的必要角色，提供将 HBase 中数据导入至 Solr 服务。 
```


#### 60.关于 Kafka 盘容量不足的告警，对于可能的原因以下分析不正确的是 ?D

```
A. 用于存储 Kafka 数据的磁盘配置(如磁盘数目、磁盘大小等)，无法满足当前业务数据 流量，导致磁盘使用率达到上限
B. 数据保存时间配置过长，数据累积达到磁盘使用率上限
C. 业务规划不合理，导致数据分配不均，使部分磁盘达到使用率上限 
D. Broker 节点故障导致
```

#### 61.FusionInsight HD 中 Loader 从 SFTP 服务器导入文件，如果不需要做编码转换和数据转 换且速度最快，选择下面哪个文件类型 ?C

```
A. text_file
B. sequence_file 
C. binary_file
D. graph_file
```



#### 62.HBase 的物理存储单元是什么 ?B 

```
A. Region
B. ColumnFamily
C. Column
D. ROW
```


#### 63.YARN 服务中，如果要给队列 QueueA 设置容量为 30% ，应该配置那个参数 ?C 

```
A. yarn.scheduler.capacity.root.QueueA.user-limit-factor
B. yarn.scheduler.capacity.root.QueueA.minimum-user-limit-percent
C. yarn.scheduler.capacity.root.QueueA.capacity
D. yarn.scheduler.capacity.root.QueueA.state
```

#### 64.FusionInsight HD 的 HBase 中保存一张用户信息表 meg_table ， Rowkey 为用户 id ， 其中一列为用户昵称，现在按先后顺序往这列写入三个 KeyValue: 001: Li ，001: Mary ，001: LiLy ，请问 scan 'meg_table' ， {VERSIONS=>2} 会返回哪几条数据 ?D

```
A. 001: Li
B. 001: Lily
C. 001: Li ， 001: Mary ， 001: LiLy 
D. 001: Mary ， 001: LiLy
```
#### 65.FusionInsight HD Loader 作业运行前后，需要哪些节点与外部数据源通讯 ?C 

```
A. Loader 服务主节点
B. 运行 Yarn 服务作业的节点
C. 前面两个都需要
D. 前面两个都不需要
```
#### 66.Hadoop 中哪个模块负责 HDFS 的数据存储 ?B

```
A. NameNode B. DataNode C. ZooKeeper D. JobTraoker
```
#### 67.FusionInsight HD 使用 HBase 客户端批量写入 10 条数据，某个 RegionServer 节点上包 含该表的 2 个 Region ，分别 A 和 B ， 10 条数据中有 2 条属于 A ， 4 条属于 B ，请问写入这 10 条数据需要向该 RegionServer 发送几次 RPC 请求 ?A

``` 
A. 1 B. 2 C. 6 D. 10
```
#### 68. 在规划 FusionIsight HD 集群时，如果客户用于功能测试，对性能没有要求，节约成本 的情况下可以采用管理节点、控制节点、数据节点合一部署，最少需要多少节点 ?B

```
A. 2 B. 3 C. 6 D. 8
```
#### 69.Flume 支持监控并传输目录下新增的文件，可实现准实时数据传输，以上描述的是哪一 类 source?A

```
A. spooling directory source 
B. http source
C. exec source
D. syslog source
```

#### 70.FusionInsight HD 集群中，根据磁盘规划建议， /srv/BigData 分区应该部署在什么磁盘 上 ?A

```
A. OS 盘
B. 元数据盘 
C. 数据盘 
D. 管理盘
```

#### 71.Hadoop 平台中启用 YARN 组件的日志聚集功能，需要配置哪个参数 ?D

```
A. yarn.nodemanager.local-dirs 
B. yarn.nodemanager.log-dirs 
C. yarn.acl.enable
D. yarn.log-aggregation-enable
```
#### 72.FusionInsight HD 产品中，关于 Kafka 组件部署说法不正确的是 ?C 

```
A. Kafka 强依赖于 ZooKeeper ，安装 Kafka 必须安装 ZooKeeper
B. Kafka 部署的实例个数不得小于 2
C. Kafka 的服务端可以产生消息
D. Consumer 作为 Kafka 的客户端角色专门进行消息的消费
```
#### 73.FusionInsight HD 集群组网设计中，有一种机架可以按照业务需求线性扩展，这种机架被称为()B 

```
A. 基本框 B. 扩展框 C. 管理框 D. 数据框
```

#### 74.FusionInsight Manager 不能够管理哪个对象 ?B 

```
A. Spark
B. 主机 OS
C. YARN
D. HDFS
```
#### 75.华为 FusionInsight HD 系统中关于 HDFS 的 DataNode 说法正确的是 ?B

```
A. 不会检查数据的有效性
B. 周期性地将本节点的 Block 发送给 NameNode 
C. 不同的 DataNode 存储的 Block 一定是不同的 
D. 一个 DataNode 上的 Block 可以是相同的
```


#### 76.关于 Hive 在 FusionInsight HD 中的架构描述错误的是 ?A

```
A. 只要有一个 Hiveserver 不可用，整个 Hive 集群便不可用
B. HiveServer 负责接受客户端请求、解析、执行 HQL 命令并返回查询结果
C. MetaStore 用于提供元数据服务，依赖于 DBService
D. 在同一时间点 HiveSever 只有一个处于 Active 状态，另一个则处于 Standby 状态
```
#### 77. 关于 HBase 中 HFile 的描述不正确的是 ?B 

```
A. 一个 HFile 属于一个 Region
B. 一个 HFile 包含多个列族的数据
C. 一个 HFile 包含多列数据
D. 一个 HFile 包含多行数据
```

#### 78.FusionInsight HD 系统中执行 HBase 写数据时，数据被写入内存 MemStore 、日志 HLog 和 HDP 中，请问哪一步写入成功后才会最终返回客户端写数据成功 ?B

```
A. MemStore 
B. HLog
C. HDFS
D. Memory
```

#### 79.FusionInsight HD 系统中，哪个不属于集群节点的磁盘分区 ?D

```
A. OS 分区 B. 数据分区 C. 元数据分区 D. 管理分区
```
#### 80.YARN 调度器分配资源申请的顺序，下面哪一个描述是正确的 ?C 

```
A. 任意机器 -> 同机架 -> 本地资源
B. 任意机器 -> 本地资源 -> 同机架
C. 本地资源 -> 同机架 -> 任意机器
D. 同机架 -> 任意机器 -> 本地资源
```

#### 81.某用户需要搭建一个 350 个节点的 FusionInsight HD 集群，哪种规划方案最佳 ?C

```
A. 管理节点、控制节点、数据节点合一部署，二层组网
B. 管理节点、控制节点合一部署，数据节点独立部署，二层组网 
C. 管理节点、控制节点、数据节点都独立部署，三层组网
D. 管理节点、数据节点合一部署，控制节点独立部署，二层组网
```

#### 82.FusionInsight HD 中，关于 HBase 的 BIoomFilter 特性理解，说法不正确的是 ?A

```
A. 可以用来过滤数据
B. 可以用来优化随机读性能
C. 会增加存储的消耗
D. 可以准确判断某条数据不存在
```


#### 83.加载数据到 Hive 表，哪种方式不正确 ?C

```
A. 直接将本地路径的文件 load 到 Hive 表中
B. 将 HDFS 上的文件 load 到 Hive 表中
C. Hive 支持 insert into 单条记录的方法，所以可以直接在命令行插入单条记录 
D. 将其他表的结果集 insert into 到 Hive 表
```
#### 84.Hadoop 系统中 YARN 资源的抽象是用什么表示 ?C

```
A. 内存
B. CPU
C. Container
D. 磁盘空间
```


#### 85.FusionInsight HD HBase 的管理进程是如何选择主节点的 ?C

``` 
A. 随机选取
B. 由 RegionServer 进行裁决
C. 通过 ZooKeeper 进行裁决
D. HMaster 为双主模式，不需要进行裁决
```




#### 86.FusionInsight HD 系统中 HBase 元数据 Meta region 路由信息保存在哪 ?B

```
A. Root 表 B. ZooKeeper C. HMaster D. Meta 表
```

#### 87.Kafka 集群中， Kafka 服务端部署的角色是 ?D 

```
A. Producer
B. Consumer
C. ZooKeeper
D. Broker
```

#### 88.FusionInsight HD 系统中， LDAP 数据同步方式是哪个 ?A

```
A. 单向同步
B. 双向同步
C. 隔离不同步 
D. 数据交叉同步
```



#### 89.FusionInsight HD 系统中，下面哪个方法不能查看到 Loader 作业执行的结果 ?D 

```
A. 通过 Yarn 任务管理查看
B. 通过 Loader UI 界面查看
C. 通过 Manager 的告警查看
D. 通过 NodeManager 查看
```

#### 90.FusionInsight 系统中， Flume 数据流在节点内不需要经过哪个 component?D 

```
A. source
B. channel
C. sink
D. topic
```
#### 91.HDfS 的 NameNode 节点主备状态管理及元数据文件合并分别由哪两个模块负责 ?A

```
A. Zkfc 和备 NameNode
B. 主 NameNode 和备 NameNode 
C. Zkfc 和主 NameNode
D. 主 NameNode 和 JournalNode
```
#### 92.HBase 中数据存储的文件格式是什么 ?A

``` 
A.HFile
B. SequenceFile
C. Log
D. TXTfile
```

#### 93.有关普通表和外部表的描述，下面哪句是错误的?(单选)D 

```
A.缺省创建时为普通表;
B.外部表实际上是将 HDFS 中已有路径的文件与表联系起来; 
C.删除普通表时会删除数据和元数据; 
D.删除外部表时只删除数据，不删除元数据;
```




#### 94.Flink 是流计算处理和批处理平台，()是数据批处理和流处理的核心引擎。A

```
A Runtime B DataStream C DataSet D FlinkCore
```




#### 95.当 ZooKeeper 集群的节点数为 5 节点时，请问集群的容灾能力和多少节点是等价的?C 

```
A.3 B.4 C.6 D.以上说法都不对
```
#### 96.FusionInsight HD HBase 默认使用什么作为其底层文件存储系统? D

```
A Hadoop B MapReduce C Memory D HDFS
```
#### 97.关于 Hive 与传统数据仓库的对比，以下描述错误的是?B

```
A 由于 Hive 的数据存储在 HDFS 中，所以可以保证数据的高容错、高可靠。
B 由于 Hive 基于大数据平台，所以查询效率比传统数据仓库快
C Hive 基于 HDFS 存储，理论上存储量可以无限扩展，而传统的数据仓库存储量会有上限 
D Hive元数据存储独立于数据存储之外，从而解耦合元数据和数据，灵活性高，而传统数据仓库数据应用单一，灵活性低。
```

#### 98.下面关于 zookeeper 的说法错误的是(B)

```
A Zookeeper 集群在启动时就选举出 Leader 角色
B 如果 zookeeper 在同步消息过程中发生中断，故障恢复后可根据故障前的状态继续同步， 即支持断点续传
C zookeeper 使用自定义的原子消息协议，保证整个系统中节点数据的一致性
D Leader 节点在接受到数据变更请求后，先写磁盘再写内存。
```

#### 99.下面关于 zookeeper 特性的描述错误的是(C)

```
A 消息更新只能成功或者失败，没有中间状态
B 客户端所发送的更新会按照他们被发送的顺序进行应用
C zookeeper 节点数必须为奇数个
D 一条消息要被超过半数的 Server 接受，它将可以成功写入磁盘
```


