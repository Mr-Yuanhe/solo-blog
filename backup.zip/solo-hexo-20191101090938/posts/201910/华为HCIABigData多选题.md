title: 华为 HCIA-Big Data 多选题
date: '2019-10-31 13:18:42'
updated: '2019-10-31 13:24:13'
tags: [HCIA-BigData]
permalink: /articles/2019/10/31/1572499122477.html
---
#### 1.FusionInsight HD 集群升级，以下描述正确的有 ? (多选)ABCD

```
A. 升级过程中不可以手工操作主备 OMS 倒换 
B. 集群内所有主机的 root 帐户密码要保持一致 
C. 保持网络畅通，避免因网络问题导致升级异常 
D. 观察期不能做扩容
```

#### 2.FusionInsight Manager 与外部管理平台对接时，支持哪些接口 ? (多选)AD

```
A. SNMP B. VPN C. BGP D. Syslog
```

#### 3.HBase 的数据文件 HFile 中一个 KeyValue 格式包含哪些信息 ? (多选)ABCD 

```
A. Key
B. Value
C. TimeStamp
D. Key Type
```

#### 4.FusionInsight HD 集群规划设计时，集群有 150 个节点，并且采用双平面组网部署，对
于该集群网络带宽要求的描述，下列描述正确的有 ? (多选)ACE 

```
A. 业务平面所有节点都使用 10GE 网络
B. 管理平面中控制节点使用 10GE 网络
C. 管理平面中数据节点使用 1GE 网络
D. 业务平面中控制节点使用 1GE 网络
E. 管理平面中管理节点使用 10GE 网络
```

#### 5.FusionInsight 系统中 Hive 支持的存储格式包括 ? (多选)BCD

```
A. HFile
B. TextFile
C. SequenceFile 
D. RCFile
```

#### 6.FusionInsight HD 产品在部署 Kerberos 和 LDAP 服务时，以下描述正确的是 ? (多选) AC

```
A. 部署 Kerberos 服务之前，必须先部署 LDAP 服务
B. LDAP 服务必须和 Kerberos 服务部署在同一个节点
C. Kerberos 服务和 LDAP 务部署到同一个节点利于数据访问，有助于性能提升 
D. LDAP 服务可以多个集群共享
```


#### 7.华为 FusionInsight HD 集群中， Spark 服务可以从以下哪些服务读取数据 ? (多选) BCD

```
A. YARN B. HDFS C. Hive D. HBase
```


#### 8.FusionInsight HD 系统中，关于 Solr 索引的存储部署策略，以下说法正确的有 ? (多选) ACD

```
A. 利用 HDFS 数据存储可靠性和易于扩容的特点优先选择索引存储于 HDFS 。
B. 不论 Solr 索引存储在 HDFS 上还是存储在本地磁盘，在同一个节点上都必须要部署 5 个 Solr 实例，根据 IP 和不同的端口号来区分不同的 Solr 实例。
C. 当对实时索引录入速度要求较高时，可选择索引存放于本地磁盘。
D. 当索引数据存放在 HDFS 上时， SolrServer 实例与 DataNode 实例部署在同一个节点 上。
```


#### 9.HBase 集群定时执行 Compaction 的目的是什么 ? (多选)AB

``` 
A. 减少同一个 Region ，同一个 ColumnFamily 下的文件数目
B. 提升数据读取性能
C. 减少同一个 ColumnFamily 的文件数据
D. 减少同一个 Region 的文件数目
```

#### 10.FusionInsight Manager 会定时备份哪些数据 ? (多选)ABCD

```
A. NameNode 
B. LDAP
C. OMs
D. DBService
```


#### 11.以下哪些是 Spark 服务的常驻进程 ? (多选)AB 

```
A. JobHistory
B. JDBCServer
C. SparkResource
D. NodeManaaer
```

#### 12.Hadoop 的 HDFS 是一种分布式文件系统，适合以下哪种场景的数据存储和管理 ? (多 选)BD

```
A. 大量小文件存储 
B. 高容错、高吞吐量 
C. 低延迟读取
D. 流式数据访问
```


#### 13.基于 Hadoop 开源大数据平台主要提供了针对数据分布式计算和存储能力，如下属于分 布式存储组件的有 ? (多选)CD

```
A. MR
B. Spark 
C. HDFS 
D. HBase
```


#### 14.关于大数据的主要特征理解和描述正确的有 ? (多选)ABCD 

```
A. 来源多，格式多
B. 增长速度快，处理速度快
C. 存储量大，计算量大
D. 数据的价值密度较低
```


#### 15.某高校的 FusionInsight HD 集群中有 230 个节点，在进行集群规划时，下列哪些进程 应该部署在数据节点上 ? (多选)ACDF

```
A. Data Node
B. NameNode
C. NodeManager 
D. RegionServer 
E. DBServer
F. SoIrServer
```


#### 16.下列哪些 OS 版本被推荐可以用来搭建 FusionInsight V1R2C60 集群 ? (多选)ABCDE

```
A. SUSE 11 SP1/SP2/SP3 for AMD64 & InteI64 B. CentOS-6.6
C. RedNat-6.4-x86_64
D. RedHat-6.5-x86_64
E. RedHat-6.7-x86_64
F. Ubuntu6.3
```


#### 17.FusionInsight HD 系统中，如果发现 Solr 服务不可用，可以从哪些方面分析定位问题 ? (多选)ABCD

```
A. 查看其依赖的 ZooKeeper 服务是否正常
B. 查看 HDFS 服务是否正常
C. 登录 SolrServerAdmin 所在节点，确认该节点与另外一个 SolrServerAdmin 实例节点网络是否连通
D. 登录 FusionInsight Manager 界面，下载 SoIr 服务不可用期间的相关日志，进行进一步定位
```


#### 18.FusionInsight HD 安装前准备，包括哪些步骤 ? (多选)ABCD

```
A. 完成硬件安装
B. 完成节点主机操作系统安装
C. 准备工具和软件。例如 PuTTY、LLD、FusionInsight HD 软件包等 
D. 准备规划数据，例如网络参数和角色部署位置
```


#### 19.Loader 提供了哪些方式或接口实现作业管理 ? (多选)ABCD

```
A. Web UI
B. Linux 命令行 
C. Rest 接口
D. Java API
87. 以下选项中，对华为 FusionInsight HD 系统中备用 
```
#### 20.NameNode 的作用描述准确的有 ? (多选)AC

```
A. 主 NameNode 的热备
B. 备 NameNode 对内存没有要求
C. 帮助主 NameNode 合并编辑日志，减少主 NameNode 启动时间 
D. 备 NameNode 应与主 NameNode 部署到一个节点
```

#### 21.FusionInsight HD 集群中，集群规模有 300 个节点，如果采用推荐部署方案，控制节点 上一定不会存在哪些分区 ? (多选)BE

```
A. /
B. /srv/BigData/dbdata_om
C. /srv/BigData
D. /srv/BigData/jurnalnode
E. /srv/BigData/hadoop/data5
```


#### 93.FusionInsight Hadoop 集群中，集群规模有 70 个节点，如果采用推荐部署方案，在管理 节点可能存在哪些分区 ? (多选)ABCD

```
A. /srv/BigData/zookeeper
B. /srv/BigData/dbdata_om
C. /srv/BigData
D. /srv/BigData/jurnalnode
E. /srv/BigData/hadoop/data5
```


#### 23.大数据商业咨询服务方案在规划环节主要考虑以下哪些设计 ? (多选)ABCD 

```
A. 大数据商业模式设计
B. 商业场景全景规划
C. 典型场景需求设计
D. 场景分解和业务设计
```


#### 24.FusionInsightHD V100R002C60 版本集群中，以下哪些组件需要规划元数据分区 ?(多选) ABC

```
A. HDFS
B. Zookeeper 
C. Streaming 
D. Redis
E. HBase
F. Kafka
```

#### 25.Hadoop 通过 ResourceManager 对集群资源进行管理，它的主要功能有 ? (多选)ABC 

```
A. 集群资源调度
B. 应用程序管理
C. 集群资源管理
D. 日志管理
```

#### 26.以下关于 Hadoop 的 HDFS 描述正确的有 ? (多选)ACD

```
A. HDFS 由 NameNode ， DataNode ， Client 组成
B. HDFS 备 NameNode 上的元数据是主 NameNode 同步过去的 
C. HDFS 采用就近的机架节点进行数据的第一副本存储
D. HDFS 适合一次写入，多次读取的读写任务
```

#### 27.FusionInsight Manager 可以对哪些项目进行健康检查 ? (多选)AB 

```
A. 主机
B. 服务
C. 角色
D. 实例
```

#### 28.Hadoop 系统中 YARN 支持哪些资源类型的管理 ? (多选)AB

```
A. 内存 B. CPU C. 网络 D. 磁盘空间
```


#### 29.在 SoIrCloud 模式下，以下关于 Solr 相关概念描述正确的有 ? (多选)ABD

```
A. Collection 是在 SoIrCloud 集群中逻辑意义上完整的索引，可以被划分为一个或者多个 Shard ，这些 Shard 使用相同的 Config Set 。
B. Config Set 是 Solr Core 提供服务必须的一组配置文件，包括 solrconfig.xml 和 schema.xml 等。
C. Shard 是 Collection 的逻辑分片，每个 Shard 都包含一个或者多个 replicas ，通过选举 确定哪个 replica 是 Leader ，只有 Leader replica 才能进行处理索引和查询请求。
D. Replica 只有处于 active 状态时才会接受索引和查询请求。
```


#### 30.关于 FusionInsight Manager 功能说法错误的有哪些 ? (多选)BC

```
A. 通过 FusionInsight Manager 的 Audit 审计界面可以查询每个重要操作
B. 通过 FusionInsight Manager 不能下载单个组件的客户端
C. 集群部署完成后，通过 FusionInsight Manager 不能进行集群扩容，只能通过卸载集群重
新搭建来扩容集群
D. 通过 FusionInsight Manager 的 Alarms 告警界面可以查询每个告警的具体信息
```


#### 31.FusionInsightHD 系统中，集群节点规划时需要考虑哪些磁盘规划 ? (多选)ABCD 

```
A. 主机 OS 磁盘规划
B. 控制节点元数据盘规划
C. 管理节点元数据盘规划
D. 数据节点数据磁盘规划
```


#### 32.FusionInsight HD 支持哪些日志下载方式 ? (多选)ABCD

```
A. 下载已安装的所有组件的日志 
B. 下载单个组件某个模块的日志 
C. 下载指定主机的日志
D. 下载指定时间段的日志
```


#### 33.在 FusionInsight 集群规划时，以下哪些集群命名是系统允许的 ? (多选)BCD

```
A. FusionInsight-123 
B. FusionInsigh_123 
C. FusionInsight 123 
D. 123 FusionInsight
```


#### 34.以下哪些是 Spark 可以提供的功能 ? (多选)AD

```
A. 分布式内存计算引擎 B. 分布式文件系统
C. 集群资源的统一调度 D. 流处理功能
```


#### 35.FusionInsight HD LLD 配置规划工具可以生成哪些配置文件 ? (多选)BD 

```
A. 监控告警阈值配置文件
B. 集群的安装模板文件
C. HDFS 和 YARN 的配置文件
D. 执行 precheck 所需要的配置文件 checkNodes.Config
```


#### 36.从生命周期维度看，数据主要经历那几个阶段 ? (多选)ABCD

```
A. 数据采集 B. 数据存储 C. 数据管理 D. 数据分析 E. 数据呈现
```


#### 37.FusionInsight HD 产品中，关于 Kafka 组件部署规划说法正确的是 ? (多选)BD

```
A. Kafka 的 Producer 发送消息时可以指定该消息被哪个 Consumer 消费
B. 在创建 Topic 时，副本数不得大于当前存活的 Broker 实例个数，否则创建 Topic 将会 失败
C. Kafka 安装完成后就不能再配置数据存放目录了
D. Kafka 会将元数据信息存放到 ZooKeeper 上
```


#### 38.安全模式下安装 FusionInsight HD 集群时，哪些组件是必须安装的 ? (多选)BC

```
A. ZooKeeper B. LdapServer C. KrbServer D. HDFS
```



#### 39.FusionInsight HD Manager 界面显示 Hive 服务状态为 Bad 时，可能的原因有哪些 ? (多选)ABC

```
A. DBServioe 服务不可用 B. HDFS 服务不可用
C. Metastore 实例不可用 D. HBase 服务不可用
```


#### 156.YARN 容量调度器的主要特点有哪些 ? (多选)ABCD 

```
A. 容量保证
B. 灵活比
C. 多重租赁
D. 动态更新配置文件
```


#### 41.FusionInsight HD 系统中使用 Streaming 客户端 Shell 命令提交了拓扑之后，使用 Storm UI 查看发现该拓扑长时间没有处理数据，可能原因有 ? (多选)ABC

```
A. 拓扑结构过于复杂或者并发太大，导致 worker 启动时间过长，超过 supervisor 的等待 时间
B. Supervisor 的 slots 资源被耗尽，拓扑提交上去后分不到 slot 去启动 Worker 进程 
C. 拓扑业务存在逻辑错误，提交之后无法正常运行
D. 当数据量较大时，拓扑处理速度较慢
```


#### 162.FusionInsight HD 集群中包含了多种服务，每种服务又由若干角色组成，下面哪些是服 务的角色 ? (多选)BC

```
A. HDFS
B. NameNode 
C. DataNode 
D. HBase
```


#### 43.FusionInsight HD Loader 可以将 HDFS 数据导出到以下哪些目标端 ? (多选)ABCD 

```
A. SFTP 服务器
B. FTP 服务器
C. Oracle 数据库
D. DB2 数据库
```


#### 44.执行 HBase 读数据业务，需要读取哪几部分数据 ? (多选)AC 

```
A. HFile
B. HLog
C. MemStore
D. HDFS
```


#### 45.FusionInsight HD 产品中，关于 Kafka 组件说法正确的有 ? (多选)ACD

```
A. 删除 Topic 时，必须确保 Kafka 的服务配置 delete.topic.enable 配置为 true 
B. Kafka 安装及运行日志保存路径为 /srv/Bigdata/kafka/
C. ZooKeeper 服务不可用会导致 Kafka 服务不可用
D. 必须使用 admin 用户或者 kafkaadmin 组用户进行创建 Topic
```


#### 46.FusionInsight HD 部署过程中，以下关于安装集群说法正确的是 ? (多选)AD

```
A. 支持模板安装和手动安装
B. 首次登陆不用修改 admin 账户密码
C. 对于组网隔离场景，在发现节点步骤的 IP 输入框中，应该输入各个节点的业务 IP 
D. 选择服务时，系统会自动为其选择依赖的底层服务
```


#### 47.FusionInsight HD 系统中使用 Streaming 客户端 Shell 命令查看拓扑或者提交拓扑失 败，以下哪些定位手段是正确的 ? (多选)AB

```
A. 查看客户端异常堆栈，判断是否客户端使用问题
B. 查看主 Nimbus 的运行日志，判断是否 Nimbus 服务端异常 
C. 查看 Supervisor 运行日志，判断是否 Supervisor 异常
D. 查看 Worker 运行日志
```


#### 48.大数据分析相关技术主要特征包括 ? (多选)ABC

```
A. 机器学习，全量特征
B. 数据背后事件关联性分析 
C. 基于海量数据为基础
D. 基于精确样本为基础
```

#### 49.FusionInsight HD 在安装集群成功后，有哪些项需要检查 ? (多选)ABCD 

```
A. Service 组件健康状态
B. 系统是否有告警
C. 服务的配置状态是否为已同步
D. 主机健康状态
```


#### 50.以下关于 Hadoop 分布式文件系统 HDFS 联邦描述正确的有 ? (多选)ACD 

```
A. 一个 Namespace 使用一个 block pool 管理数据块
B. 一个 Namespace 可使用多个 block pool 管理数据块
C. 每个 block pool 的磁盘空间是物理共享的，逻辑空间是隔离的
D. 支持 NameNode/Namespace 水平扩展
```


#### 51.Flume 进程级联时，以下哪些 sink 类型用于接收上一跳 Flume 发送过来的数据 ?AB

```
A avro sink 
B thrift sink 
C HDFS sink 
D Null Sink
```


#### 52.Hadoop 的 HBase 主要特点有哪些 ? (多选)ABCD

```
A 高可靠性 
B 高性能 
C 面向列 
D 可伸缩
```


#### 53.下面哪些数据以非结构化数据为主。ABCD

```
A CRM管理系统
B 地震监测数据
C 淘宝网支付数据
D 银行影像明细
```


#### 54.Spark 可以接收哪些来源的数据?(多选)BCD

```
A YARN 
B HDFS 
C HIVE 
D HBase
```


#### 55.下面那些组件依赖 ZooKeeper?ABCD

```
A. Streaming 
B. HDFS 
C. YARN 
D. HBase
```


#### 56. FusionInsight 家族包含下列哪些子产品()?ABCDE

```
A HD 
B Libra 
C Manager 
D Miner 
E Farmer 
F DWS
```


#### 57.Flume 进程级联时，一下哪些 Sink 类型用于向下一条 Flume 发送数据。 AB

```
A avro sink 
B thift sink 
C HDFS sink 
D Null sink
```


#### 58.下列关于 ZooKeeper 的描述正确的是 AC

```
A ZookKeeper 基于开源 Apache Zookper 主要用于解决分布式应用中经常遇到的一些数据管理问题
B ZooKeeper 作为底层组件被其他组件依赖，而不依赖于其他组件
C 华为 FusionInsight HD 中要求必须部署 ZooKeeper
D ZooKeeper 节点个数要求越多越好
```


#### 59.下面哪些场景不是 Flink 组件擅长的?ABC

```
A 迭代计算 
B 批处理 
C 数据存储 
D 流处理
```


#### 60.下面关于 Flink 窗口的描述错误的是()?AD

```
(多选)
A 滚动窗口在时间上是不重叠的。
B 滑动窗口之间时间点不存在重叠。
C 滚动窗口在时间上是重叠的。
D 滑动窗口之间时间点存在重叠。
```

