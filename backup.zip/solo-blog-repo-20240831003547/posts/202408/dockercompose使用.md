title: docker-compose使用
date: '2024-08-26 09:36:57'
updated: '2024-08-26 09:40:49'
tags: [Docker]
permalink: /articles/2024/08/26/1724636217115.html
---
注意XX都需要自己填写的

```
version: '3'

services:
  ftp:
    image: jiushuokj/ftp
    container_name: ftp
    ports:
      - "20:20"
      - "21:21"
      - "21100-21110:21100-21110"
    volumes:
      - "xx:/home/vsftpd/ftp"
    environment:
      FTP_USER: ftp
      FTP_PASS: ftp
      PASV_ADDRESS: 192.168.x.x
      PASV_MIN_PORT: 21100
    restart: always
    privileged: true # 添加权限
```

