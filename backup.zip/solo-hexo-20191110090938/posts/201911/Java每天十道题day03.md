title: Java每天十道题 - day03
date: '2019-11-05 13:51:01'
updated: '2019-11-05 13:51:01'
tags: [Java-每天十道题]
permalink: /articles/2019/11/05/1572933061054.html
---
## 1.简述面向对象的三大特征

- 封装性：
```
将属性私有化（即用private修饰），并提供公共的get和set方法供外部调用者进行修改操作，若没有get和set方法本包中的另一个类无法使用私有属性，这么做保护了类的内部结构；
```

- 继承性：

```
将共性代码提出，定义在一个类中（即父类）其他需要使用该共性的类（即子类），可以通过extends继承父类，可以减少代码，减少出错率，同时也能使用父类中属性和方法，除去私有属性/方法；
```

- 多态性：

```
对象的多种表现形式，相同的签名和消息，不同的响应。重写重载，对象的上转型，面向接口编程，都是多态的体现。
```

## 2.解释一处编译到处运行的含义

```
因为跨平台。各个操作系统，都有对应的java虚拟机。我们在任意虚拟机中编译好.class，把当前这个class拿到其他操作系统的虚拟机里面，就可以运行。例如，我们在win10下编译好的class文件，就能在CentOS7.4中运行，但前提是win10和CentOS7.4都装了java虚拟机
```

- 步骤：

```
    第一步：Java源代码——.CLASS文件字节码，是java的第一次编译。生成的这个.class文件就是可以到处运行的文件。
```
![image.png](https://img.hacpai.com/file/2019/11/image-0a1d626f.png)

```
    第二步：Java字节码——到目标机器代码；执行是由JVM执行引擎来完成，JAVA的第二次编译。    
```
![image.png](https://img.hacpai.com/file/2019/11/image-497e0aa3.png)

```
    第三步：看完编译过程在这里说“到处运行”就毫不费力了。因为第二次编译就是在JVM中执行的，也就是在任何一个装有“JVM”的操作系统中完成的。JAVA提供了各种不同平台上的虚拟机制，所以可以实现“到处”。
```
![image.png](https://img.hacpai.com/file/2019/11/image-302105f7.png)


## 3.实现多线程的几种方式

```
第一：继承Thread类，重写run（）

第二：实现Runnable接口，重写run（）

第三：实现Callable接口，有返回值

线程池：newCachedThreadPool，newFixedThreadPool，newSingleThreadExecutor，newScheduleThreadPool
```

## 4.使用反射如何创建一个对象，如何调用一个方法

- 创建对象

```
1、使用Class类的静态方法Class.forName(name.class)加载这个类的字节码（注意，加载字节码不等于实例化对象） ，返回 一个Class对象，这个对象代表的是一个字节码文件。
2、通过Class对象的newInstance()方法来创建Class对象对应类的实例。
3、强转成你所需要的对象
```

- 调用方法

```
1.获取运行时类

Class clazz=目标类.class;

2.获取指定方法的Method对象

Method method = clazz.getDeclaredMethod(“test”);

3.取消访问控制

method.setAccessible(true);//私有可访问

4.通过invoke方法调用

method.invoke(类的对象,参数的实参); //当有返回值Object即为对应的返回值，否则为null
```


## 5.简述样式和内容的分离

在 Web 开发中，所谓内容与样式分离，就是让内容的归 HTML, 样式归 CSS, 不要混着用

```
内容：页面上所要展示的内容，属于html
样式：内容显示成什么样子，比如字体颜色等，属于css
两者的分离保证了页面风格的统一，代码的重用，降低了耦合性
```

## 6.ajax的核心含义是什么

局部刷新，异步请求


## 7.解释servlet的生命周期

- 初始化 ==> 服务 ==> 销毁
```
init（）初始化

service() 服务

destroy()销毁
```

[简书详情](https://www.jianshu.com/p/67b1fb7d95d9)


## 8.servlet的作用域有哪些

1、request

```
request是一个请求，只要发送一个请求就会创建一个request对象，这个对象只在本次请求中有效。
```

2、session

```
session是一次会话，服务器会为每一个会话创建一个session对象，session中的数据可以被本次会话中的所有servlet访问，会话是从浏览器打开开始，到关闭浏览器结束。
```

3、application

```
application是应用程序作用域，是从程序开始运行到运行停止。
保存在application作用域中的值，只要程序没有停止运行，都可以获取。
此作用域一般不使用。
```


## 9.解释MVC以及Spring MVC配置的关键点

- MVC:model-view-controller的简称：模型-视图-控制器

```
前端传过来一个请求，找到对应的控制器接受用户的请求，调用相应的模型来进行业务处理，并返回数据给控制器。控制器调用相应的视图来显示处理的结果。并通过视图呈现给用户。
```

- Spring MVC关键点：中央控制器，处理器映射器+处理器适配器，包扫描，handle（程序员自己写的Controller），视图解析，异常处理

## 10.解释控制反转和依赖注入

```
inversion of control，所谓IOC，就是由spring来负责控制对象的生命周期和对象间的关系。不同于传统的程序开发，在一个对象中，如果要使用另外的对象，就必须得到它(自己new一个)，使用完之后还要将对象销毁(比如Connection)，对象始终会和其他的接口或类耦合起来。在spring中，所有的类都会在spring容器中登记，类的创建，销毁都是由spring控制，也就是说控制对象生命周期的不再是引用它的对象，而是spring。

动态地向某个对象提供它所需要的其他对象，这一点是通过DI(Dependency Injection, 依赖注入)来实现的。比如对象A需要操作数据库，以前我们是通过在A中自己编写代码来获得一个Connection对象，有了spring后我们只需要告诉spring，A中需要一个Connection，spring会在适当的时候制造一个Connection，注射到A当中，这样就完成了对各个对象之间关系的控制。spring就是通过反射来实现注入的。
```
