title: HTML学习
date: '2019-09-17 00:28:13'
updated: '2019-09-17 19:54:18'
tags: [HTML]
permalink: /articles/2019/09/17/1568652644765.html
---
# 

# 1. 什么是html

```
HTML 是用来描述网页的一种语言。
HTML 指的是超文本标记语言 (Hyper Text Markup Language) 
标记语言是一套标记标签 (markup tag) 
HTML 使用标记标签来描述网页 
```

- 发展史

```
html
html2.0
html3.0
html4.0
xhtml（写代码必须要严格规范，这个版本的html是遵守严格规范）
html4.0
html5（2013年出现，15年被广泛运用）
```

- 三个维护html的组织结构

```
w3c（万维网联盟）
网页技术工作组（各大浏览器厂商组成）
internet协议团队
```

# 2.  html规范

- html有一套标记标签

- 创建一个hello.html文件

```
注意点：开启windon中的文件后缀名
```

```html
<h1>静夜思</h1>
<hr/>
<p style="color:red" title="xixi">举头望明月，</p>
<hr/>
<p title="haha">低头思姑娘！</p>
```

```
<h1></h1><p></p>....这些就是html中的标签
```

- html中的标签又一套规范

```
 html中的标签可以称为元素
 HTML 元素以开始标签起始，以结束标签终止;
 元素的内容是开始标签与结束标签之间的内容 
 某些 HTML 元素具有空内容（empty content） 
 空元素在开始标签中进行关闭（以开始标签的结束而结束） 
 大多数 HTML 元素可拥有属性 
```

```
<h1><p>就是开始标签
</h1></p>就是结束标签
<hr/>空元素（空标签）
```

```
style="color:red"就是标签中的属性
title="haha"也是标签中的属性
```

- html中的属性规范

```
 语法：属性名="属性值"
 属性名使用小写
 属性值必须加引号
 属性的值可能会存在多个值，有的用";"隔开，有的用"空格"隔开
 属性与属性之间用空格隔开
```

# 3. HTML的基本结构

- 骨架
- 在idea开发工具中创建一个网页（html文件）
- 统一idea的settings

```
 修改主题
 修改字体
```

```html
<!DOCTYPE html>
<!-- html5的声明 -->

<!--<html></html> 根标签 -->
<html lang="en">
  <!--<head></head>头标签-->
  <head>

  </head>

  <!--<body></body>身体标签-->
  <body>

  </body>
</html>
```

- 总结

```
 标签一般成对出现
 标签可以嵌套，必须要正确嵌套
```

- head标签中有什么？

```
 元标签
<meta charset="UTF-8">
       
 作用
主要是用来设置网页的基本配置
```

```
  标题标签
<title>Title</title>

 作用
显示该网页的标题
```

```
 引入外部css样式的标签<link>
 编写样式内容的标签<style>
```

- body标签中有什么？

```
 网页内容显示的东西全部写在body标签中
```

- 总结

```
head中写配置，body中写内容！
```

# 4. 网页中常见的标签

- 标题

```
h1~h6
```

```html
<h1>我是大标题h1</h1>
<h2>我是标题h2</h2>
<h6>我是小标题h6</h6>
```

- 水平线

```
<hr>或者<hr/>
```

- 段落

```
<p>
```

```html
<p>
  江苏万和计算机培训中心创立于1993年，是江苏省成立最早、规模最大的IT教育专业机构。二十多年来一直坚持不懈的努力做好IT教育，通过规范化、标准化、专业化服务流程实施，硕果斐然，已成功为社会培养各类中高级专业技术人才超过100000人，被誉为江苏省国际服务外包人才培训基地、南京市国际服务外包人才培训机构及南京市软件人才培训基地，中国十大IT培训品牌之一！
</p>
```

- 换行（文字与文字之间的换行）

```
<br>或者<br/>
```

```html
<p>
  江苏万和计算机培训中心创立于1993年，是江苏省<br>成立最早、规模最大的IT教育专业机构。二十多年来一直坚持不懈的努力做好IT教育，通过规范化、标准化、专业化服务流程实施，硕果斐然，已成功为社会培养各类中高级专业技术人才超过100000人，被誉为江苏省国际服务外包人才培训基地、南京市国际服务外包人才培训机构及南京市软件人才培训基地，中国十大IT培训品牌之一！
</p>
```

- 快捷方式

```html
<!--ctrl + d : 复制光标所在的那一行，并且直接在光标下一行粘贴 -->
<!--ctrl + x : 删除光标所在的一行 -->
<!--注释的快捷方式：ctrl+/-->
```

- 字体标签

```
由于font标签过时了，请用span代替!
```

```html
<i>斜体</i>
<em>强调斜体</em>
<b>加粗</b>
<strong>强调加粗</strong>
<font>正常字体(过时)</font>
<span>正常字体</span>
```

# 5. html中的实体

- 实体就相当于java中的转义

```
空格		   
<			<
>			>
&			&
```

```html
<p>江苏万和    算机培训中心创立于1993年</p>

<p><h1>是大标题标签</p>
```

# 6. 图像标签

- 路径学习（常识）

```
 路径分类
1、绝对路径
2、相对路径
```

- 绝对路径

```
 完全路径，无论自己在什么地方，都能够访问到目标资源
 带http协议和主机名以及端口号的路径就是绝对路径
http://localhost:63342/day01/img/yangmi.jpg
```

- 相对路径

```
 相对自身，自己改变了，想要访问到目标资源，你的路径也要改变
 路径是以./或者../开始
./ 表示当前目录(可以省略)
../ 表示上一级目录
```

- 图像标签

```tml
<img src="" alt="">
src="url" 规定显示图像的url(路径)。
alt="text" 规定图像的替代文本(只有图片不显示的时候，才会替代)。
```

```html
<!--绝对路径显示-->
<img src="http://localhost:63342/day01/img/yangmi.jpg" alt="大幂幂1">

<!--相对路径显示-->

<!-- ./ 表示该文件所在的当前目录-->
<img src="./img/yangmi.jpg" alt="大幂幂2">

<!-- ../ 表示该文件所在的上一级目录 -->
<img src="../img/yangmi.jpg" alt="大幂幂3">
```

- 图像标签的其他属性

```
width="数字"
height="数字"

注意点：如果高度和宽度只设置一个值，另一个值等比缩放
```

```html
<img src="img/yangmi.jpg" alt="大幂幂2222" width="100"  height="200">
```

# 7. 链接标签

- 功能1：基本跳转

```
在一个页面上写一个链接，点击能够进入另一个页面

<a href="url" target="_blank"></a>	就表示链接标签
href="url"定链接指向的页面的 URL。
target="_self/_ blank/__parent/__top/framename" 规定在何处打开链接文档。
```

```html
<a href="./success.html">成功(基本跳转)</a>
```

- 功能2：重新开启一个窗口进行页面跳转

```html
<a href="https://www.baidu.com/" target="_blank">百度(开启一个窗口跳转)</a>
```

- 功能3：锚点技术

```
语法：<a href="锚">链接</a>
```

```html
<a href="toOne">第一章节</a>
<a href="toTwo">第二章节</a>
<a href="toThree">第三章节</a>

<!--id：id的值唯一-->
<h1 id="toOne">第一章节：群雄崛起</h1>
<p>aaa</p>
<p>aaa</p>
<h1 id="toTwo">第二章节：三分天下</h1>
<p>bbb</p>
<p>bbb</p>
<h1 id="toThree">第三章节：天下一统</h1>
<p>ccc</p>
<p>ccc</p>
```

# 8. 列表标签

- 有序列表

```html
<!-- ol>li*4 + tab  ol下面有儿子li,且4个 -->

<!--ol 有序列表(order list)-->
<!--属性type="1、A、a、I、i"-->
<ol type="1" start="3">
  <!-- li 列表项（list item） -->
  <li>苹果</li>
  <li>芒果</li>
  <li>百香果</li>
  <li>牛油果</li>
</ol>
<ol type="i">
  <li>苹果</li>
  <li>芒果</li>
  <li>百香果</li>
  <li>牛油果</li>
  <li>奇异果</li>
</ol
```

- 无序列表

```html
<!--ul  无序列表-->
<!--type=" disc、square、circle、none"-->
<ul>
  <li>AAA</li>
  <li>BBB</li>
  <li>CCC</li>
  <li>YYY</li>
</ul>
<ul type="none">
  <li>aaa</li>
  <li>bbb</li>
  <li>ccc</li>
  <li>ddd</li>
</ul>
```

- 定义列表（了解）

```html
<!--dl 定义列表-->
<dl>
  <!--定义列表的标题-->
  <dt>定义标题1</dt>
  <!--定义列表的描述-->
  <dd>定义描述1111....</dd>
  <dt>定义标题2</dt>
  <dd>定义描述22222....</dd>
  <dt>定义标题3</dt>
  <dd>定义描述33333....</dd>
</dl>
```

# 9. 标签分类

- 两类

```
 块级标签
块级元素能够独占一行，有div、h1~h6、p、ul、ol、li....

 行内（内联）标签
行内元素通常不会以新行开始，有a、img、label、span、i、b、em....
```

```html
<h1>静夜思123</h1>
<p style="color:red">举头望明月，</p>
<p title="haha">低头思姑娘！</p>
<ul>
  <li>aaa</li>
  <li>bbb</li>
  <li>ccc</li>
  <li>ddd</li>
</ul>
<hr>
<img src="img/yangmi.jpg" alt="" width="100px">
<a href="">百度</a>
<i>我是斜体</i>
```
