title: Docker基础使用
date: '2019-12-04 19:52:37'
updated: '2024-08-26 19:30:57'
tags: [Docker]
permalink: /articles/2019/12/04/1575460357179.html
---
# 1. 安装Docker

参考 [Docker 安装](https://www.runoob.com/docker/ubuntu-docker-install.html)

# 2. docker添加国内镜像

- 第一步：更换镜像地址

在服务器本机的/etc/docker/下新建daemon.json,并输入以下内容：

```json
{
"registry-mirrors": ["https://d2mejsvf.mirror.aliyuncs.com"]
}
```

* 科大镜像：`https://docker.mirrors.ustc.edu.cn`
* 网易：`https://hub-mirror.c.163.com`
* 阿里云：`https://<你的ID>.mirror.aliyuncs.com`
* 七牛云加速器：`https://reg-mirror.qiniu.com`

阿里云的可以去 [阿里云](https://help.aliyun.com/document_detail/60750.html) 自行申请

- 第二步：重启docker
  
  1、systemctl daemon-reload   //载入daemon.json
  
  2、systemctl restart docker   //重启docker
- 第三步：使用 `docker info` 查看是否更换成功

# 3. 常用命令

## 3.1. 镜像命令

| 操作 | 命令                                            | 说明                                                     |
| ------ | ------------------------------------------------- | ---------------------------------------------------------- |
| 检索 | docker  search 关键字  eg：docker  search redis | 我们经常去docker  hub上检索镜像的详细信息，如镜像的TAG。 |
| 拉取 | docker pull 镜像名:tag                          | :tag是可选的，tag表示标签，多为软件的版本，默认是latest  |
| 列表 | docker images                                   | 查看所有本地镜像                                         |
| 删除 | docker rmi image-id                             | 删除指定的本地镜像                                       |

## 3.2. 容器命令

```shell
1、根据镜像启动容器  
    docker run --name mytomcat -d tomcat:latest  
2、docker ps   
    查看运行中的容器  
3、查看所有的容器  
    docker ps -a  
4、启动容器  
    docker start 容器id  
5、 停止运行中的容器  
    docker stop  容器的id  
8、删除一个容器  
     docker rm 容器id  
9、查看容器的日志  
    docker logs 容器id  
10、进入容器  
    docker exec -it 容器id /bin/bash
```

# 4. 常用安装

## 4.1. mysql

```shell
docker pull mysql:5.7.25   
docker run --restart=always -d -p 3306:3306  --name mysql5 -e   MYSQL_ROOT_PASSWORD=root mysql:5.7.25
```

## 5.2. 示例

### 5.2.1. mysql安装

```shell
# 摘取镜像  
docker pull 192.168.100.205:5000/mysql  
# 安装容器  
docker run --restart=always -d -p 3306:3306  --name mysql5 -e   MYSQL_ROOT_PASSWORD=root 192.168.100.205:5000/mysql  
# --restart=always  开机启动  
# -d 后台启机  
# -p 端口映射  
# -name 容器名称  
# -e 参数  
# 192.168.100.205:5000/mysql 镜像
```

