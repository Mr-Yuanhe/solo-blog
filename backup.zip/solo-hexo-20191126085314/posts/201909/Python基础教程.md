title: Python基础教程
date: '2019-09-19 14:49:42'
updated: '2019-09-19 14:49:42'
tags: [Python]
permalink: /articles/2019/09/19/1568875782008.html
---
# 该文档主要内容如下

1. Python介绍
2. 变量和数据类型
3. 运算符和表达式
4. 控制流语句
5. 复合数据类型
6. 函数
7. 模块和包
8. 标准库
9. 面向对象
10. 异常处理
11. Python进阶

- 仅限电脑游览
[查看文档](http://code.yuanheweb.com/python/index)

- 如需下载至本地，请至友情链接中的文件集合点击下载Python基础教程

