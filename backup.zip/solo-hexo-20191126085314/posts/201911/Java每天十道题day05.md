title: Java每天十道题 - day05
date: '2019-11-07 20:34:41'
updated: '2019-11-19 13:47:30'
tags: [Java-每天十道题, Java面试题]
permalink: /articles/2019/11/07/1573130081367.html
---
## 1.final, finally, finalize的区别； throw , throws的区别；break ,continue, return的区别； if else/ switch case defualt的区别；interface与抽象类的区别；重写与重载的区别；对象的上转型与面向接口编程的区别

- final, finally, finalize的区别

1.final是修饰符（关键字）

```
final 修饰的类叫最终类，该类不能被继承。
final 修饰的方法不能被重写。
final 修饰的变量叫常量，只能赋值一次，不能被更该。
```

2.finally

```
配合try-catch使用，只要执行try或者catch就必须执行finally，一般做资源的释放，如关闭文件等。
例外：在try或者catch执行System.exit(0);java虚拟机直接关闭，finally自然不会执行了
```

3.finalize

```
finalize() 方法的作用是在垃圾收集器将对象从内存中清除出去之前做必要的清理工作
```
[简书详情](https://www.jianshu.com/p/f099e8b149f2)


- throw , throws的区别

```
1、throw用于方法内部，throws用于方法声明上  
2、throw后跟异常对象，throws后跟异常类型  
3、throw后只能跟一个异常对象，throws后可以一次声明多种异常类型
```
- break ,continue, return的区别

```
break：  
1、用于完全结束一个循环，跳出循环体执行循环后面的语句。  
2、当break出现在循环体中的switch语句体内时，其作用只是跳出该switch语句体。
continue：
跳过当次循环中剩下的语句，执行下一次循环。  
return：  
1、从当前方法中退出，返回调用的开始。  
2、返回一个值给调用该方法的语句，返回值的数据类型必须与方法的声明中的返回值的类型一致。
```
-  if else/ switch case defualt的区别

```
if else 
一个一个顺序的进行判断，找到就终止，找不到就判断到最后

switch...case会生成一个跳转表来指示case分支的地址，不用像if...else...if那样遍历条件分支直到命中条件，而只需访问对应索引号的表项从而到达定位分支的目的。时间效率较高，但需要较多的存储空间。  defualt是case中没有找到才执行的。

此外，switch...case只能处理case为常量的情况，并不能处理区间判断的情况。例如：if (a > 10 && a < 20)用switch...case是无法处理的。
```

- 对象的上转型与面向接口编程的区别

```
上转型对象不能操作子类新增的成员变量，不能调用子类新增的方法。
上转型对象可以访问子类继承和隐藏的成员变量，也可以调用子类继承的方法或子类重写的方法。
```


## 2.String, StringBuilder, StringBuffer的区别是什么

```
1.String里面存储的是一个常量，不可改变，对String的频繁操作会在常量区产生大量碎片数据
2.StringBuffer可以进行字符创的拼接，线程安全，效率相对StringBuilder较低
3.StringBuilder也进行进行字符串的拼接，线程不安全，效率更高
单线程使用StringBuilder较好，多线程使用StringBuffer较好
```

## 3.解释笛卡尔乘积，水平过滤，垂直过滤

```
1.笛卡尔乘积是在表连接的时候进行的运算，如一张表是10条数据，另外一张表20条，相乘的结果是200条记录，笛卡尔乘积罗列出了所有的可能性；
2.水平过滤是在where子句之后的过滤，过滤出正确或者要求的记录。行
3.垂直过滤是在select后面，过滤出我们关心的数据。列
```


## 4.数据库的组函数有哪些？怎么使用

```
COUNT():用于统计数据数量 用于select语句和group by having语句
SUM():用于统计数据和
AVG()：统计平均值
MIN()：得到最小值
MAX()：得到最大值
```

## 5.如何做到页面加载完毕就执行js语句

```
1.window.onload
2.$(document).ready(function(){ });
3.$(function(){ });
```


## 6.input的类型有哪些

```
text		文本
password	密码
file		文件
hidden		隐藏
button		按钮
checkbox	复选框
radio		单选按钮
image		图片
submit		提交
reset		重置
```


## 7.解释监听器、过滤器以及servlet以及拦截器的区别

1.servlet

```
servlet是一种运行服务器端的java应用程序，具有独立于平台和协议的特性，
可以动态生成web页面它工作在客户端请求与服务器响应的中间层；
    servle的生命周期开始于被装入web服务器的内存中，并在web服务终止或者重新装入servlet的时候结束；servlet一旦被装入web服务器，一般不会从web服务器内存中删除；直到web服务器关闭；
　　装入：启动服务器时加载servlet的实例；
　　初始化：web服务器接收到请求时，或者两者之间的某个时刻启动，调用init（）
　　调用：从第一次到以后的多次访问，都只调用doGet（）或dopost）（）方法；
　　销毁；停止服务器时调用destroy（）方法，销毁实例
```

2.filter：

```
filter是一个可以复用的代码片段，可以用来转换HTTP请求，响应和头信息。
它不能产生一个请求或者响应，它只是修改对某一资源的请求或者响应；
　　需要实现javax.servlet包的Filter接口的三个方法init（），doFilter（），destroy（）；
　　加载：启动服务器时加载过滤器的实例，并调用init（）方法；
　　调用：每次请求的时候只调用方法doFilter（）进行处理；
　　销毁：服务器关闭前调用destroy（）方法，销毁实例
```

3.listener

```
监听器，通过listener可以坚挺web服务器中某一执行动作，并根据其要求作出相应的响应。就是在application，session，request三个对象创建消亡或者往其中添加修改删除属性时自动执行代码的功能组件；
    web.xml的加载顺序是：context-param->listener->filter->servlet

```

4.interceptor

```
拦截器是对过滤器更加细化的应用，他不仅可以应用在service方法前后还可以应用到其他方法的前后加载配置文件后初始化拦截器，当有对action的请求的时候，调用interceptor方法，最后也是根据服务器停止进行销毁；
①拦截器是基于java的反射机制的，而过滤器是基于函数回调。
②拦截器不依赖与servlet容器，过滤器依赖与servlet容器。
③拦截器只能对action请求起作用，而过滤器则可以对几乎所有的请求起作用。
④拦截器可以访问action上下文、值栈里的对象，而过滤器不能访问。
⑤在action的生命周期中，拦截器可以多次被调用，而过滤器只能在容器初始化时被调用一次。
⑥拦截器可以获取IOC容器中的各个bean，而过滤器就不行，这点很重要，在拦截器里注入一个service，可以调用业务逻辑。
```

## 8.解释服务器端跳转和客户端跳转

```
客户端跳转时用HttPservletResopse对象的sendRedirect（重定向）函数实现，服务器端跳转是使用RequestDispather（转发）对象的forward方法实现的。

使用服务器端跳转时，客户浏览器的地址栏并不会显示目标地址的URL，而是用客户端跳转时，地址栏当中会显示目标资源的URL；
服务器端跳转是由客户端发送一个请求，请求一个服务器资源——如JSP和Servlet，这个资源又将请求转到另一个服务器资源，然后再给客户端发送一个响应，也就是说服务器端跳转是客户端发送一次请求，服务器端给出一次响应；而客户端跳转的流程则不同。客户端同样是发送一个请求给服务器端资源，这个服务器资源会首先给客户端一个响应，客户端再根据这个响应当中所包含的地址，再次向服务器端发送一个请求，也就是说客户端跳转是两次请求，两次响应
```


## 9.延迟加载是什么意思

延迟加载又称懒加载，就是用到的时候才回去查数据库，用于减轻服务器压力。

```
Mybatis的延迟加载功能默认是关闭的
需要在SqlMapConfig.xml文件中通过setting标签配置来开启延迟加载功能
开启延迟加载的属性：
lazyLoadingEnabled：全局性设置懒加载。如果设为‘false’，则所有相关联的都会被初始化加载。默认为false
```

## 10.介绍一下shiro

```
模块：认证、授权、session管理、rememberme、加密、websurport
关键点：subject(所有的登录或者申请授权者)、SecurityManager(调用验证逻辑和管理subject)、Realm(账号和密码所在地，类似datasource，一般要用户自己实现AuthorizingRealm)
配置：web.xml中设置一个过滤器委托代理DelegatingFilterProxy，要对应到一个springbean的过滤器ShiroFilterFactoryBean上面，关键的属性有：loginurl， nopermmisionurl, unauthorizedUrl，filterChainDefinitions（anon, user， authc）
```


