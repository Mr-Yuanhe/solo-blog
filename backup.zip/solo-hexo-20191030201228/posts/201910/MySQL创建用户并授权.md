title: MySQL创建用户并授权
date: '2019-10-25 23:39:56'
updated: '2019-10-29 18:38:52'
tags: [MySQL]
permalink: /articles/2019/10/25/1572017996312.html
---
## 1.创建用户

```sql
CREATE USER 'username'@'host' IDENTIFIED BY 'password';
```

- *username*：你将创建的用户名 非必须情况下，不太建议使用 root 用户
- *host*：指定该用户在哪个主机上可以登陆，如果是本地用户可用 localhost，如果想让该用户可以从任意远程主机登陆，可以使用通配符 %
- *password*：该用户的登陆密码，密码可以为空，如果为空则该用户可以不需要密码登陆服务器。

案例：创建用户test并且可以从任意远程主机登陆
```sql
CREATE USER 'test'@'%' IDENTIFIED BY '你的密码';
```

## 2.修改用户名和密码

- 查看初始密码

>MySQL 安装完成之后，在 /var/log/mysqld.log 文件中给 root 生成了一个默认密码。查看 /var/log/mysqld.log 文件，获取并记录 root 用户的初始密码

```sql
grep 'temporary password' /var/log/mysqld.log
```
```sql
2019-04-28T06:50:56.674085Z 1 [Note] A temporary password is generated for root@localhost: 3w)WqGlM7-o,

root@localhost:后面的是密码
```

- 重置
```sql
mysql -uroot -p你找到的密码
ALTER USER 'root'@'localhost' IDENTIFIED BY '你的新密码';
```

## 3.远程登录权限
  
- 授权

```sql
GRANT privileges ON databasename.tablename TO 'username'@'host'；
```

>privileges：用户的操作权限，如 SELECT，INSERT，UPDATE 等，如果要授予所的权限则使用 ALL

>databasename：数据库名

>tablename：表名，如果要授予该用户对所有数据库和表的相应操作权限则可用表示，如.*

- 授予用户test权限

```sql
grant all on *.* to 'test'@'%'IDENTIFIED BY '你的密码';
```

- 刷新
flush privileges;

## 4.用户操作数据库权限

- 所有表的所有增删改查等操作权限，语句如下：

```
grant all on *.* to 用户名@'%' identified by '密码';
```

- 定义给用户hehe操作test库的goods表的insert，select，update的权限
```sql
grant  insert,select,update  on test@'localhost'  identified  by  '密码';
```
