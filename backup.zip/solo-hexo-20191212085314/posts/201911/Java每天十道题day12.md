title: Java每天十道题 - day12
date: '2019-11-19 13:45:44'
updated: '2019-11-19 13:45:44'
tags: [Java-每天十道题, Java面试题]
permalink: /articles/2019/11/19/1574142344773.html
---
## 1.spring的启动过程是什么

```
1.启动一个WEB项目的时候,容器(如:Tomcat)会去读它的配置文件web.xml.读两个节点: <listener></listener> 和 <context-param></context-param>

2.紧接着,容器创建一个ServletContext(上下文),这个WEB项目所有部分都将共享这个上下文.

3.容器将<context-param></context-param>转化为键值对,并交给ServletContext.

4.容器创建<listener></listener>中的类实例,即创建监听.

5.在监听中会有contextInitialized(ServletContextEvent args)初始化方法,在这个方法中获得ServletContext = ServletContextEvent.getServletContext();
context-param的值 = ServletContext.getInitParameter("context-param的键");

6.得到这个context-param的值之后,你就可以做一些操作了.注意,这个时候你的WEB项目还没有完全启动完成.这个动作会比所有的Servlet都要早.

7.以上是父容器的启动那个过程，接下来将启动子容器DispatcherServlet（配置了load-on-startup）。
```

## 2.如何自定义拦截器

```
SpringMVC的拦截器HandlerInterceptorAdapter对应提供了三个preHandle，postHandle，afterCompletion方法。preHandle在业务处理器处理请求之前被调用，  
postHandle在业务处理器处理请求执行完成后,生成视图之前执行，afterCompletion在DispatcherServlet完全处理完请求后被调用,可用于清理资源等 。所以要想实现自己的权限管理逻辑，需要继承HandlerInterceptorAdapter并重写其三个方法。
```
```xml
<!--配置拦截器, 多个拦截器,顺序执行 -->

<mvc:interceptors>

<mvc:interceptor>

<!-- 匹配的是url路径， 如果不配置或/**,将拦截所有的Controller -->

<mvc:mapping path="/" />

<mvc:mapping path="/user/**" />

<mvc:mapping path="/test/**" />

<bean class="com.alibaba.interceptor.CommonInterceptor"></bean>

</mvc:interceptor>

<!-- 当设置多个拦截器时，先按顺序调用preHandle方法，然后逆序调用每个拦截器的postHandle和afterCompletion方法 -->

</mvc:interceptors>
```

## 3.maven里面本地仓库和中央仓库的区别？全局设置和用户设置的区别？groupid和artifactid的区别？依赖的生命周期是什么

```
本地仓库指的是下载jar包到本地的路径
中央仓库指的是jar包从哪个网络地址下载。

以上两个地址都是在setting.xml中配置。
```

```
全局设置是指maven的安装目录下conf里面的setting.xml；用户设置是指在.m2下的setting.xml。
```

```
groupid、artifctid以及version组成了jar包的坐标
```

- 依赖的声明周期：
```
1.compile： 默认编译依赖范围。对于编译，测试，运行三种classpath都有效
2.test：测试依赖范围。只对于测试classpath有效
3.provided：已提供依赖范围。对于编译，测试的classpath都有效，但对于运行无效。因为由容器已经提供，例如servlet-api
4.runtime:运行时提供。例如:jdbc驱动
```
## 4.delete与truncate的区别

```
delete是一条一条删除，打了日志，即便提交也能恢复。
truncate是截断，不可恢复，效率更高。
```

## 5.数据库事务的隔离级别

- 如果不考虑事务的隔离性，会发生的几种问题：
```
脏读是指在一个事务处理过程里读取了另一个未提交的事务中的数据；不可重复读是指在对于数据库中的某个数据，一个事务范围内多次查询却返回了不同的数据值，这是由于在查询间隔，被另一个事务修改并提交了；幻读是事务非独立执行时发生的一种现象。例如事务T1对一个表中所有的行的某个数据项做了从“1”修改为“2”的操作，这时事务T2又对这个表中插入了一行数据项，而这个数据项的数值还是为“1”并且提交给数据库。而操作事务T1的用户如果再查看刚刚修改的数据，会发现还有一行没有修改，其实这行是从事务T2中添加的，就好像产生幻觉一样，这就是发生了幻读。
```
- 数据库为我们提供的四种隔离级别：
```
① Serializable (串行化)：可避免脏读、不可重复读、幻读的发生。
② Repeatable read (可重复读)：可避免脏读、不可重复读的发生。
③ Read committed (读已提交)：可避免脏读的发生。
④ Read uncommitted (读未提交)：最低级别，任何情况都无法保证。
```

## 6.OSI网络七层协议、TCP与UDP的区别、
>物理层、数据链路层、网络层、传输层、会话层、表示层和应用层。

- 区别
```
TCP的优点： 可靠，稳定 TCP的可靠体现在TCP在传递数据之前，会有三次握手来建立连接，而且在数据传递时，有确认、窗口、重传、拥塞控制机制，在数据传完后，还会断开连接用来节约系统资源。 
TCP的缺点： 慢，效率低，占用系统资源高，易被攻击 。
UDP的优点： 快，比TCP稍安全 UDP没有TCP的握手、确认、窗口、重传、拥塞控制等机制
UDP的缺点： 不可靠，不稳定 因为UDP没有TCP那些可靠的机制，在数据传递时，如果网络质量不好，就会很容易丢包。
```
- 用法
```
什么时候应该使用TCP： 当对网络通讯质量有要求的时候，比如：整个数据要准确无误的传递给对方，这往往用于一些要求可靠的应用，比如HTTP、HTTPS、FTP等传输文件的协议，POP、SMTP等邮件传输的协议。
  在日常生活中，常见使用TCP协议的应用如下： 浏览器，用的HTTP FlashFXP，用的FTP Outlook，用的POP、SMTP Putty，用的Telnet、SSH QQ文件传输

什么时候应该使用UDP： 当对网络通讯质量要求不高的时候，要求网络通讯速度能尽量的快，这时就可以使用UDP。
  比如，日常生活中，常见使用UDP协议的应用如下： QQ语音 QQ视频 TFTP
```


## 7.项目基本信息有哪些?你最近做的项目的基本信息是什么？

>TODO...

## 8.svn的使用要注意什么

```
提交之前先更新，小粒度提交，测试正确在提交，提交之时要注明此次提交的原因和目的，慎重覆盖本地代码
```

## 9.tomcat当中在哪里修改http访问端口？如果tomcat启动失败.应该怎么解决？

> server.xml.

如果启动失败，应该去查看logs当中的日志。

## 10.项目中遇到一个问题.怎么解决？



