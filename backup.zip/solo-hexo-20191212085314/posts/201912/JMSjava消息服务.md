title: JMS - java消息服务
date: '2019-12-09 13:36:04'
updated: '2019-12-10 20:02:45'
tags: [Java]
permalink: /articles/2019/12/09/1575869764040.html
---
# 1. 消息服务简介

## 1.1. JMS概念

- JMS：(Java Message Service) -- Java消息服务，是一个Java平台中关于面向消息中间件（MOM）的API，用

  于在两个应用程序之间，或分布式系统中发送消息，进行异步通信。

- JMS 是一个与具体平台无关的API，绝大多数MOM提供商都对JMS提供支持。

## 1.2. 什么是MQ、AMQP和RabbitMQ

- MQ全称为Message Queue，即消息队列

- AMQP ：Advanced Message Queue，高级消息队列协议。它是应用层协议的一个开放标准，为面向消息的

  中间件设计，基于此协议的客户端与消息中间件可传递消息，并不受产品、开发语言等条件的限制。

- RabbitMQ是由erlang语言开发，基于AMQP（**Advanced Message Queue 高级消息队列协议**）协议实现的

  消息队列，它是一种应用程序之间的通信方法，消息队列在分布式系统开发中应用非常广泛。

- RabbitMQ 最初起源于金融系统，用于在分布式系统中存储转发消息，在易用性、扩展性、高可用性等方面表

  现不俗。

- RabbitMQ官方地址：http://www.rabbitmq.com

## 1.3. JMS和AMQP对比

- JMS
  - 是Java消息服务的规范
  - 基于jvm消息代理的规范
  - 用@JmsListener监听消息
  - JMS是java提供的一套消息服务API标准，其目的是为所有的java应用程序提供统一的消息通信的标准，类似java的 jdbc，只要遵循jms标准的应用程序之间都可以进行消息通信。
- `AMQP`(Advacnce Message Queuing Protocol)
  - 高级消息队列协议，是一个消息代理的规范，兼容JMS
  - RabbitMQ 是AMQP的实现
  - 用@RabbitListener(AMQP)监听消息
  - 它和AMQP有什么 不同，jms是java语言专属的消息服务标准，它是在api层定义标准，并且只能用于java应用；而AMQP是在协议层定义的标准，是跨语言的 。

## 1.4. 应用场景

在实际应用中常用的使用场景：异步处理，应用解耦，流量削锋和消息通讯四个场景

- 异步处理

  ![](http://yuanheweb.com/img/mq/QQ20190811-183443.png)

  - 应用解耦

    ![](http://yuanheweb.com/img/mq/QQ20190811-183606.png)

  - 流量削峰

    ![](http://yuanheweb.com/img/mq/QQ20190811-183632.png)

## 1.5.  其它消息队列

- - ActiveMQ
  - RabbitMQ
  - ZeroMQ
  - Kafka
  - MetaMQ
  - RocketMQ
  - Redis

## 1.6. 消息服务中的两大概念

- 消息服务中的两大概念是:

  - 消息中间件服务器——`消息代理(message broker)`和`目的地(destination)`

    消息发送者发送消息以后，由消息代理接管，消息代理保证消息传递到指定的`目的地`。

  - 消息队列主要的两种形式的`目的地`

    - 队列(queue):`点对点`(point-to-point)消息通信
    - 主题(topic):`发布(publish)/订阅`(subsrcibe)消息通信

    


## 1.7. 架构图与主要概念

### 1.7.1. 架构图

![](http://yuanheweb.com/img/mq/121.jpg)

![](http://yuanheweb.com/img/mq/1.jpg)

### 1.7.2. 主要概念

RabbitMQ Server： 也叫broker server，它是一种传输服务。 他的角色就是维护一条从Producer到Consumer的路线，保证数据能够按照指定的方式进行传输。

Producer： 消息生产者，如图A、B，数据的发送方。消息生产者连接RabbitMQ服务器然后将消息投递到Exchange。

Consumer：消息消费者，如图1、2、3，数据的接收方。消息消费者订阅队列，RabbitMQ将Queue中的消息发送到消息消费者。

Exchange：生产者将消息发送到Exchange（交换器），由Exchange将消息路由到一个或多个Queue中（或者丢弃）。Exchange并不存储消息。RabbitMQ中的Exchange有direct、fanout、topic、headers四种类型，每种类型对应不同的路由规则。

Queue：（队列）是RabbitMQ的内部对象，用于存储消息。消息消费者就是通过订阅队列来获取消息的，RabbitMQ中的消息都只能存储在Queue中，生产者生产消息并最终投递到Queue中，消费者可以从Queue中获取消息并消费。多个消费者可以订阅同一个Queue，这时Queue中的消息会被平均分摊给多个消费者进行处理，而不是每个消费者都收到所有的消息并处理。

RoutingKey：生产者在将消息发送给Exchange的时候，一般会指定一个routing key，来指定这个消息的路由规则，而这个routing key需要与Exchange Type及binding key联合使用才能最终生效。在Exchange Type与binding key固定的情况下（在正常使用时一般这些内容都是固定配置好的），我们的生产者就可以在发送消息给Exchange时，通过指定routing key来决定消息流向哪里。RabbitMQ为routing key设定的长度限制为255bytes。

Connection： （连接）：Producer和Consumer都是通过TCP连接到RabbitMQ Server的。以后我们可以看到，程序的起始处就是建立这个TCP连接。

Channels： （信道）：它建立在上述的TCP连接中。数据流动都是在Channel中进行的。也就是说，一般情况是程序起始建立TCP连接，第二步就是建立这个Channel。

VirtualHost：权限控制的基本单位，一个VirtualHost里面有若干Exchange和MessageQueue，以及指定被哪些user使用。

# 2. 走进RabbitMQ

## 2.1. docker环境下的安装

（1）下载镜像：（此步省略）

```shell
docker pull rabbitmq:3.7.12-management
```

（2）创建容器，rabbitmq需要有映射以下端口: 5671 5672 4369 15671 15672 25672 15672 (if management plugin is enabled) 15671 management监听端口 5672, 5671 (AMQP 0-9-1 without and with TLS) 4369 (epmd) epmd 代表 Erlang 端口映射守护进程 25672 (Erlang distribution)

```shell
docker run -d --name=myrabbitmq -p 5671:5617 -p 5672:5672 -p 4369:4369 -p 15671:15671 -p 15672:15672 -p 25672:25672 rabbitmq:3.7.12-management
```

## 2.2. 访问

浏览器访问 http://192.168.100.7:15672/#/

 ![](http://yuanheweb.com/img/mq/image9.png)

 初始账号和密码：guest/guest

![](http://yuanheweb.com/img/mq/image10.png)

最上侧的导航以此是：概览、连接、信道、交换器、队列、用户管理

# 3. 四大交换器->三种Exchange类型

- Exchange分发消息时根据类型的不同分发策略分为四种交换器,：**direct、fanout、topic、headers** 。

  headers 匹配 AMQP 消息的 header 而不是路由键，此外 headers 交换器和 direct 交换器完全一致，但性能

  差很多，目前几乎用不到了。所以直接看另外三种类型：

1. **direct**

   如果路由键完全匹配的话,消息才会被投放到相应的队列.

2. **fanout**

   当发送一条消息到fanout交换器上时,它会把消息投放到所有附加在此交换器的上的队列.

3. **topic**

   设置模糊的绑定方式,"*"操作符将"."视为分隔符,匹配单个字符;"#"操作符没有分块的概念,它将任意"."均视为关键字的匹配部分,能够匹配多个字符.

## 3.1. direct(直接模式) : 点对点

消息中的路由键（routing key）如果和 Binding 中的 binding key 一致， 交换器就将消息发到对应的队列中。路由键与队列名完全匹配，如果一个队列绑定到交换机要求路由键为“dog”，则只转发 routing key 标记为“dog”的消息，不会转发“dog.puppy”，也不会转发“dog.guard”等等。它是完全匹配、单播的模式。

![](http://yuanheweb.com/img/mq/4.jpg)

任何发送到Direct Exchange的消息都会被转发到RouteKey中指定的Queue。

1. 一般情况可以使用rabbitMQ自带的Exchange：”"(该Exchange的名字为空字符串，下文称其为default Exchange)。
2. 这种模式下不需要将Exchange进行任何绑定(binding)操作
3. 消息传递时需要一个“RouteKey”，可以简单的理解为要发送到的队列名字。
4. 如果vhost中不存在RouteKey中指定的队列名，则该消息会被抛弃。

- 创建队列

做下面的例子前，我们先建立一个四个的队列。

![](http://yuanheweb.com/img/mq/QQ20190820-065724@2x.png)

Durability：是否做持久化 Durable（持久） transient（临时） Auto delete : 是否自动删除



![](http://yuanheweb.com/img/mq/QQ20190811-192634@2x.png)

再新建一个exchange.topic的exchanges

![](http://yuanheweb.com/img/mq/QQ20190811-192328@2x.png)

1. 将wanho、 wanho.emps、wanho.news和wanhodaxue.news四个队列绑定到交换器exchange.fanout

![](http://yuanheweb.com/img/mq/QQ20190820-070829@2x.png)

## 3.2 . fanout(分列模式) ：pub/sub

- 什么是分列（Fanout）模式

每个发到 fanout 类型交换器的消息都会分到所有绑定的队列上去。fanout 交换器不处理路由键，只是简单的将队列绑定到交换器上，每个发送到交换器的消息都会被转发到与该交换器绑定的所有队列上。很像子网广播，每台子网内的主机都获得了一份复制的消息。fanout 类型转发消息是最快的。

![](http://yuanheweb.com/img/mq/5.jpg)

任何发送到Fanout Exchange的消息都会被转发到与该Exchange绑定(Binding)的所有Queue上。

```
 1. 可以理解为路由表的模式
 2. 这种模式不需要RouteKey
 3. 这种模式需要提前将Exchange与Queue进行绑定，一个Exchange可以绑定多个Queue，一个Queue可以同多个Exchange进行绑定。
 4. 如果接受到消息的Exchange没有与任何Queue绑定，则消息会被抛弃。
```

- 交换器绑定队列

1. 在queue中添加队列itheima 和kudingyu

2. 新建交换器chuanzhi

   ![](http://yuanheweb.com/img/mq/QQ20190820-070609@2x.png)

3. 将wanho、 wanho.emps、wanho.news和wanhodaxue.news四个队列绑定到交换器exchange.fanout

![](http://yuanheweb.com/img/mq/QQ20190820-070829@2x.png)

## 3.3. 主题模式（Topic）

- 什么是主题模式

topic 交换器通过模式匹配分配消息的路由键属性，将路由键和某个模式进行匹配，此时队列需要绑定到一个模式上。它将路由键和绑定键的字符串切分成单词，这些单词之间用点隔开。它同样也会识别两个通配符：符号“#”和符号`*`。#匹配0个或多个单词，`*`匹配不多不少一个单词。

![](http://yuanheweb.com/img/mq/6.jpg)

添加匹配规则，添加后列表如下：

![](http://yuanheweb.com/img/mq/QQ20190820-071134@2x.png)

# 4. 六大队列模式

 RabbitMQ有以下几种工作模式 ：http://www.rabbitmq.com/getstarted.html

## 4.1. Work queues ,见官网

## 4.2. Publish/Subscribe 

 ![](http://yuanheweb.com/img/mq/image14.png)

 发布订阅模式：

 1、每个消费者监听自己的队列。

 2、生产者将消息发给broker，由交换机将消息转发到绑定此交换机的每个队列，每个绑定交换机的队列都将接收 到消息

## 4.3. Routing

 ![](http://yuanheweb.com/img/mq/image16.jpeg)

 路由模式：

 1、每个消费者监听自己的队列，并且设置routingkey。 

2、生产者将消息发给交换机，由交换机根据routingkey来转发消息到指定的队列。

## 4.4. Topics 

上面的路由模式是根据路由key进行完整的匹配(完全相等才发送消息),这里的通配符模式通俗的来讲就是模糊匹配.

**符号"#"表示匹配一个或多个词,符号"\*"表示匹配一个词.**

 ![](http://yuanheweb.com/img/mq/image18.jpeg)

 路由模式：

 1、每个消费者监听自己的队列，并且设置带统配符的routingkey。

 2、生产者将消息发给broker，由交换机根据routingkey来转发消息到指定的队列。



## 4.5. Header ，见官网

headers 匹配 AMQP 消息的 header 而不是路由键，此外 headers 交换器和 direct 交换器完全一致，但性能

差很多，目前几乎用不到了

## 4.6. RPC，见官网

# 5. SpringBoot使用RabbitMQ

## 5.1. 创建环境

- 创建项目

  ```java
  Core
  	Lombok
  Web
  	Web
  Interation
  	RabbitMQ
  ```

- pom.xml

  ```xml
  <!-- amqp-->
  <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-amqp</artifactId>
  </dependency>
  ```

- application.yml

  ```yaml
  spring:
    rabbitmq:
      host: 192.168.100.7
  ```

## 5.2. 使用方式一

### 5.2.1. 手动创建队列、交换器和绑定，手动发送和接受

```java
@RunWith(SpringRunner.class)
@SpringBootTest
public class TestRabbitmqApplicationTests {

    @Autowired
    private AmqpAdmin amqpAdmin;

    @Autowired
    private RabbitTemplate rabbitTemplate;

    //创建队列
    @Test
    public void createQueue(){
        amqpAdmin.declareQueue(new Queue("amqpAdmin.queue",true));
    }

    //删除队列
    @Test
    public void deleteQueue(){
        amqpAdmin.deleteQueue("amqpAdmin.queue");
    }

    //创建交换器
    @Test
    public void createExchange() {
        //new TopicExchange();
        //new FanoutExchange();
        amqpAdmin.declareExchange(new DirectExchange("amqpAdmin.directExchange",true,false));
    }

    //删除交换器
    @Test
    public void deleteExchange(){
        amqpAdmin.deleteExchange("amqpAdmin.directExchange");
    }




    /**
     * 绑定交换器与队列的关系
     * 参数一：目的地，即要绑定的队列
     * 参数二：类型，绑定的是队列
     * 参数三：交换器的名字
     * 参数四：路由键
     * 参数五：参数 null
     */
    @Test
    public void testBind(){
        amqpAdmin.declareBinding(new Binding("amqpAdmin.queue", Binding.DestinationType.QUEUE,"amqpAdmin.directExchange","amqpAdmin.wanho",null));
    }


    /**
     * 解绑交换器与队列的关系
     * 参数一：目的地，即要绑定的队列
     * 参数二：类型，绑定的是队列
     * 参数三：交换器的名字
     * 参数四：路由键
     * 参数五：参数 null
     */
    @Test
    public void contextLoads() {
        amqpAdmin.removeBinding(new Binding("amqpAdmin.queue", Binding.DestinationType.QUEUE,"amqpAdmin.directExchange","amqpAdmin.wanho",null));
    }


    @Test
    public void sendDirect() {
        Map map = new HashMap();
        map.put("name","wanho");
        map.put("lst", Arrays.asList(1,2,3));
        rabbitTemplate.convertAndSend("amqpAdmin.directExchange","amqpAdmin.wanho",map);
    }

    @Test
    public void receiveDirect() {
        Map map = (Map) rabbitTemplate.receiveAndConvert("amqpAdmin.queue");
        System.out.println(map);
    }
}
```

### 5.2.2. 使用侦听来自动接受消息

- @RabbitListener

```java
@Component
public class MsgListener {
    @RabbitListener(queues = "amqpAdmin.queue")
    public void receive(String msg){
        System.out.println(msg);
    }
}
```

- @EnableRabbit

```java
@SpringBootApplication
@EnableRabbit
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
```

## 5.3. 使用方式二

### 5.3.1. 自动创建队列，交换器和绑定关系 ，手动发送消息

```java
@Configuration
public class RabbitmqConfig {
    @Bean
    public Queue getQueue(){
        return new Queue("amqpAdmin.queue2",true);
    }

    @Bean
    public Exchange getExchange(){
      return  ExchangeBuilder.directExchange("amqpAdmin.directExchange2").durable(true).build();
    }

    @Bean
    public Binding getBinding(@Autowired Queue queue, @Autowired Exchange exchange){
       return BindingBuilder.bind(queue).to(exchange).with("amqpAdmin.wanho2").noargs();
    }
}

```
















