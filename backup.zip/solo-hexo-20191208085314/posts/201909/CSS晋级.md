title: CSS晋级
date: '2019-09-17 00:42:40'
updated: '2019-09-17 00:42:40'
tags: [CSS]
permalink: /articles/2019/09/17/1568652160688.html
---
# 1、盒子模型

- CSS 框模型 (Box Model) 规定了元素框处理元素内容、内边距、边框 和 外边距 的方式。

- 盒子模型包含四部分

```css
内容
内边距（padding）
边框（border）
外边距（margin）
```

- 浏览器中的盒子模型

```
F12查看元素，最右下角的东西就是该元素的盒子模型结构图
```

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <style>
      #box{
        padding: 50px;
        margin: 100px;
        border: 10px solid red;
      }
    </style>
  </head>
  <body>
    <div id="box">
      我们学习盒子迷行
    </div>
  </body>
</html>
```

- 外边距

- 外边距的多种写法

```css
 margin: 100px;（上下左右外边距都为100px）
 margin: 100px 50px;（上下外边距为100px,左右为50px）
 margin: 20px 40px 80pneuix 160px;（上右下左）
```

```css
margin-left: 20px;
margin-bottom: 40px;
margin-right: 80px;
margin-top: 160px;
```

- 外边距可以让固定div水平居中

```html
<head>
  <style>
    #box{
      background-color: yellowgreen;
      /*文本居中*/
      text-align: center;
      width: 300px;
      /*固定div水平居中*/
      margin: 100px auto;
    }
  </style>
</head>
<body>
  <div id="box">
    我们学习盒子迷行
  </div>
</body>
```

- 内边距

- 内边距的多种写法

```css
padding: 100px;（上下左右内边距都为100px）
padding: 100px 50px;（上下内边距为100px,左右为50px）
padding: 20px 40px 80pneuix 160px;（上右下左）
```

```css
padding-left: 20px;
padding-bottom: 40px;
padding-right: 80px;
padding-top: 160px;
```

- 注意点

```
1、内边距有背景色、外边距没有背景色
2、相邻的两个元素，上下外边距会重叠（大的吃小的）；左右外边距会叠加
3、（了解）嵌套的两个元素，内边距和外边距互相叠加
```

```html
<head>
  <meta charset="UTF-8">
  <title>Title</title>
  <style>
    #d1{
      height: 80px;
      background-color: yellowgreen;
      margin: 50px 0px;
    }

    #d2{
      height: 80px;
      background-color: deepskyblue;
      margin: 100px 0px;
    }

    #s1{
      background-color: deeppink;
      margin: 0px 50px;
    }

    #s2{
      background-color: orange;
      margin: 0px 100px;
    }
  </style>

</head>
<body>

  <div id="d1"></div>
  <div id="d2"></div>
  <span id="s1">我是1个span</span><span id="s2">我是2个span</span>
</body>
```

- 边框

```css
border:3px solid red;

border-style: solid;/*double、solid、dotted、dashed*/
border-color: red;
border-width: 3px;

border-top: 5px solid red;
border-right: 5px double blue;
border-bottom: 5px dashed red;
border-left: 5px dotted blue;
```

```html
<head>
  <meta charset="UTF-8">
  <title>Title</title>
  <style>
    div{

      background-color: #ccc;
      margin: 10px 0px;
      width: 300px;
      height: 150px;
    }

    #d1{
      border: 3px solid red;
    }

    #d2{
      border-style: solid;
      border-color: red;
      border-width: 3px;
    }

    #d3{
      /*下边框的样式:3px 点虚线 红色*/
      border-top: 5px solid red;
      border-right: 5px double blue;
      border-bottom: 5px dashed red;
      border-left: 5px dotted blue;

    }
    #d4{
      border-bottom-color:  red;
      border-bottom-width: 3px;
      border-bottom-style: dotted;
    }
  </style>

</head>
<body>
  <div id="d1">111</div>
  <div id="d2">222</div>
  <div id="d3">333</div>
  <div id="d4">444</div>
</body>
```

- 边框圆角

```html
<head>
  <style>
    div{
      background-color: #ccc;
      margin: 10px 0px;
      width: 100px;
      height: 100px;
      border: 2px solid red;
    }
    #d1{
      border-radius: 20px;
    }

    #d2{
      border-radius: 50px;
    }

    #d3{
      border-radius: 50%;
    }
    #d4{
      width: 200px;
      height: 100px;
      border-radius: 50px;
    }

    #d5{
      width: 200px;
      height: 100px;
      border-radius: 50%;
    }
  </style>
</head>
<body>
  <div id="d1">111</div>
  <div id="d2">222</div>
  <div id="d3">333</div>
  <div id="d4">444</div>
  <div id="d5">555</div>
</body>
```

# 2、display属性

- 元素分类

```css
块级元素：div、h1~h6、ul、ol、li、p....
行内元素：span、label、a、img、font....
```

- 样式属性

```
它能够让元素，从行内元素以块级样式去显示，让块级元素以行内样式去显示，可以让元素隐藏
```

- 它的值有哪些

```css
none：隐藏
block：让元素以块级样式去显示
inline：让元素以行内样式去显示
inline-block：让元素以行内的块去显示（可以给行内元素设置高度和宽度等一系列的样式）
```

```html
<head>
  <style>
    div{
      height: 80px;
      border: 3px solid red;
    }
    #d2{
      display: inline;
    }
    #d3{
      display: inline;
    }
    
    span{
      border: 3px solid blue;
    }
    #s5{
      display: block;
    }
  </style>
</head>
<body>

  <div>1111</div>
  <div id="d2">2222</div>
  <div id="d3">3333</div>
  <hr>
  <span>444</span>
  <span id="s5">555</span>
  <span>666</span>
</body>
```

- 脱标（脱离标准文档流）

```css
通过display属性，让行内元素和块级元素互相转变，这种行为就是脱标

# 让元素脱标的方式有3中
1、display
2、float
3、position
```

- 元素的隐藏

```css
display:none
visibility: hidden;
```

```html
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
        div{
            border: 3px solid blue;
            height: 80px;
        }
        #d2{
            /*元素隐藏：且不占空间*/
            /*display: none;*/

            /*隐藏元素，并且占空间*/
            visibility: hidden;
        }
    </style>
</head>
<body>
    <div>111</div>
    <div id="d2">222</div>
    <div>333</div>
</body>
```

- 注意点：

```
行内元素，或者拥有行内样式的元素，无法设置宽和高等一些列的元素
可以通过设置元素为行内的块，让行内元素拥有高和宽等样式
```

```html
<head>
  <meta charset="UTF-8">
  <title>Title</title>
  <style>
    #s1,#s2{
      border: 3px solid orange;
      height: 80px;
      width: 400px;
      display: inline-block;
    }
  </style>
</head>
<body>
  <span id="s1">我是行内元素</span>
  <span id="s2">我是行内元素</span>
</body>
```

# 3、浮动

- 关键字：float

```
目前，用的最多的一种布局技术（div+css布局）
```

- 浮动的介绍

```
浮动的框可以向左或向右移动，直到它的外边缘碰到包含框或另一个浮动框的边框为止。
由于浮动框不在文档的普通流中，所以文档的普通流中的块框表现得就像浮动框不存在一样。(脱标)
```

- float属性值

```css
left：向左浮动
right：向右浮动
none:不浮动（默认值）
```

```html
<head>
  <style>
    #box{
      border: 3px solid blue;
    }
    #box>div{
      height: 100px;
      background-color: yellowgreen;
      border: 3px solid red;
    }
    #d1{
      float: left;
    }

    #d2{
      float: right;
    }
    #d3{
      float: right;
    }
  </style>

</head>
<body>


  <div id="box">
    <div id="d1">我是第一个div</div>
    <div id="d2">我是第二个div</div>
    <div id="d3">我是第3个div</div>
  </div>

</body>
```

- 浮动的元素有字围效果

```html
<head>
  <meta charset="UTF-8">
  <title>Title</title>
  <style>

    #box{
      border:1px solid #ccc;
    }
    #box>img{
      width: 200px;
      float: right;
    }

    #box>p{
      font-size: 30px;
      letter-spacing: 5px;
    }
  </style>

</head>
<body>

  <div id="box">
    <img src="img/yangmi.jpg" alt="">
    <h1>杨幂介绍</h1>
    <p>
      1990年，当时她正参加小演员培训班，刚好陈家林导演的《唐明皇》剧组来挑演员，4岁的杨幂幸运地被挑上了，并出演了剧中的咸宜公主 [18]  ，该剧则在播出后获得了第11届“金鹰奖”优秀长篇连续剧奖 [25-26]  、第13届“飞天奖”长篇特等奖 [27]  。次年，5岁的杨幂又在香港动作喜剧片《武状元苏乞儿》中饰演了男主角苏灿（周星驰饰演）的女儿。
    </p>
    <p>
      1992年，杨幂与六小龄童合作主演了戏曲题材儿童剧《猴娃》，此剧在播出后则获得了第十四届“飞天奖”少儿电视连续剧二等奖 [28]  ，而只有6岁的她也给该剧的制片人李小婉留下了深刻的印象 [16]  。
    </p>
    <p>
      1993年，杨幂在李丹阳的《穿军装的川妹子》MV中饰演小李丹阳 [29]  ，而该作品则荣获了首届中国音乐电视大赛金奖 [30]  。1996年，她还在何晴、李亚鹏出演的青春电影《歌手》中饰演了小夏表妹的角色 [31]  。
    </p>
  </div>

</body>
```

# 4、清除浮动

- 什么要清除浮动

```
由于浮动的元素对后面的元素布局存在一定的影响
清除浮动的意思，就是让其他元素不受浮动元素的影响
注意点：使用了浮动就必须要清除浮动
```

- 清除浮动的多种方式

```css
方式1：给最近受影响的元素添加一个clear:both样式
方式2：给浮动父元素添加一个overflow:hidden样式
方式3：使用bootstrap框架中的clearfix样式类
方式4：是用双伪元素清除浮动
```

```html
<head>
  <style>
    #box{
      border: 3px solid blue;
      /*清除浮动方式2*/
      overflow: hidden;
    }
    #box>div{
      background-color: yellowgreen;
      border: 3px solid red;
    }
    #d1{
      height: 200px;
      float: left;
    }
    #d2{
      height: 100px;
      float: right;
    }
    #d3{
      height: 200px;
      float: right;
    }

    .clearFix{
      /*清除浮动方式1*/
      /*clear: both;*/
    }
  </style>
</head>
<body>
  <div id="box">
    <div id="d1">我是第一个div</div>
    <div id="d2">我是第二个div</div>
    <div id="d3">我是第3个div</div>
  </div>
  <div  class="clearFix">
    浮动不要给我带来影响！
  </div>
</body>
```

# 5、溢出

- 属性：overflow

- 值

```css
hidden：溢出影藏
vidible：溢出显示（默认值）
scroll：显示滚动条
auto：溢出的时候才会显示滚动条
```

```html
<head>
  <style>
    #box{
      border: 5px solid red;
      height: 300px;
      /*溢出影藏*/
      /*overflow: hidden;*/
      /*显示滚动条*/
      /*overflow: scroll;*/
      /*溢出才会显示滚动条*/
      overflow: auto;
    }
  </style>
</head>
<body>
  <div id="box">
    <img src="img/yangmi.jpg" alt="">
  </div>
</body
```

# 6、定位

- 属性：position

- 值

```css
static：默认值
relative：相对定位
absolute：绝对定位
fixed：固定浏览器定位
```

- 除了默认值外，其他定位，需要结合四个方向属性

```css
top
bottom
left
rigth
```

- 相对定位

```
相对于原来的位置进行定位
不脱标，原来的位置保留
```

```html
<head>
  <meta charset="UTF-8">
  <title>Title</title>

  <style>
    div{
      border: 5px solid red;
      height: 80px;
    }
    #d2{
      /*相对定位：不脱标，原来位置保留，相对原来的位置进行定位*/
      position: relative;
      /*距离上边*/
      top:20px;
      /*距离左边*/
      left:50px;
    }
  </style>
</head>
<body>
  <div>111</div>
  <div id="d2">222</div>
  <div>333</div>
  <div>444</div>
</body>
```

- 绝对定位

```
绝对定位的元素需要有参照物，参照物是最近已定位的父元素（爹、爷爷、太爷...）
如果父元素没有定位，那绝对定位的元素的参照物就是根元素（html）
会脱标
一般开始的时候，都是自绝父相
```

```html
<head>
  <style>
    #box{
      border: 5px solid green;
      position: relative;
    }
    #box>div{
      border: 5px solid red;
      height: 80px;
    }

    #d2{
      position: absolute;
      top:10px;
      left: 50px;
    }
  </style>
</head>
<body>
  <div id="box">
    <div>111</div>
    <div id="d2">222</div>
    <div>333</div>
    <div>444</div>
  </div>
</body>
```

- 固定浏览器定位

```
会脱标
```

```html
<head>
  <style>
    #box{
      border: 3px solid red;
      position: fixed;
      right: 0px;
      top:200px;
    }
  </style>
</head>
<body>
  <div id="box">
    <ul>
      <li>电话咨询</li>
      <li>微信咨询</li>
      <li>网络咨询</li>
      <li>QQ咨询</li>
    </ul>
  </div>
</body
```

# 7、透明度

- 颜色表示法

```css
单词：red、green、blue、orange...
十六进制：#ff0000、#00ff00、#0000ff...
十六进制简写：#f00、#0f0、#00f...
背景色的值多一个rgb(0~255,0~255,0~255)函数形式
```

- 全透明

```
元素的背景透明，元素上的内容也透明
```

```css
语法
opcaity:0~1;
```

```html
<head>
  <style>
    #box{
      width: 300px;
    }
    .c1{
      height: 100px;
      background-color: rgb(0,0,0);
      position: relative;
      top: -104px;
      color: #fff;
      font-size: 60px;
      font-weight: bold;
      opacity: 0.5;
    }
  </style>
</head>
<body>
  <div id="box">
    <img src="img/yangmi.jpg" alt="">
    <div class="c1">杨幂真好看</div>
  </div>
</body>
```

- 背景色透明

```
元素的背景透明，元素上的内容不透明
```

```css
background-color:rgb(0,0,0);表示背景色为黑色

background-color:rgba(0,0,0,0~1);表示背景色为黑色,且有一点点透明度
```

```html
<head>
  <style>
    #box{
      width: 300px;
    }

    .c1{
      height: 100px;
      background-color: rgba(0,0,0,0.5);
      position: relative;
      top: -104px;
      color: #fff;
      font-size: 60px;
      font-weight: bold;
    }
  </style>
</head>
<body>
  <div id="box">
    <img src="img/yangmi.jpg" alt="">
    <div class="c1">杨幂真好看</div>
  </div>
</body>
```


