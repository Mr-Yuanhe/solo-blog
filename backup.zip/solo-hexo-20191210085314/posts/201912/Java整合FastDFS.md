title: Java整合FastDFS
date: '2019-12-08 20:05:27'
updated: '2019-12-09 11:15:11'
tags: [Java]
permalink: /articles/2019/12/08/1575806727624.html
---
# FastDFS

# 1. 图片上传分析

传统方式：

![](http://yuanheweb.com/img/fastdfs/07.png)

 要解决系统进行集群也可以访问，可以把图片服务器创建在外部图片服务，但普通图片服务器不可以做到水平扩展（分布式图片服务器）

![](http://yuanheweb.com/img/fastdfs/08.png)

如果想使用外部图片服务器，也需要支持水平扩展，同时还要保证高可用（主从备份）

解决方案：

- 搭建一个图片服务器，专门保存图片。可以使用分布式文件系统FastDFS。

# 2. 图片服务器的要求

1. 存储空间可扩展。
2. 提供一个统一的访问方式。

解决方案: 使用FastDFS，分布式文件系统。存储空间可以横向扩展，可以实现服务器的高可用。支持每个节点有备份机。

# 3. 什么是FastDFS

- FastDFS是用c语言编写的一款开源的分布式文件系统。
- FastDFS为互联网量身定制，充分考虑了冗余备份、负载均衡、线性扩容等机制，并注重高可用、高性能等指标，使用FastDFS很容易搭建一套高性能的文件服务器集群提供文件上传、下载等服务

# 4. FastDFS架构

- FastDFS架构包括 Tracker server和Storage server。客户端请求Tracker server进行文件上传、下载，通过

  Tracker server调度最终由Storage server完成文件上传和下载。

- Tracker server作用**是负载均衡和调度**，通过Tracker server在文件上传时可以根据一些策略找到Storage 

  server提供文件上传服务。可以将tracker称为追踪服务器或调度服务器。

- Storage server作用**是文件存储**，客户端上传的文件最终存储在Storage服务器上，Storage server没有实现自己的文件系统而是利用操作系统 的文件系统来管理文件。可以将storage称为存储服务器。

![](http://yuanheweb.com/img/fastdfs/09.png)



服务端两个角色：

- Tracker：管理集群，tracker也可以实现集群。每个tracker节点地位平等。收集Storage集群的状态。

- Storage：实际保存文件,Storage分为多个组，每个组之间保存的文件是不同的。

  每个组内部可以有多个成员，组成员内部保存的内容是一样的，组成员的地位是一致的，没有主从的概念。

# 5. FastDFS安装 -- docker 方式

```java
docker pull qbanxiaoli/fastdfs
mkdir -p /root/docker/fastdfs
docker run -d --restart=always --privileged=true --net=host --name=fastdfs -e IP=192.168.100.5 -v /root/docker/fastdfs:/var/local/fdfs qbanxiaoli/fastdfs
```

- 由于此镜像中配置了nginx+fastdfs的环境，就可以可以http访问到fast了，但端口默认是8080，进行修改

```shell
# 进入容器
docker exec -it fastdfs /bin/bash
# 测试
echo "Hello FastDFS!">index.html
# 上传后会返回一个url，注意要自己加上5000端口
fdfs_test /etc/fdfs/client.conf upload index.html
```

输入：http://192.168.100.5:8080/group1/M00/00/00/wKhkBV3I-9WAUPKSAAAAD1Hgi3Q71_big.html

# 6. 文件上传的流程

![](F:/course/java133/step6/05_fastdfs/http://yuanheweb.com/img/fastdfs/10.png)

客户端上传文件后存储服务器将文件ID返回给客户端，此文件ID用于以后访问该文件的索引信息。文件索引信息包括：组名，虚拟磁盘路径，数据两级目录，文件名。

![](F:/course/java133/step6/05_fastdfs/http://yuanheweb.com/img/fastdfs/11.png)

​	1、组名：文件上传后所在的storage组名称，在文件上传成功后有storage服务器返回，需要客户端自行保存。 

​	2、虚拟磁盘路径：storage配置的虚拟路径，与磁盘选项store_path*对应。如果配置了store_path0则是M00，如果配置了store_path1则是M01，以此类推。

​	3、数据两级目录：storage服务器在每个虚拟磁盘路径下创建的两级目录，用于存储数据文件。

​	4、文件名：与文件上传时不同。是由存储服务器根据特定信息生成，文件名包含：源存储服务器IP地址、文件创建时间戳、文件大小、随机数和文件拓展名等信息。

# 7. 文件下载流程

![](F:/course/java133/step6/05_fastdfs/http://yuanheweb.com/img/fastdfs/12.png)

# 8. java使用FastDFS

## 8.1. pom中加入依赖

```xml
<dependency>
    <groupId>com.github.tobato</groupId>
    <artifactId>fastdfs-client</artifactId>
    <version>1.26.7</version>
</dependency>
```

## 8.2 application.yml

```yaml
fdfs:
  pool:
    ## 连接池最大数量
    max-total: 200
    ## 每个tracker地址的最大连接数
    max-total-per-key: 50
    ## 连接耗尽时等待获取连接的最大毫秒数
    max-wait-millis: 5000
    testOnBorrow: false
  soTimeout: 1500 #socket连接超时时长
  connectTimeout: 600 #连接tracker服务器超时时长
  resHost: 192.168.100.5
  storagePort: 5000
  thumbImage: #缩略图生成参数，可选
    width: 150
    height: 150
  trackerList: #TrackerList参数,支持多个，我这里只有一个，如果有多个在下方加- x.x.x.x:port
    - 192.168.100.5:22122
```

## 8.3. config

```java
@Configuration
@Import(FdfsClientConfig.class)
// 解决jmx重复注册bean的问题
@EnableMBeanExport(registration = RegistrationPolicy.IGNORE_EXISTING)
public class FastDFSConfig {

}
```

## 8.4. 图片操作

```java
@RunWith(SpringRunner.class)
@SpringBootTest
public class FastDFSTest {

    @Autowired
    private FastFileStorageClient fastFileStorageClient;


    /**
     * 测试文件上传
     */
    @Test
    public void  upload() throws Exception {
        InputStream is = new FileInputStream("C:\\Users\\Public\\Pictures\\Sample Pictures\\thttp://yuanheweb.com/img/fastdfs.jpg");
        StorePath storePath = fastFileStorageClient.uploadFile(is, is.available(), "jpg", null);
        System.out.println(storePath);
    }

    /**
     * 测试上传缩略图
     */
    @Test
    public void uploadCrtThumbImage()  throws Exception  {
        try {
            InputStream is = new FileInputStream("C:\\Users\\Public\\Pictures\\Sample Pictures\\thttp://yuanheweb.com/img/fastdfs.jpg");
            // 测试上传 缩略图
            StorePath storePath = fastFileStorageClient.uploadImageAndCrtThumbImage(is,  is.available(), "jpg", null);
            System.out.println(storePath);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * 测试文件下载
     */
    @Test
    public void download() {
        try {
            byte[] bytes = fastFileStorageClient.downloadFile("group1", "M00/00/00/wKhkBV3JAkyAYHMBAAAWRHklvyI226.jpg", new DownloadByteArray());
            FileOutputStream stream = new FileOutputStream("a.jpg");
            stream.write(bytes);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 测试文件删除
     */
    @Test
    public void deleteFile(){
        fastFileStorageClient.deleteFile("group1","M00/00/00/wKhkBV3JAkyAYHMBAAAWRHklvyI226.jpg");
    }

}

```





















# 
