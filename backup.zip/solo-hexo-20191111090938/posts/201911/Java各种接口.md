title: Java各种接口
date: '2019-11-10 18:51:11'
updated: '2019-11-10 19:14:16'
tags: [Java笔记, Java]
permalink: /articles/2019/11/10/1573383071777.html
---
## 截止目前，我们见过哪些有趣的接口  
  
```  
FactoryBean  
InvocationHandler  
ServletContextListener  
Iterable  
    Collection  
	List
        Set  
        Queue  
Iterator  
Map  
Comparable  
Comparator  
Entry.Key  
    
Connection  
Statement  
ResultSet  
    
Serializeable  
    
Runnable  
Callable  
Servlet  
    
BeanPostProcessor  
```  
  
### 1.FactoryBean  

>工厂Bean返回的对象不是指定类的一个实例，其返回的是该FactoryBean的getObject方法所返回的对象。在Spring框架内部，有很多地方有FactoryBean的实现类，它们在很多应用如(Spring的AOP、ORM、事务管理)及与其它第三框架(hibernate丶mybatis丶jpa...)集成时都有体现

- 接口：
```java 
public interface FactoryBean<T> {
 
   /**
    * 获取实际要返回的bean对象。
    */
   T getObject() throws Exception;
 
   /**
    * 获取返回的对象类型
    */
   Class<?> getObjectType();
 
   /**
    * 是否单例
    */
   boolean isSingleton();
}
```
- 实现类：
```
public class UserFactoryBean implements FactoryBean<User> {
   @Override
   public User getObject() throws Exception {
      User user = new User();
      user.setId(1);
      user.setName("张三");
      return user;
   }
 
   @Override
   public Class<?> getObjectType() {
      return User.class;
   }
 
   @Override
   public boolean isSingleton() {
      return true;
   }
  
}
```
- XML配置：
```
<bean id="userFactoryBean" class="com.factory.UserFactoryBean" lazy-init="false"/>
```

### 2.InvocationHandler

> JDK动态代理，根据实体类生成代理对象，由该实体类的接口变量接收，进而调用接口方法

[简书详情](https://www.jianshu.com/p/e575bba365f8)


### 3.ServletContextListener 

>它能够监听 ServletContext 对象的生命周期，实际上就是监听 Web 应用的生命周期。
当Servlet 容器启动或终止Web 应用时，会触发ServletContextEvent 事件，该事件由ServletContextListener 来处理。在 ServletContextListener 接口中定义了处理ServletContextEvent 事件的两个方法。

- ServletContextListener接口

```
public interface ServletContextListener extends EventListener {
    public void contextInitialized(ServletContextEvent sce);
    public void contextDestroyed(ServletContextEvent sce);
}
```
- 实现ServletContextListener 接口
```
public class MyServletContextListener implements ServletContextListener {
   /** 
    * 当Servlet 容器启动Web 应用时调用该方法。在调用完该方法之后，容器再对Filter 初始化， 
    * 并且对那些在Web 应用启动时就需要被初始化的Servlet 进行初始化。 
    */
    public void contextInitialized(ServletContextEvent event) {
        System.out.println("context initialized");
    }

   /** 
    * 当Servlet 容器终止Web 应用时调用该方法。在调用该方法之前，容器会先销毁所有的Servlet 和Filter 过滤器
    */
    public void contextDestroyed(ServletContextEvent event) {
        System.out.println("context destroyed");
    }
}
```
- web.xml中配置
```xml
<listener>
    <listener-class>com.thejavageek.MyServletContextListener</listener-class>
</listener>
```

### 4.Iterable  
>Iterable接口 (java.lang.Iterable) 是Java集合的顶级接口之一。

![image.png](https://img.hacpai.com/file/2019/11/image-df8cbcd9.png)

>Collection  是单列集合。有List、Set、Queue

- List

>List   元素是有序的、可重复，可以对列表中每个元素的插入位置进行精确地控制。

List接口中常用类
```java
Vector： 线程安全，但速度慢，已被ArrayList替代。

ArrayList：线程不安全，查询速度快。底层是基于动态数组。jdk1.7中默认大小是 10 个元素。加载因子为原容量的 1.5倍

LinkedList：线程不安全。增删速度快。底层是基于链表的动态数组
```
- Set

>Set不允许包含重复的元素，底层通过Map实现。
通常Set是无序的，不保证元素的插入顺序；部分实现除外(LinkedHashSet)。

- Queue

>Queue(队列)是一个专为进行处理前保存元素而设计的集合。
除了Collection接口中基本操作外，Queue还提供了其它的插入、获取和检查操作；每种操作有两种形式的方法：一种是当操作失败时抛出异常，另一种是失败时返回特殊的值（null or false）。
Queue通常不允许插入null元素，然而一些实现类比如LinkedList，并不禁止null值的插入。但是我们仍然需要避免插入null元素，因为当Queue为空时，poll()会返回null。


### 5.Iterator  
>遍历容器的所有元素。
```
在iterator实现了Iterator接口后，相当于把一个Collection容器的所有对象，做成一个线性表（List），而iterator本身是一个指针，开始时位于第一个元素之前。
```
```
Iterator iter = list.iterator(); // 注意iterator，首字母小写
```
- Iterator的三个主要方法

1.Boolean hasNext();

>判断 iterator 内是否存在下1个元素，如果存在，返回true，否则返回false。（注意，这时上面的那个指针位置不变）

2.Object next();

>返回 iterator 内下1个元素，同时上面的指针向后移动一位。  
故，如果不断地循环执行next()方法，就可以遍历容器内所有的元素了。

3.void remove();

>删除 iterator 内指针的前1个元素，前提是至少执行过1次next();  
(这个方法不建议使用，建议使用容器本身的romove 方法)

### 6.Map  
>Map是一种(key/value)的映射结构，其它语言里可能称作字典（Dictionary），包括java早期也是叫做字典，Map中的元素是一个key只能对应一个value，不能存在重复的key。
![image.png](https://img.hacpai.com/file/2019/11/image-e651df7c.png)

Map常用的子类：

1.HashMap：
>内部结构是哈希表，不是同步的。允许null作为键和值。jdk1.7中默认大小是16个元素（必须是2的幂）加载因子为0.75：即当元素个数超过容量长度的0.75倍时，进行扩容。扩容增量：原容量的 1 倍

2.Hashtable：
>内部结构是哈希表，是同步的。不允许null作为键和值

3.TreeMap：
>内部结构地二叉树，不是同步的。可以对Map集合中的键进行排序。




### Comparable  
### Comparator  
### Entry.Key  
### Connection  
### Statement  
### ResultSet  
### Serializeable  
### Runnable  
### Callable  
### Servlet  
### BeanPostProcessor


![image.png](https://img.hacpai.com/file/2019/11/image-f958f166.png)

