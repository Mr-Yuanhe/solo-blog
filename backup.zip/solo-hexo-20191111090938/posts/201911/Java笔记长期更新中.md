title: Java笔记，长期更新中。。。
date: '2019-11-10 15:59:23'
updated: '2019-11-10 17:37:27'
tags: [Java笔记]
permalink: /articles/2019/11/10/1573372763794.html
---
## 1.见过哪些答案取值刚好是5个的问题：

- oracle中的组函数；

```
1）AVG(arg)函数：对分组数据做平均值运算。

2）SUM(arg)函数：对分组数据求和。

3）COUNT(1) 函数：返回一个表中的行数。

4）MIN(arg)函数：求分组中最小数据。

5）MAX(arg)函数：求分组中最大数据。
```

- spring中Bean的@Autowired取值


- spring中Bean的scope取值 
    
```
1.Singleton：默认，单例模式，全容器共享一个实例。

2.Prototype：每次调用新建一个Bean实例。

3.Request：Web项目中，给每一个HTTP Request新建一个Bean实例。

4.Session：Web项目中，给每一个HTTP Session新建一个Bean实例。

5.Global Session：这个只在portal应用中有用，给每一个global http session新建一个Bean实例。
```

- maven中dependency的scope取值

```
1.compile：缺省值，默认，适用于所有阶段，会随着项目一起发布。

2.provided：类似compile，第三方提供。如servlet.jar。

3.runtime：只在运行时使用，如JDBC驱动，适用运行和测试阶段。

4.test：只在测试时使用，用于编译和运行测试代码。不会随项目发布。如Junit

5.system：类似provided，需要显式提供包含依赖的jar，Maven不会在 Repository中查找它。
```


- AOP中的通知类型
 
```
1.前置通知（Before）：在目标方法前执行自定义行为。
2.后置通知（After）：在目标方法后执行自定义行为。
3.返回通知（After-returning）：在目标方法执行后执行自定义行为。
4.异常通知（After-throwing）：在目标方法抛出异常后执行自定义行为。
5.环绕通知（Around）： 在目标方法调用前和调用后都执行自定义行为。
```
[点击查看详情]()


## 2.截止目前，我们见过哪些强悍的标签：

```xml
<context:property-placeholder/>   引入资源文件的例子：
例子：
<context:property-placeholder location="jdbc.properties"/>
```

 ```xml
<context:component-scan> 扫描路径进行对象创建
例子：
<context:component-scan base-package="com.entity"/>
<context:component-scan base-package="com.*"/>
```

```xml
<aop:aspectj-autoproxy>  如果有一个@Aspect的类，则会产生代理类
模板：
<bean id="myAspect" class="com.aspect.MyAspect"/>
<aop-config>
    <aop-aspect ref="myAspect">
        <aop:pointcut id="pt" expression="* 切点方法名(..))"/>
        <aop:before pointcut="execution(* 切点方法名(..))" method="前置通知方法名"/>
        <aop:after pointcut-ref="pt" method="前置通知方法名"/>
    </aop-aspect>
</aop-config>

例子：

<bean id="myAspect" class="com.aspect.MyAspect"/>
<aop:config>
    <aop:aspect id="aspect" ref="myAspect">
         <aop:pointcut id="pt" expression="execution(* com.service.UserService.*(..))"/>
         <aop:before method="before" pointcut="execution(* com.service.UserService.query())"/>
         <aop:after method="after"  pointcut-ref="pt"/>
         <aop:after-returning method="commit" pointcut-ref="pt"/>
         <aop:after-throwing method="rollback"  pointcut-ref="pt"/>
         <aop:around method="around" pointcut-ref="pt"/>
    </aop:aspect>
</aop:config>
```

```
<tx:annotation-driven transaction-manager> 注解事务
```







## 4.注解

```java
@Override	// 重写方法
@Overload	// 重载
```

- WEB工程
```
@WebFilter 	// 过滤器
@WebServlet	// 该类为servlet
@WebListener	// 监听器
```

- spring中的注解首先引入component的扫描组件

<context:component-scan base-package=”包路径”> 
```
@Component	// 实例化到spring容器中。相当于xml中的<bean id="" class=""/>
@Autowired	// 自动装配，可以消除get，set方法，通过类型
@Resource	// 自动装配，一般卸载set上，默认根据name找
@Controller	// @controller 控制器（注入服务）
@Service	// 服务（注入DAO）
@Repository	// 用于将数据访问层（DAO 层）
@Configuration	// 指示一个类声明一个或多个@Bean方法
@Bean		// 一个方法级别上的注解
例子：
@Configuration
public class BeanConfig {
    @Bean
    public Person person() {
        return new Person("zhang3",18);
    }
}
```

- MyBatis
```
@Param		// 参数，mapper接口中方法的参数
@Delete		// 删除
@Insert		// 插入
@Update		// 更新
@Select		// 查询
@Results	// 结果集映射
```

- lombok

>先下载一个lombok插件
加入依赖
```
<dependency>
        <groupId>org.projectlombok</groupId>
        <artifactId>lombok</artifactId>
        <version>1.18.4</version>
</dependency>
```
>然后使用
```
@Data			// getter、setter、ToString
@AllArgsConstructor	// 全参构造方法
@NoArgsConstructor	// 无参构造方法
@ToString 		//重写ToString方法
```

- AOP
```
@Before			// 前置通知
@After			// 后置通知
@Around			// 环绕通知
@AfterThrowing		// 异常通知
@AfterReturning		// 返回通知
```

## 5.spring的bean当中有哪些属性和标签
属性
id
class
init-method
destory-method
factory-method
factory-bean
lazy-init
scope
autowired
deponds-on
abstract
p:name
parent

内容
property name value/ref
7，pom.xml中有哪些常用标签
groupid
artifactid
version
packaging
parent
dependencymanagement
dependencies
dependency
    groupid
    artifactid
    version
    scope
build
    plugins
        plugin
            tomcat

clean compile package install
## 6.Mybatis-Config.xml
    Configuration
        settings
        typealises
        enviroments
            enviroment
                transactionManager
                datasoure
        mappers

## 7.UserMapper.xml
    mapper namespace
        insert
        delete
        update
        select parameterType resultType/resultMap
        resultMap
## 8.分页
    PageHelper.start(1,3);
    List list = userService.select();
    PageInfo page = new PageInfo(List);
## 9.事务
    单独mybatis事务提交和回滚：   sqlsession.commit()/rollback();
    
spring当中事务：
（1）<tx:annotation-driven transaction-manager />
（2）扫描
（3）@Transactional(rollbackfor)
