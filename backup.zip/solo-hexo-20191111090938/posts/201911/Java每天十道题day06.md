title: Java每天十道题 - day06
date: '2019-11-08 13:51:03'
updated: '2019-11-10 15:54:36'
tags: [Java-每天十道题, Java面试题, Java]
permalink: /articles/2019/11/08/1573192263548.html
---
## 1.哪些类是线程安全的

>Vector、Hashtable、StringBuffer、 Stack、ConcurrentHashMap

- Vector


- Hashtable


- StringBuffer


- Stack


- ConcurrentHashMap



## 2.截止目前我们学习过哪些接口

```
Runnable, Callable, Serailizeable, Comparator, List, Set, Map, Queue, Servlet, 8个监听器，Connection , Statement, DriverManager, BeanFactory
```

## 3.打印工资最高的人的部门所在的地址；打印每个部门工资最低的员工的领导的领导的地址

- 最高

```sql
Select loc from dept where deptno in (Select deptno  from  emp where  sal >=(Select max(sal) from emp ))
```

- 最低

```sql
Select loc from dept wherer deptno in(Select deptno from emp where empno in (Select  mgr from emp where sal in ( Select  min(sal) emp group by deptno )))
```

## 4.存储过程和存储函数的区别是什么

```
1.一般来说，存储过程实现的功能要复杂一点，而函数的实现的功能针对性比较强。 
2.对于存储过程来说可以返回参数，而函数只能返回值或者表对象。 
3.存储过程一般是作为一个独立的部分来执行（EXEC执行），而函数可以作为查询语句的一个部分来调用（SELECT调用）
```
- 一般情况 如果只有一个返回值，用存储函数；否则，就用存储过程


## 5.使用jquery获取页面元素的方式有哪些

```js
1.根据标签
2.根据id获取元素  $("#msg")
3.直接根据元素名称获取元素  $("div,p")
4.根据样式获取元素  $(".temp")
5.取得所有元素 $("*")
```


## 6.jquery tmpl的作用是什么

```js
jquery.tmpl 就是用生成HTML模版的框架
jquery.tmpl的几种常用标签分别有：
${}, {{each}}, {{if}}, {{else}}, {{html}}
```

## 7.Session和Cookie的区别是什么.如何使用java代码操作

1.Cookie和Session都是会话技术，Cookie是运行在客户端，Session是运行在服务器端。
2.Cookie有大小限制以及浏览器在存cookie的个数也有限制，Session是没有大小限制和服务器的内存大小有关。
3.Cookie有安全隐患，通过拦截或本地文件找得到你的cookie后可以进行攻击。
4.Session是保存在服务器端上会存在一段时间才会消失，如果session过多会增加服务器的压力。
5.一般将登陆信息等重要信息存放为Session，其他信息如果需要保留，可以放在Cookie中

```java
// 创建 cookie：
Cookie cookie = new Cookie(String name,String value);
response.addCookie(cookie);
// 删除 cookie：
Cookie.setMaxAge(0);
// 获得 session 对象
HttpSession session = request.getSession();
// 赋值
session.setAttribute("key","value");
```

## 8.jsp的组成元素有哪些

```
1.静态内容
就是html,css,javascript等内容

2.指令
以<%@开始 %> 结尾，比如<%@page import="java.util.*"%>

3.表达式 <%=%>
用于输出一段html

4.Scriptlet
在<% %> 之间，可以写任何java 代码

5.声明
在<%! %> 之间可以声明字段或者方法。但是不建议这么做。

6.动作
<jsp:include page="Filename" > 在jsp页面中包含另一个页面。在包含的章节有详细的讲解

7.注释 <%-- -- %>
不同于 html的注释 <!-- --> 通过jsp的注释，浏览器也看不到相应的代码，相当于在servlet中注释掉了。
```


## 9.截止目前我们学过哪些注解

```java
@Override	// 重写方法
@Overload	// 重载
```

```
@WebFilter 	// 过滤器
@WebServlet	// 该类为servlet
@WebListener	// 监听器
```

- spring中的注解首先引入component的扫描组件

<context:component-scan base-package=”包路径”> 
```
@Component	// 实例化到spring容器中。相当于xml中的<bean id="" class=""/>
@Autowired	// 自动装配，可以消除get，set方法，通过类型
@Resource	// 自动装配，一般卸载set上，默认根据name找
@Controller	// @controller 控制器（注入服务）
@Service	// 服务（注入DAO）
@Repository	// 用于将数据访问层（DAO 层）
@Configuration	// 指示一个类声明一个或多个@Bean方法
@Bean		// 一个方法级别上的注解
例子：
@Configuration
public class BeanConfig {
    @Bean
    public Person person() {
        return new Person("zhang3",18);
    }
}
```

- MyBatis
```
@Param		// 参数，mapper接口中方法的参数
@Delete		// 删除
@Insert		// 插入
@Update		// 更新
@Select		// 查询
@Results	// 结果集映射
```

- lombok

>先下载一个lombok插件
加入依赖
```
<dependency>
        <groupId>org.projectlombok</groupId>
        <artifactId>lombok</artifactId>
        <version>1.18.4</version>
</dependency>
```
>然后使用
```
@Data			// getter、setter、ToString
@AllArgsConstructor	// 全参构造方法
@NoArgsConstructor	// 无参构造方法
@ToString 		//重写ToString方法
```

- AOP
```
@Before			// 前置通知
@After			// 后置通知
@Around			// 环绕通知
@AfterThrowing		// 异常通知
@AfterReturning		// 返回通知
```


## 10.spring当中的自动装配是什么

```
默认的方式是不进行自动装配，通过显式设置ref 属性来进行装配。 byName： 通过参数名 自动装配，Spring容器在配置文件中发现bean的autowire属性被设置成byname，之后容器试图匹配、装配和该bean的属性具有相同名字的bean。 byType:： 通过参数类型自动装配，Spring容器在配置文件中发现bean的autowire属性被设置成byType，之后容器试图匹配、装配和该bean的属性具有相同类型的bean。如果有多个bean符合条件，则抛出错误。 constructor：这个方式类似于 byType， 但是要提供给构造器参数，如果没有确定的带参数的构造器参数类型，将会抛出异常。 autodetect： 首先尝试使用constructor来自动装配，如果无法工作，则使用byType方式。 
```
