title: Linux文件处理命令
date: '2019-09-15 17:47:37'
updated: '2024-08-26 09:32:14'
tags: [Linux]
permalink: /articles/2019/09/15/1568547117311.html
---
# cd

英文：change directory     命令路径：内部命令     执行权限：所有用户
作用：切换目录
语法：cd [目录]

> __cd /__ 切换到根目录
> __cd ..__  回到上一级目录
> __cd .__ 当前目录
> __cd ./*__ 当前目录下*文件夹
> __cd -__ 显示并打开到上一次操作的目录
> __cd ~__ 当前用户的宿主目录（root:# cd ~用户名 进入某个用户的家目录）

---

# ls

英文：list      命令路径：/bin/ls执行权限：所有用户
作用：显示目录文件
语法：ls [-alrRd] [文件或目录]

> __ls -a__ all 显示所有文件，注意隐藏文件，特殊目录.和..
> __ls -l__（long）显示详细信息
> __ls -R__（recursive）递归显示当前目录下所有目录
> __ls -r__（reverse）逆序排序
> __ls -t__（time）按修改时间排序（降序）
> __ll__ 相当于 ls –l

---

# pwd

英文：print working directory	命令路径：/bin/pwd	执行权限：所有用户
作用：显示当前工作目录
语法：pwd [-LP]

> __pwd__ 或者 __pwd -L__ 显示链接路径，当前路径，默认
> __pwd -P__ 物理路径
> ![图片1.png](https://img.hacpai.com/file/2019/09/图片1-990335a0.png)

---

# mkdir

英文：make directories	命令路径：/bin/mkdir	执行权限：所有用户
作用：创建新目录
语法：mkdir [-p] 目录名

> __mkdir tmp__ 当前目录下创建tmp目录
> __mkdir -p__ 父目录不存在情况下先生成父目录 （parents）
> __mkdir linux/test__  如果目录linux不存在，则报错，使用参数-p即可自动创建父目录。
> ![2.png](https://img.hacpai.com/file/2019/09/2-099be719.png)

---

# touch

命令路径：/bin/touch		执行权限：所有用户
作用：创建空文件或更新已存在文件的时间语法：touch 文件名

> __touch  a.txt  b.txt__ 或者 __touch {a.txt,b.txt}__ 同时创建多个文件
> 创建带空格的文件   __touch "program files"__  在查询和删除时也必须带双引号
> 注意：生产环境中，文件名，一定不要加空格

---

# cp

英文：copy		命令路径：/bin/cp		执行权限：所有用户
作用：复制文件或目录
语法：cp [–rp]  源文件或目录 目的目录

> __cp filename__ 复制单个文件
> __cp -r 或 -R__ recursive 递归处理，复制目录
> __cp -p__ 保留文件属性 （原文件的时间不变）

1. 相对路径

> __cp –R /etc/*__
> __cp –R ../aaa__
> __cp -R ../../test/__

2. 绝对路径

> __cp –R /ect/service__
> __cp –R /root/test/aa/bb__

---

# mv

英文：move 	命令路径：/bin/mv		执行权限：所有用户
作用：移动文件或目录、文件或目录改名
语法：mv 源文件或目录 目的目录


| 命令格式         |                           运行结果                           |
| ------------------ | :------------------------------------------------------------: |
| mv 文件名 文件名 |                   将源文件名改为目标文件名                   |
| mv 文件名 目录名 |                     将文件移动到目标目录                     |
| mv 目录名 目录名 | 目标目录已存在，将源目录移动到目标目录；目标目录不存在则改名 |
| mv 目录名 文件名 |                             出错                             |

---

# rm

英文：remove 	命令路径：/bin/rm		执行权限：所有用户
作用：删除文件
语法： rm [-rf] 文件或目录

> __rm -r__ （recursive）删除目录，同时删除该目录下的所有文件
> __rm -f__（force） 强制删除文件或目录 即使原档案属性设为唯读,亦直接删除,无需逐一确认
> __rm -rf ./__ 强制删除当前目录下所有文件

注意：工作中，谨慎使用rm –rf 命令。

---

# cat

英文：concatenate 	命令路径：/bin/cat	执行权限：所有用户
作用：显示文件内容
语法：cat [-n] [文件名]

> __cat -n 或 --number__：由 1 开始对所有输出的行数编号。
> __cat -b 或 --number-nonblank__：和 -n 相似，只不过对于空白行不编号。
> __cat -A`__ 显示所有内容，包括隐藏的字符

---

# more

命令路径：/bin/more		执行权限：所有用户
作用：分页显示文件内容
语法：more [文件名]

> __空格或f__ 显示下一页
> __Enter键__ 显示下一行
> __q或Q__ 退出

---

# head

命令路径：/usr/bin/head		执行权限：所有用户
作用：查看文件前几行（默认10行）
语法：head [文件名]

> __head -n__ 显示指定行数
> __head -20 /etc/services__ 查看services前20行数据
> __head –n 3 /etc/services__ 查看services前3行数据（带行号）

---

# tail

命令路径：/usr/bin/tail	执行权限：所有用户
作用：查看文件的后几行语法：tail [文件名]

> __tail -n__ 指定行数
> __tail -f__（follow） 动态显示文件内容

- 获取一个大文件的部分文件，可使用head或tail命令

> 实例：
> __head -n 100 /etc/services > config.log__ 获取services中前100行数据放入config.log中
> __tail -n 100 /etc/services > config.log__ 获取services中后100行数据放入config.log中
