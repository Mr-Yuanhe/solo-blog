title: JavaScript基础教程
date: '2019-09-18 21:09:15'
updated: '2019-09-18 21:09:15'
tags: [JavaScript]
permalink: /articles/2019/09/18/1568812155818.html
---
# 1、阻止默认事件

- 事件函数中的两个对象

```
this,表示当前调用对象
event,表示当前事件对象
```

- 可以通过当前事件对象，阻止默认事件

```html
<<a href="#"  onclick="del(this)">Delete</a></td>
<script>
  function del(obj) {
    //alert("删除操作")
    console.log(event);
    //阻止默认事件
    event.preventDefault();
  }
</script>
```

- 表单作业

```html
<head>
  <style>
    #box{
      margin-top: 50px;
    }

    #box>.form{
      text-align: center;
      line-height: 40px;
    }

    #box>.table{
      text-align: center;
    }
  </style>
</head>
<body>

  <div id="box">

    <div class="form">
      <form action="">
        <label>name</label>
        <input type="text" id="name" name="name">
        <label>email</label>
        <input type="text" id="email" name="email">
        <label>salary</label>
        <input type="text" id="salary" name="salary">
      </form>
      <button onclick="add()">添加</button>
    </div>
    <hr>
    <div class="table">
      <table border="1" cellspacing="0" align="center">
        <thead>
          <tr>
            <th>name</th>
            <th>email</th>
            <th>salary</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody id="data">
          <tr>
            <td>1</td>
            <td>1</td>
            <td>1</td>
            <td><a href="#"  onclick="del(this)">Delete</a></td>
          </tr>
          <tr>
            <td>2</td>
            <td>2</td>
            <td>2</td>
            <td><a href="#" onclick="del(this)">Delete</a></td>
          </tr>
          <tr>
            <td>3</td>
            <td>3</td>
            <td>3</td>
            <td><a href="#" onclick="del(this)">Delete</a></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <script>
    function add() {

      //1、获取输入的三个值
      var name = document.getElementById("name").value;
      var email = document.getElementById("email").value;
      var salary = document.getElementById("salary").value;

      //2、判断
      if(name==null||name==""){
        alert("名字不能为空！");
        return;
      }
      if(email==null||email==""){
        alert("email不能为空！");
        return;
      }
      if(salary==null||salary==""){
        alert("salary不能为空！");
        return;
      }

      //3、创建dom节点，并且把值添加到对应的dom节点中
      var trNode = document.createElement("tr");
      var tdNode01 = document.createElement("td");
      tdNode01.textContent=name;
      var tdNode02 = document.createElement("td");
      tdNode02.textContent=email;
      var tdNode03 = document.createElement("td");
      tdNode03.textContent=salary;
      var tdNode04 = document.createElement("td");
      var aNode = document.createElement("a");
      aNode.textContent="delete";
      aNode.setAttribute("href","#");
      aNode.setAttribute("onclick","del(this)");
      tdNode04.appendChild(aNode);
      trNode.appendChild(tdNode01);
      trNode.appendChild(tdNode02);
      trNode.appendChild(tdNode03);
      trNode.appendChild(tdNode04);
      document.getElementById("data").appendChild(trNode);
    }

    function del(obj) {
      obj.parentNode.parentNode.remove();
      event.preventDefault();
    }
  </script>
</body>
```

# 2、文本节点操作

- 方式1

```
通过元素的属性来操作文本节点
```

- 获取文本节点对象，可通过获取子节点的形式获取文本节点（了解）

```html
<h2 id="title">我是h2中内容</h2>

<script>
  var h2Node = document.getElementById("title");

  var nodes = h2Node.childNodes;

  console.log(nodes);
  console.log(nodes[0]);
</script>
```

- 操作文本节点中的内容

```
通过元素节点的属性textContent或者属性innerHTML来操作元素的文本值
```

- textContent与innerHTML有什么区别

```
element.textContent 设置或返回节点及其后代的"文本内容"。 
element.innerHTML 设置或返回元素的内容。 
```

```html
<div id="box">
  <h1>我是标题</h1>
</div>
<button onclick="fn1()">获取值</button>
<button onclick="fn2()">textContent设置值</button>
<button onclick="fn3()">innerHTML设置值</button>
<div id="box2">
  
</div>
<script>

  function fn1() {
    var divNode = document.getElementById("box");
    /*返回节点及其后代的"文本内容"。*/
    console.log(divNode.textContent);
    /*返回元素的html内容*/
    console.log(divNode.innerHTML);

  }

  function fn2() {
    var divNode = document.getElementById("box2");
    /*直接以文本的形式在元素节点中显示文本值*/
    divNode.textContent="<h1>我是标题</h1>";
  }

  function fn3() {
    var divNode = document.getElementById("box2");
    /*在元素节点中显示内容的时候，会渲染标签*/
    divNode.innerHTML="<h1>我是标题</h1>";
  }
</script>
```

# 3、js中创建对象

- new Date();
- new String();
- document.CreateElement(tag);


- 以创建学生对象为例


- 方法1

```
new Object()形式
```

```js
var student = new Object();//object可以泛指一切
//给学生对象添加属性
student.id=1001;
student.name="张三";
student.age=18;
//给学生对象添加方法
student.study=function () {
  console.log("好好写代码！");
}

console.log(student);
console.log(student.name);
console.log(student.age);

student.study();
```

- 方法2

```
json形式，又叫简写形式
格式:{key1:value1,key2:value2,key3:value3,...}
```

```js
var student2 = {
  id: 1002,
  name: "李四",
  age: 19,
  study: function () {
    console.log("好好写项目！");
  }
}

console.log(student2.name);
console.log(student2.age);
student2.study();

student2.address="南京卡子门";
console.log(student2);
var stu ={};
```

