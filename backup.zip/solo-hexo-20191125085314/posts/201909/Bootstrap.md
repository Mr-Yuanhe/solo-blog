title: Bootstrap
date: '2019-09-24 18:26:59'
updated: '2019-09-24 18:26:59'
tags: [Bootstrap]
permalink: /articles/2019/09/24/1569320819776.html
---
# 1、Bootstrap简介

- 官网（中文网）

https://www.bootcss.com/

- Bootstrap3中文文档

https://v3.bootcss.com/

```
是一个前端开发框架
Bootstrap 是最受欢迎的 HTML、CSS 和 JS 框架，用于开发响应式布局、移动设备优先的 WEB 项目。
```

- 我们学习bootstrap3

```
bootstrap2：不能够支持响应式布局
bootstrap3：支持响应式布局
```

- 什么是响应式

```
开发一套页面，可以给多种设备使用
多设备指的pc端、移动端
```

```
淘宝不是响应式的：移动端是移动端的网页，pc端是pc端的网页（访问的路径不一样）
中岚签证网页就是响应式的：移动端和pc端的网页是同一个网页，显示效果不一样，内容完全一样
```
- 下载
[点击进入下载](http://package.yuanheweb.com)
依次点击  HTML -> Bootstrap -> bootstrap.zip-3.3.7.zip
__中文离线手册根据需要下载__

- 解压后直接将bootstrap放入项目内
- 基本模板

```html
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <!--让ie浏览器以最新的引擎来渲染该页面-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--视口：让浏览器的宽度等于设置的宽度，初始化缩放比例为100%-->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Bootstrap 101 Template</title>

    <!-- Bootstrap核心css文件 -->
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- HTML5 shim 和 Respond.js 是为了让 IE8 支持 HTML5 元素和媒体查询（media queries）功能 -->
    <!-- 警告：通过 file:// 协议（就是直接将 html 页面拖拽到浏览器中）访问页面时 Respond.js 不起作用 -->

    <!--html中的选择标签,如果ie的版本小于9，下面两个script标签可以被渲染-->
    <!--[if lt IE 9]>
<script src="https://cdn.jsdelivr.net/npm/html5shiv@3.7.3/dist/html5shiv.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/respond.js@1.4.2/dest/respond.min.js"></script>
<![endif]-->
  </head>
  <body>
    <h1>你好，世界！</h1>

    <!-- jQuery (Bootstrap 的所有 JavaScript 插件都依赖 jQuery，所以必须放在前边) -->
    <script src="js/jquery-3.4.1.js"></script>
    <!-- 加载 Bootstrap 的所有 JavaScript 插件。你也可以根据需要只加载单个插件。 -->
    <script src="bootstrap/js/bootstrap.js"></script>
  </body>
</html>
```

# 2、布局容器

- div是元素
- 样式类：container（容器）

```
响应式布局容器，会根据浏览器的宽度的变化，container的宽度也会发生变化
```

- 学习css3中的媒体查询
- 语法

```css
@media (条件) {
  选择器{
    样式;
  }
}
```

```html
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap 101 Template</title>
    <style>
      #box{
        height: 300px;
        background-color: red;
      }
      @media (min-width: 768px) {
        #box{
          background-color: green;
        }
      }
      @media (min-width: 992px) {
        #box{
          background-color: orange;
        }
      }

      @media (min-width: 1200px) {
        #box{
          background-color: deepskyblue;
        }
      }
    </style>
  </head>
  <body>
    <div id="box">
      如果屏幕设备宽度小于768px,背景色显示红色，<br>
      如果屏幕设置宽度在768~992之间，背景色显示绿色<br>
      如果屏幕设置宽度在992~1200之间，背景色显示橙色<br>
      如果屏幕设置宽度在>1200之间，背景色显示天蓝色
    </div>
  </body>
</html>
```

- 响应式布局容器的源码

```css
.container {
  padding-right: 15px;
  padding-left: 15px;
  margin-right: auto;
  margin-left: auto;
}
@media (min-width: 768px) {
  .container {
    width: 750px;
  }
}
@media (min-width: 992px) {
  .container {
    width: 970px;
  }
}
@media (min-width: 1200px) {
  .container {
    width: 1170px;
  }
}
```

```
.container-fluid 类用于 100% 宽度，占据全部视口（viewport）的容器。
```

```css
.container-fluid {
  padding-right: 15px;
  padding-left: 15px;
  margin-right: auto;
  margin-left: auto;
}
```

- 分析一下768、992、1200这些数值是什么意思

```
超小屏幕 手机 (<768px)			  xs
小屏幕 平板 (≥768px) 			   sm
中等屏幕 桌面显示器 (≥992px)			md
大屏幕 大桌面显示器 (≥1200px)		lg
```

# 3、栅格系统

- 介绍

```
Bootstrap 提供了一套响应式、移动设备优先的流式栅格系统，随着屏幕或视口（viewport）尺寸的增加，系统会自动分为最多12列。它包含了易于使用的预定义类，还有强大的mixin 用于生成更具语义的布局。

一行最多被分为12列
需要使用一些预定义的类
不同设备用不同的类
```

```html
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap 101 Template</title>
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
    <style>
      .container>div>div{
        border: 2px solid red;
        height: 100px;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col-md-1">1</div>
        <div class="col-md-1">2</div>
        <div class="col-md-1">3</div>
        <div class="col-md-1">4</div>
        <div class="col-md-1">5</div>
        <div class="col-md-1">6</div>
        <div class="col-md-1">7</div>
        <div class="col-md-1">8</div>
        <div class="col-md-1">9</div>
        <div class="col-md-1">10</div>
        <div class="col-md-1">11</div>
        <div class="col-md-1">12</div>
      </div>
      <hr>
      <div class="row">
        <div class="col-md-6">1</div>
        <div class="col-md-6">2</div>
      </div>
      <hr>
      <div class="row">
        <div class="col-md-3">1</div>
        <div class="col-md-3">1</div>
        <div class="col-md-2">1</div>
        <div class="col-md-4">2</div>
      </div>
    </div>
    <script src="js/jquery-3.4.1.js"></script>
    <script src="bootstrap/js/bootstrap.js"></script>
  </body>
</html>
```

- 分析md

```
超小屏幕 手机 (<768px)			  xs
小屏幕 平板 (≥768px) 			   sm
中等屏幕 桌面显示器 (≥992px)			md
大屏幕 大桌面显示器 (≥1200px)		lg
```

```html
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap 101 Template</title>
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
    <style>
      .container>div>div{
        border: 2px solid red;
        height: 400px;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col-sm-6 col-md-3">1</div>
        <div class="col-sm-6 col-md-9">2</div>
      </div>
    </div>
    <script src="js/jquery-3.4.1.js"></script>
    <script src="bootstrap/js/bootstrap.js"></script>
  </body>
</html>
```

# 4、偏移、排序、嵌套

- 偏移

```
# 重偏移的那个开始，整体往右偏移

.col-md-offset-*
```

- 排序

```
通过使用 .col-md-push-* 和 .col-md-pull-* 类就可以很容易的改变列（column）的顺序。
```

- 嵌套

```
为了使用内置的栅格系统将内容再次嵌套，可以通过添加一个新的 .row 元素和一系列 .col-sm-* 元素到已经存在的 .col-sm-* 元素内。被嵌套的行（row）所包含的列（column）的个数不能超过12（其实，没有要求你必须占满12列）。
```

```html
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap 101 Template</title>
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
    <style>

      .row>div{
        border: 2px solid red;
        height: 100px;
      }

    </style>
  </head>
  <body>

    <div class="container">
      <div class="row">
        <div class="col-sm-6 col-md-3">1</div>
        <div class="col-sm-6 col-md-9">2</div>
      </div>
      <h2>列偏移</h2>
      <div class="row">
        <div class="col-md-3 ">1</div>
        <div class="col-md-3 col-md-offset-3">2</div>
        <div class="col-md-3">3</div>
        <div class="col-md-3">4</div>
      </div>


      <h2>列排序</h2>
      <div class="row">
        <div class="col-md-3">1</div>
        <div class="col-md-3 col-md-push-3">2</div>
        <div class="col-md-3 col-md-pull-3">3</div>
        <div class="col-md-3">4</div>
      </div>

      <h2>嵌套</h2>
      <div class="row">
        <div class="col-md-6">
          <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-1"></div>
            <div class="col-md-1"></div>
            <div class="col-md-1"></div>
            <div class="col-md-1"></div>
            <div class="col-md-1"></div>
            <div class="col-md-1"></div>
            <div class="col-md-1"></div>
            <div class="col-md-1"></div>
            <div class="col-md-1"></div>
            <div class="col-md-1"></div>
            <div class="col-md-1"></div>
          </div>
        </div>
        <div class="col-md-6">4</div>
      </div>
    </div>

    <script src="js/jquery-3.4.1.js"></script>
    <script src="bootstrap/js/bootstrap.js"></script>
  </body>
</html>
```

# 5、表格的基本样式类

- 基本表格

```
为任意 <table> 标签添加 .table 类可以为其赋予基本的样式 
```

- 其他表格相关的样式

```
通过 .table-striped 类可以给 <tbody> 之内的每一行增加斑马条纹样式。
添加 .table-bordered 类为表格和其中的每个单元格增加边框。
通过添加 .table-hover 类可以让 <tbody> 中的每一行对鼠标悬停状态作出响应。
通过添加 .table-condensed 类可以让表格更加紧凑，单元格中的内补（padding）均会减半。
```

- 表格中还存在一些状态类，给每一行或者每一个单元格添加

```
.active		鼠标悬停在行或单元格上时所设置的颜色
.success	标识成功或积极的动作（绿色）
.info		标识普通的提示信息或动作（天蓝色）
.warning	标识警告或需要用户注意（黄色）
.danger		标识危险或潜在的带来负面影响的动作（红色）
```

```html
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap 101 Template</title>
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
  </head>
  <body>
    <div class="container">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>编码</th>
            <th>姓名</th>
            <th>年龄</th>
            <th>性别</th>
            <th>地址</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr class="success">
            <td>1001</td>
            <td>张三</td>
            <td>18</td>
            <td>男</td>
            <td>南京卡子门</td>
            <td><button>删除</button><button>详情</button></td>
          </tr>
          <tr class="info">
            <td>1002</td>
            <td>李四</td>
            <td>18</td>
            <td>女</td>
            <td>南京卡子门</td>
            <td><button>删除</button><button>详情</button></td>
          </tr>
          <tr class="warning">
            <td>1003</td>
            <td>王五</td>
            <td>18</td>
            <td>男</td>
            <td>南京卡子门</td>
            <td><button>删除</button><button>详情</button></td>
          </tr>
          <tr class="danger">
            <td>1003</td>
            <td>王五</td>
            <td>18</td>
            <td>男</td>
            <td>南京卡子门</td>
            <td><button>删除</button><button>详情</button></td>
          </tr>
          <tr>
            <td>1003</td>
            <td>王五</td>
            <td>18</td>
            <td>男</td>
            <td>南京卡子门</td>
            <td><button>删除</button><button>详情</button></td>
          </tr>
        </tbody>
      </table>
    </div>
    <script src="js/jquery-3.4.1.js"></script>
    <script src="bootstrap/js/bootstrap.js"></script>
  </body>
</html>
```

- 响应式表格

```
将任何 .table 元素包裹在 .table-responsive 元素内，即可创建响应式表格，其会在小屏幕设备上（小于768px）水平滚动。当屏幕大于 768px 宽度时，水平滚动条消失。
```

# 6、表单

- 基本表单

```
# 所有设置了 .form-control 类的 <input>、<textarea> 和 <select> 元素都将被默认设置宽度属性为 width: 100%;。
# 将 label 元素和前面提到的控件包裹在 .form-group 中可以获得最好的排列。
```

```html
<form>
  <div class="form-group">
    <label>用户名</label>
    <input type="text" class="form-control" name="username" placeholder="请输入用户名">
  </div>
  <div class="form-group">
    <label>密码</label>
    <input type="password" class="form-control" name="password" placeholder="请输入密码">
  </div>
  <div class="checkbox">
    <label>
      <input type="checkbox"> Check me out
    </label>
  </div>
  <div class="form-group">
    <button type="submit" class="btn btn-primary">登录</button>
  </div>
</form>
```

- 内联表单

```
为 <form> 元素添加 .form-inline 类可使其内容左对齐并且表现为 inline-block 级别的控件。只适用于视口（viewport）至少在 768px 宽度时（视口宽度再小的话就会使表单折叠）。
```

```html
<div>
  <form class="form-inline">
    <div class="form-group">
      <label>搜索条件1</label>
      <input type="text" class="form-control" name="username" placeholder="请输入用户名">
    </div>
    <div class="form-group">
      <label>搜索条件1</label>
      <input type="password" class="form-control" name="password" placeholder="请输入密码">
    </div>
    <div class="form-group">
      <button type="submit" class="btn btn-primary">登录</button>
    </div>
  </form>
</div>
```

- 水平表单

```
通过为表单添加 .form-horizontal 类，并联合使用 Bootstrap 预置的栅格类，可以将 label 标签和控件组水平并排布局。这样做将改变 .form-group 的行为，使其表现为栅格系统中的行（row），因此就无需再额外添加 .row 了。
```

```html
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap 101 Template</title>
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  </head>
  <body>

    <div class="container">
      <div style="width: 500px">
        <form class="form-horizontal">
          <div class="form-group">
            <label class="col-md-2 control-label">用户名</label>
            <div class="col-md-10">
              <input type="text" class="form-control" name="username" placeholder="请输入用户名">
            </div>
          </div>
          <div class="form-group">
            <label class="col-md-2 control-label">密码</label>
            <div class="col-md-10">
              <input type="password" class="form-control" name="password" placeholder="请输入密码">
            </div>
          </div >

          <div class="form-group">
            <label class="col-md-2 control-label">性别</label>
            <div class="col-md-10">
              <label class="radio-inline">
                <input type="radio" name="gender" value="0"> 女
              </label>
              <label class="radio-inline">
                <input type="radio"  name="gender" value="1"> 男
              </label>
            </div>
          </div>
          <div class="form-group">
            <label class="col-md-2 control-label">爱好</label>
            <div class="col-md-10">
              <label class="checkbox-inline">
                <input type="checkbox" name="hobby" value="eat"> 吃
              </label>
              <label class="checkbox-inline">
                <input type="checkbox" name="hobby" value="drink"> 喝
              </label>
              <label class="checkbox-inline">
                <input type="checkbox" name="hobby" value="sleep"> 睡
              </label>
            </div>
          </div>
          <div class="form-group">
            <label class="col-md-2 control-label">选择部门</label>
            <div class="col-md-10">
              <select name="departmentId" class="form-control">
                <option value="1001">研发一部</option>
                <option value="1002">研发二部</option>
                <option value="1003">产品一部</option>
                <option value="1004">产品二部</option>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-md-2 control-label">自我介绍</label>
            <div class="col-md-10">
              <textarea name="info" class="form-control"></textarea>
            </div>
          </div>
          <div class="form-group">
            <div class="col-md-10 col-md-offset-2">
              <button type="submit" class="btn btn-primary">登录</button>
            </div>
          </div>
        </form>
      </div>
    </div>
    <script src="js/jquery-3.4.1.js"></script>
    <script src="bootstrap/js/bootstrap.js"></script>
  </body>
</html>
```

# 7、按钮样式

- 基本样式

```
btn
```

- 其他样式

```
btn-default	白色按钮
btn-primary	深蓝色按钮(主要按钮)
btn-info
btn-success
btn-danger
btn-link	链接按钮
```

```html
<button>主要按钮</button>
<hr>
<button class="btn">按钮</button>
<hr>
<button class="btn btn-primary">主要按钮</button>
<button class="btn btn-primary active">激活的主要按钮</button>
<hr>
<button class="btn btn-success">成功按钮</button>
<hr>
<button class="btn btn-danger">危险按钮</button>
<hr>
<button class="btn btn-link">链接按钮</button>
<hr>
<a href="#" class="btn btn-primary">按钮链接</a>
<hr>
<input type="submit" class="btn btn-primary btn-lg" value="提交按钮">
<hr>
<input type="button" class="btn btn-primary btn-xs" value="普通按钮">
<hr>
<button class="btn btn-primary disabled" onclick="fn1()">样式禁用按钮</button>
<button class="btn btn-primary" disabled="disabled" onclick="fn1()">属性禁用按钮</button>
<!--属性决定功能，样式徒有其表-->
```

- 关闭按钮

```html
<button type="button" class="close"><span>×</span></button>
```

- 三角符号

```html
<span class="caret"></span>
```

# 8、浮动

- 快速浮动

```
通过添加一个类，可以将任意元素向左或向右浮动。!important 被用来明确 CSS 样式的优先级。

.pull-left
.pull-right
```

- 清除浮动

```
通过为父元素添加 .clearfix 类可以很容易地清除浮动（float）。
```

```html
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap 101 Template</title>
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

    <style>
      .container>div{
        border: 2px solid blue;
      }
      .container>div>div{
        border: 2px solid red;
        height: 200px;
        width: 200px;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="clearfix">
        <div class="pull-right">1 right</div>
        <div class="pull-left">2 left</div>
      </div>
    </div>
    <script src="js/jquery-3.4.1.js"></script>
    <script src="bootstrap/js/bootstrap.js"></script>
  </body>
</html>
```

# 9、响应式工具类

- 为了加快对移动设备友好的页面开发工作，利用媒体查询功能并使用这些工具类可以方便的针对不同设备展示或隐藏页面内容。

```
有针对性的使用这类工具类，从而避免为同一个网站创建完全不同的版本。相反，通过使用这些工具类可以在不同设备上提供不同的展现形式。
```

- 可以使用的类

|                 | 超小屏幕手机 (<768px) | 小屏幕平板 (≥768px) | 中等屏幕桌面 (≥992px) | 大屏幕桌面 (≥1200px) |
| --------------- | --------------------- | ------------------- | --------------------- | -------------------- |
| `.visible-xs-*` | 可见                  | 隐藏                | 隐藏                  | 隐藏                 |
| `.visible-sm-*` | 隐藏                  | 可见                | 隐藏                  | 隐藏                 |
| `.visible-md-*` | 隐藏                  | 隐藏                | 可见                  | 隐藏                 |
| `.visible-lg-*` | 隐藏                  | 隐藏                | 隐藏                  | 可见                 |
| `.hidden-xs`    | 隐藏                  | 可见                | 可见                  | 可见                 |
| `.hidden-sm`    | 可见                  | 隐藏                | 可见                  | 可见                 |
| `.hidden-md`    | 可见                  | 可见                | 隐藏                  | 可见                 |
| `.hidden-lg`    | 可见                  | 可见                | 可见                  | 隐藏                 |

```
* 的取值为block、inline、inline-block
```

```html
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap 101 Template</title>
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

    <style>

      .container{
        height: 1000px;
        background-color: yellowgreen;
      }

      #link-pc{
        width: 80px;
        height: 200px;
        background-color: deeppink;
        position: fixed;
        right: 0px;
        top: 200px;
      }
      #link-mobile{
        height: 80px;
        width: 100%;
        background-color: purple;
        position: fixed;
        bottom: 0px;
      }
    </style>
  </head>
  <body>
    <div class="container">

    </div>
    <div id="link-pc" class="hidden-xs"></div>
    <div id="link-mobile" class="visible-xs-block"></div>
    <script src="js/jquery-3.4.1.js"></script>
    <script src="bootstrap/js/bootstrap.js"></script>
    <script>
      function fn1(){
        alert("禁用按钮测试！");
      }
    </script>
  </body>
</html>

```




















