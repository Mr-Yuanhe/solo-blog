title: war包方式部署solo博客
date: '2019-09-13 00:26:12'
updated: '2019-09-13 00:26:12'
tags: [安装教程]
permalink: /articles/2019/09/21/1568995728707.html
---
# war包方式部署solo个人博客步骤如下
1. 环境和文件准备
2. 安装JDK
3. 安装Tomcat
4. 安装MySQL并创建solo库
5. 部署 Solo

# 1. 环境和文件准备

- 服务器：我用的是腾讯云服务器，系统是CentOS 7.3 64 位。
- JDK：1.8
- Tomcat： 9.0.24
- MySQL：5.7
- solo：solo-v3.6.4.war

这里介绍一款远程软件，等会要用他登录和传文件（如果有可跳过）
- FinalShell `免费的且功能强大，可以远程登录和传文件`
- 下载地址：  
 [Windows版下载](http://www.hostbuf.com/downloads/finalshell_install.exe)   
 [macOS版下载](http://www.hostbuf.com/downloads/finalshell_install.pkg)

SSH登录服务器（建议下载FinalShell登录，因为后面传文件也比较方便）
下载安装完成点击SSH连接
![image.png](https://img.hacpai.com/file/2019/09/image-886cbc77.png)

输入相关信息连接成功页面
- 如果连接失败可能是Linux没有安装SSH，具体怎么安装，自行百度

![image.png](https://img.hacpai.com/file/2019/09/image-493e60a4.png)


# 2. 安装JDK

运行
```
java -version
```
如果没有出现版本信息则没有安装JDK
- [点击查看Centos7 安装 JDK](http://106.54.54.131/articles/2019/09/20/1568989171576.html)

# 3. 安装Tomcat

- 可以通过官网下载最新版的也可以直接点击下载我在使用的版本

1. [Tomcat官网](https://www-us.apache.org/dist/tomcat/tomcat-9/)  -> **v9.x.x** -> **/bin** -> 点击后缀名为 **.tar.gz** 的文件下载，大概十几M，别下错了
2. 下载我在使用的版本[点击下载Tomcat-9.0.24](http://package.yuanheweb.com/linux-file/apache-tomcat-9.0.24.tar.gz)

- 把Tomcat文件上传到系统的 **/usr/local/** 目录下
- 在FinalShell软件的下方有系统的目录文件
- 依次点击 usr -> local 在右边空白处右击上传
![image.png](https://img.hacpai.com/file/2019/09/image-83ca43cb.png)

上传完毕后
- 进入/usr/local解压文件（看清tomcat的版本自行修改命令）
```
cd /usr/local
tar -zxvf apache-tomcat-9.0.24.tar.gz 
```
- 修改名称
```
mv ./apache-tomcat-9.0.24 ./tomcat9
```
- 进入conf目录修改server.xml文件
```
cd /usr/local/tomcat9/conf
vi server.xml
```
- 找到这一行大概在70行左右，按 **i** 键修改8080端口为80，通过80端口访问，访问时默认端口会隐藏，输入 **:wq** 保存并退出（英文冒号）

![image.png](https://img.hacpai.com/file/2019/09/image-4e0e7aa0.png)

# 4. 安装MySQL并创建solo库

如果已安装可跳过
[CentOS 7 安装MySQL 5.7](http://106.54.54.131/articles/2019/09/16/1568611730681.html)

- 登录 MySQL 并手动建库（库名 solo，字符集使用 utf8mb4，排序规则 utf8mb4_general_ci）
1. 登录
```
mysql -u用户名 -p你的密码
```
2. 建库
```
CREATE DATABASE `solo` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
```

# 5. 部署 Solo

- 下载solo.war包 -> 两种方式
	1. 下载我使用的 [点击下载solo-v3.6.4.war](http://package.yuanheweb.com/linux-file/solo-v3.6.4.war)
	2. 下载最新的 [点击进入下载页面](https://github.com/b3log/solo/releases)

- 将Tomcat下 /webapps/ROOT 目录清空，将war包解压到里面
```
cd /usr/local/tomcat9/webapps/ROOT
rm -rf ./*
```
- 通过FinalShell将solo.war包上传至 **/usr/local/tomcat9/webapps/ROOT**目录下解压
```
cd /usr/local/tomcat9/webapps/ROOT
jar -xvf solo-v3.6.4.war
```
- 删除solo.war包
```
rm -rf solo-v3.6.4.war
```
- 修改配置文件 latke.properties 和 local.properties

先进入文件路径
```
cd /usr/local/tomcat9/webapps/ROOT/WEB-INF/classes
```
vi命令编辑配置文件
1. 编辑latke.properties
```
vi latke.properties
```
配置 solo 的访问域名端口和模式  
>serverHost=你的已解析的域名（如果这行注释掉，那么访问地址就是你的服务器的地址）
>serverPort默认为80

![image.png](https://img.hacpai.com/file/2019/09/image-63942812.png)
**注意：** 一定要把注释去掉
![image.png](https://img.hacpai.com/file/2019/09/image-5207678d.png)

2. 配置数据库

```
vi local.properties
```
```  
配置MySQL用户名和密码   
jdbc.username=用户名   
jdbc.password=密码  
```
```
#### MySQL runtime ####
runtimeDatabase=MYSQL
jdbc.username=root -> 改成你的用户名（有solo库的那个用户）
jdbc.password=123456 -> 数据库密码
jdbc.driver=com.mysql.cj.jdbc.Driver
jdbc.URL=jdbc:mysql://localhost:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC
```

- 配置完成之后，就可以启动Tomcat，进入到目录 **cd /usr/local/tomcat9/bin**，执行命令：./startup.sh，然后通过你的域名访问博客了。
```
cd /usr/local/tomcat9/bin
./startup.sh
```

如果进不去可以关闭防火墙再试
关闭防火墙命令
```
systemctl stop firewalld
```
禁止开机自启
```
systemctl disable firewalld
```

如果怕关闭防火墙不安全，可以自行百度打开端口

现在可以放飞自我了！！！
![image.png](https://img.hacpai.com/file/2019/09/image-2e9391ec.png)

