title: Java每天十道题 - day08
date: '2019-11-12 13:46:40'
updated: '2019-11-12 13:50:11'
tags: [Java-每天十道题, Java面试题, Java]
permalink: /articles/2019/11/12/1573537600267.html
---
## 1.servlet是单例的还是多例的.能不能使用实例变量
```
（1）：Servlet单实例，减少了产生servlet的开销；
（2）：通过线程池来响应多个请求，提高了请求的响应时间；
（3）：Servlet容器并不关心到达的Servlet请求访问的是否是同一个Servlet还是另一个Servlet，直接分配给它一个新的线程；如果是同一个Servlet的多个请求，那么Servlet的service方法将在多线程中并发的执行；
（4）：每一个请求由ServletRequest对象来接受请求，由ServletResponse对象来响应该请求
```

## 2.jsp的四大作用域
```
1.page：在一个页面内保存属性，跳转之后无效。  
2.request：在一次请求范围内有效，服务器跳转之后依然有效。  
3.session：在一次会话范围内有效，网页重新打开之后无效。典型用法，用户登录。  
4.application: 在整个服务器上保存，对所有用户都有用。典型用法，比如网站计数等，只有服务器重启之后，才能释放。
```

## 3.jsp与servlet的区别与联系

```
1.jsp经编译后就变成了Servlet.

2.jsp更擅长表现于页面显示,servlet更擅长于逻辑控制.

3.Servlet能够很好地组织业务逻辑代码，但是在Java源文件中通过字符串拼接的方式生成动态HTML内容会导致代码维护困难、可读性差

4.JSP虽然规避了Servlet在生成HTML内容方面的劣势，但是在HTML中混入大量、复杂的业务逻辑同样也是不可取的
```

## 4.context-param与init-param的区别

```
第一种参数在servlet里面可以通过getServletContext().getInitParameter("context/param")得到

第二种参数只能在servlet的init()方法中通过this.getInitParameter("param1")取得
```

## 5.super和this的用法是什么

```
super指代父类，可以使用super来调用父类里面的方法和变量。可以使用super调用父类的构造方法，但必须放在第一行；

this指代的是当前类。
```

## 6.静态代码块.非静态代码块.构造方法的加载顺序是什么

```
静态代码块（类加载之时，只加载一次）--> 构造方法（类实例化之时，实例化几次执行几次）--> 非静态代码块（类实例化，实例化几次执行几次）
```

## 7.什么是javaBean

>Java Bean 实际是就是一个普通的 Java Class，但是需要满足三个要求 

``` 
1、所有属性为 private，只允许通过getter方法和setter方法访问对象的属性  
2、必须具有一个无参的构造函数  
3、实现serializable接口
```

## 8.resultMap, resultType, parameterType, parameterMap

```
1.resultMap即ORM的实现，当表里面的列名与类里面的成员变量名不同时，需要定义对应关系。在select定义中，只需要引入resultMap的id即可。

2.resultType用于表里面的列名和类里面的成员变量名相同时，直接使用对应的类名即可。

3.parameterType

4.parameterMap
```

## 9.p命名空间和util命名空间的意义是什么
```xml
p命名空间用来把通过property写的方式变成通过属性来写，例如：

<bean id="user" class="com.entity.User">
<property name="name" value="zhang" />
</bean>
变为
<bean id="user" class="com.entity.User" p:name="zhang" />
util命名空间用来定义集合例如list, set, property, map等，方便复用。
```


## 10.ModelAndView、Map、Model、@SessionAttributes、@ModelAttribute等注解的意义是什么

```
1.ModelAndView：模型和视图，它里面既能存放模型数据，也能存放视图。

2.Map: 它里面存放的数据是以键值对的形式存在，里面只存放数据；

3.Model: 它里面存放的数据是以键值对的形式存在，里面也只存放数据，一般与ModelAttribute配合使用。凡是方法上标记了ModelAttribute注解的，这个方法会在其他方法被访问之前执行，并且将数据放到Model，而其他方法也将获取到Model中的数据；

4.SessionAttributes: 如果ModelAttribute是以Request方式存放数据的，那么SessionAttributes是将数据放在Session中的，而且只能将此注解放到类上面。
```

