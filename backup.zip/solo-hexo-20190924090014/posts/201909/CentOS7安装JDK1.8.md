title: 'CentOS 7安装JDK1.8 '
date: '2019-09-16 14:50:52'
updated: '2019-09-16 14:50:52'
tags: [Linux]
permalink: /articles/2019/09/20/1568989171576.html
---
# 准备工具

1. SSH登录工具 `我这里用的远程登录工具是FinalShell（免费）`
- FinalShell下载地址：  
 [Windows版下载](http://www.hostbuf.com/downloads/finalshell_install.exe)   
 [macOS版下载](http://www.hostbuf.com/downloads/finalshell_install.pkg)
2. 上传工具
```
FinalShell自带上传功能
如果用WinSCP或者其他上传工具也可以
Mac可以直接在终端用scp命令上传: scp 本机的文件路径 服务器用户名@服务器ip地址:目录
```

3. SSH登录服务器（建议下载FinalShell登录，因为后面传文件也比较方便）
下载安装完成点击SSH连接
![image.png](https://img.hacpai.com/file/2019/09/image-886cbc77.png)

输入相关信息连接成功页面
- 如果连接失败可能是Linux没有安装SSH，具体怎么安装，自行百度

![image.png](https://img.hacpai.com/file/2019/09/image-493e60a4.png)



# 下载JDK

[下载地址](https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)

点击接受，然后点击下载Linux x64中的 __tar.gz__ 这个文件
![image.png](https://img.hacpai.com/file/2019/09/image-2dd20350.png)

下载完成后上传到系统中
- 在系统的 **/usr/local** 下新建一个java文件夹
```
cd /usr/local
mkdir java
```
- 然后将刚刚下载的jdk上传到此文件夹下。这里用FinalShell图形化上传

在FinalShell界面的下方有系统的目录
依次点击 usr -> local -> java  在空白处右击上传
![image.png](https://img.hacpai.com/file/2019/09/image-f81aa541.png)

上传完毕！查看一下
```
cd /usr/local/java
ls
```
![image.png](https://img.hacpai.com/file/2019/09/image-e7dbe4d6.png)

# 解压并配置环境变量

1. 解压
```
tar -zxvf jdk-8u221-linux-x64.tar.gz
```
2. 配置环境变量
```
vi /etc/profile
```
在英文输入法的情况下按 **i** 键进入编辑模式，在文件的顶部写入如下信息

```
export JAVA_HOME=/usr/java/jdk1.8.0_221
export PATH=$JAVA_HOME/bin:$PATH
export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
export JRE_HOME=$JAVA_HOME/jre
```
写完之后先按**esc**键，然后输入 **:wq** 保存信息并退出（冒号是英文）

- 然后使环境变量生效
```
source /etc/profile
```

# 测试安装成功

```
java -version
```
出现如下信息则表示安装成功
![image.png](https://img.hacpai.com/file/2019/09/image-3d490007.png)

