title: Docker打包镜像
date: '2024-08-26 09:34:20'
updated: '2024-08-27 20:54:05'
tags: [Docker]
permalink: /articles/2024/08/26/1724636060523.html
---
# 1. 编写Dockerfile

简单制作一个 Ubuntu 环境，如果想设置更多参数，参考 [菜鸟Docker](https://www.runoob.com/docker/docker-dockerfile.html)

```
FROM ubuntu:22.04
LABEL maintainer="jiushuokj-YH"
RUN apt-get -y update
COPY lib.tar /
WORKDIR /
ENV JAVA_HOME=/xxx
CMD ["tail", "-f", "/dev/null"]
```

参数

- RUN
  执行命令，内部执行，这里是更新了下apt-get
- COPY
  复制当前文件夹至容器，把当前目录lib.tar复制到容器的/下
- WORKDIR
  指定工作目录，类似于 `cd /`
- ENV
  设置环境变量，在后续的指令中使用
- CMD
  容器启动时执行的指令，程序运行结束，容器也就结束
  CMD 指令指定的程序可被 docker run 命令行参数中指定要运行的程序所覆盖
  **注意** ：如果 Dockerfile 中如果存在多个 CMD 指令，仅最后一个生效。

# 2. build

```
docker build -t test:latest .
```

latest 可以换成版本号

# 3. 上传至Docker Hub

1. 在 [Docker Hub](https://hub.docker.com/) 注册账号
2. cmd窗口输入 `docker login` 登录
3. `docker tag test:tag username/test:tag `
4. 最后 `docker push username/test:tag`

# 4. 导出

```
docker save -o test.tar test:tag
```

# 5. 导入

```
docker load -i test.tar
```

