title: 华为--HCIA
date: '2019-10-31 10:42:27'
updated: '2019-10-31 10:42:27'
tags: [待分类]
permalink: /articles/2019/10/31/1572489747535.html
---
#### 1.Flume 的数据流可以根据 headers 的信息发送到不同的 channel 中。A

```
A. 正确
B. 错误
```

#### 12.Spark 任务的每个 stage 可划分为 job ，划分的标记是 shuffle 。B 

```
A. 正确
B. 错误

```
