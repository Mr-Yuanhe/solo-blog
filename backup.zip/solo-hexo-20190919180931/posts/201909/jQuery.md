title: jQuery
date: '2019-09-18 21:30:07'
updated: '2019-09-18 21:30:07'
tags: [jQuery]
permalink: /articles/2019/09/18/1568813407846.html
---
# 1、事件

- 鼠标事件

```
mousedown() 触发、或将函数绑定到指定元素的 mouse down 事件 
mouseup() 触发、或将函数绑定到指定元素的 mouse up 事件 

mouseenter() 触发、或将函数绑定到指定元素的 mouse enter 事件 
mouseleave() 触发、或将函数绑定到指定元素的 mouse leave 事件

mouseover() 触发、或将函数绑定到指定元素的 mouse over 事件 
mouseout() 触发、或将函数绑定到指定元素的 mouse out 事件 

mousemove() 触发、或将函数绑定到指定元素的 mouse move 事件 
```

```html
<head>
  <style>
    #d1{
      height: 200px;
      width: 400px;
      background-color: yellowgreen;
    }
  </style>
</head>
<body>
  <button>鼠标事件测试</button>
  <div id="d1">

  </div>
  <script src="js/jquery-3.4.1.js"></script>
  <script>
    $(function () {

      /*鼠标按事件*/
      $("button").mousedown(function () {
        console.log("鼠标被你按下去了！");
      });

      /*鼠标松事件*/
      $("button").mouseup(function (e123) {
        console.log("鼠标被你松开了！");
      });
      /*鼠标进入事件*/
      $("#d1").mouseenter(function (abc) {
        console.log("鼠标进来了！");
      });

      /*鼠标离开事件*/
      $("#d1").mouseleave(function (a) {
        console.log("鼠标出去了！");
      });

      /*鼠标移动事件*/
      $("#d1").mousemove(function (e) {
        //回调函数中的参数e就相当于内置对象event
        console.log(event);
        //this就是表示当前调用对象（dom节点对象），需要转成jquery对象$(this)
        /*text() 设置或返回匹配元素的text内容。 */
        $(this).text(event.pageX+";"+event.pageY);
      });
    });
  </script>
</body>
```

- 键盘事件

```
keydown() 触发、或将函数绑定到指定元素的 key down 事件 
keypress() 触发、或将函数绑定到指定元素的 key press 事件 
keyup() 触发、或将函数绑定到指定元素的 key up 事件 

# 主要了解一下键盘事件的event对象
```

```html
<input type="text" id="username">
<script src="js/jquery-3.4.1.js"></script>
<script>
  $(function () {
    $("#username").keypress(function (e) {
      //console.log(e);
      if(e.key=="Enter"){
        console.log("提交数据！");
      }
    });
  });
</script>
```

- 点击事件

```
click();
dblclick();
```

- 绑定事件

```
bind();	可以绑定任何事件
unbind();

on();可以绑定任何事件
off();

one();绑定的时间只生效一次
```

```html
<button>dblclick</button>
<button>bind</button>
<button>on</button>
<button>unbind</button>
<button>off</button>
<button>one</button>
<script src="js/jquery-3.4.1.js"></script>
<script>
  $(function () {
    $("button:eq(0)").dblclick(function () {
      alert("双击666");
    });

    /*bind(事件类型，callback)*/
    $("button:eq(1)").bind("click",function () {
      alert("绑定一个点击事件");
    });
    $("button:eq(2)").on("click",function () {
      alert("用on绑定一个点击事件");
    });

    /*unbind(事件类型)是解除事件的方法，如果带参数，就解指定事件，不带参数，解除所有事件*/
    $("button:eq(3)").click(function () {
      $("button").unbind();
    });

    /*one(),绑定一次事件*/
    $("button:eq(5)").one("click",function () {
      alert("用one绑定一个点击事件");
    });
  });
</script>
```

- 表单提交事件

```
submit();
```

- 表单控件相关事件

```
change();值改变事件，用于下拉框
select();鼠标选中文本触发的事件
blur();离开焦点事件
focus();获得焦点事件
```

```html
<div>
  <label>搜索项：</label>
  <select name="address">
    <option value="nj">南京</option>
    <option value="yz">扬州</option>
    <option value="hf">合肥</option>
    <option value="sz">苏州</option>
  </select>
</div>

<input type="text" id="username" value="admin">

<script src="js/jquery-3.4.1.js"></script>
<script>
  $(function () {
    $("[name='address']").change(function () {
      /*$(this)表示jquery当前对象*/
      var address = $(this).val();
      console.log(address);
    });

    $("#username").select(function (e) {
      console.log(e);
    });

    $("#username").focus(function () {
      $(this).css("background","orange");
    });

    $("#username").blur(function () {
      $(this).css("background","#ccc");
    });
  });
</script>
```

# 2、复合事件

- 一个事件有两个或者多个回调函数的事件，这个两个回调函数分别执行不同的功能

```
hover(fn1,fn2);相当于mouseover和mouserout两个事件在一起
toggle();在1.9版本该事件被取消，直接沦为方法
```

```html
<ul>
  <li>aaa</li>
  <li>bbb</li>
  <li>ccc</li>
  <li>ddd</li>
  <li>yyy</li>
  <li>zzz</li>
</ul>
<script src="js/jquery-3.4.1.js"></script>
<script>
  $(function () {
    /*给每一个li添加一个mouseover事件*/
    //           $("li").mouseover(function () {
    //               /*$(this)表示当前对象*/
    //               $(this).css("background","orange");
    //           });
    //
    //            $("li").mouseout(function () {
    //                /*$(this)表示当前对象*/
    //                $(this).css("background","");
    //            });

    /*复合事件hover(fn1,fn2)*/
    $("li").hover(function () {
      $(this).css("background","pink");
    },function () {
      $(this).css("background","");
    });
  });
</script>
```

# 3、事件冒泡

- 什么是事件冒泡

```
给父元素添加一个点击事件
给子元素也添加一个点击事件
当点击子元素的时候，会触发自己的事件，也会触发父元素的事件
```

- 阻止事件冒泡

```
# 方法1
event.cancelBubble=true;

# 方法2
 event.stopPropagation();
```

- 阻止默认事件

```
event.preventDefault();
```

```html
<head>
  <style>
    #d1{
      width: 600px;
      height: 600px;
      border: 3px solid red;
      margin: 50px auto;
    }
    #d2{
      width: 400px;
      height: 400px;
      border: 3px solid blue;
      margin: 100px;
    }

    #d3{
      width: 200px;
      height: 200px;
      border: 3px solid green;
      margin: 125px 100px;
    }
  </style>

</head>
<body>
  <div id="d1">
    <div id="d2">
      <div id="d3">

      </div>
    </div>
  </div>
  <script src="js/jquery-3.4.1.js"></script>
  <script>
    $(function () {
      $("#d1").click(function () {
        alert(111);
      });
      $("#d2").click(function () {
        alert(222);
        event.cancelBubble=true;

      });
      $("#d3").click(function () {
        alert(333);
        event.stopPropagation();
      });
    });
  </script>
</body>
```

# 4、效果操作

- 动画

```
animate() 对被选元素应用“自定义”的动画 
```

- 隐藏和显示

```
hide(time) 隐藏被选的元素 
show(time) 显示被选的元素 
toggle(time) 对被选元素进行隐藏和显示的切换 
```

```html
<img src="./img/cxk.jpg" alt="" width="200px">
<hr>
<button>隐藏</button>
<button>显示</button>
<button>切换</button>

<script src="js/jquery-3.4.1.js"></script>
<script>
  $(function () {
    $("button:eq(0)").click(function () {
      //$("img").css("display","none");
      $("img").hide(5000);

    });
    $("button:eq(1)").click(function () {
      $("img").show(3000);

    });
    $("button:eq(2)").click(function () {
      $("img").toggle(3000);
    });
  });
</script>
```

- 淡入和淡出

```
fadeIn() 逐渐改变被选元素的不透明度，从隐藏到可见 
fadeOut() 逐渐改变被选元素的不透明度，从可见到隐藏 
fadeTo() 把被选元素逐渐改变至给定的不透明度 
```

```html
<img src="./img/cxk.jpg" alt="" width="200px">
<hr>
<button>淡出</button>
<button>淡入</button>
<button>淡入到某种程度</button>


<script src="js/jquery-3.4.1.js"></script>
<script>
  $(function () {
    $("button:eq(0)").click(function () {
      $("img").fadeOut(3000);
    });
    $("button:eq(1)").click(function () {
      $("img").fadeIn(3000);
    });
    $("button:eq(2)").click(function () {
      $("img").fadeTo(3000,0.5,function () {
        alert("效果完成！");
      });
    });
  });
</script>
```

- 滑动显示和滑动隐藏

```
slideDown() 通过调整高度来滑动显示被选元素 
slideUp() 通过调整高度来滑动隐藏被选元素 
slideToggle() 对被选元素进行滑动隐藏和滑动显示的切换 
```

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <style>
      #box{
        height: 500px;
        width: 300px;
        background-color: yellowgreen;
      }
    </style>
  </head>
  <body>

    <button>滑动隐藏</button>
    <button>滑动显示</button>
    <button>滑动切换</button>
    <div id="box">

    </div>

    <script src="js/jquery-3.4.1.js"></script>
    <script>
      $(function () {
        $("button:eq(0)").click(function () {
          $("#box").slideUp(3000);
        });
        $("button:eq(1)").click(function () {
          $("#box").slideDown(3000);
        });
        $("button:eq(2)").click(function () {
          $("#box").slideToggle(3000);
        });
      });
    </script>
  </body>
</html>
```

- 自定义动画

```
animate() 对被选元素应用“自定义”的动画 
```

- 语法

```
$(selector).animate(styles,speed,easing,callback);
```

- 注意点

```
使用 "+=" 或 "-=" 来创建相对动画（relative animations）。
```

```html
<head>
  <meta charset="UTF-8">
  <title>Title</title>
  <style>
    #box{
      height: 100px;
      width: 100px;
      background-color: yellowgreen;
      position: relative;
    }
  </style>
</head>
<body>
  <button>动次打次</button>
  <div id="box">
  </div>
  <script src="js/jquery-3.4.1.js"></script>
  <script>
    $(function () {
      $("button:eq(0)").click(function () {
        /*$(selector).animate(styles,speed,easing,callback)*/
        //$("#box").animate({height:"300px",width:"300px"},3000);
        $("#box").animate({left:"+=300px",top:"+=100px"},3000);
      });
    });
  </script>
</body>
```

# 5、属性操作

- dom如何操作属性的

```
# 设置元素的属性
ele.setAttribute(属性名,属性值);

# 获取元素的属性值
var 属性值 = ele.getAttribute(属性名)
```

- jquery对象是如何操作属性的

```
attr() 设置或返回匹配元素的属性和值。 
removeAttr() 从所有匹配的元素中移除指定的属性。 

prop()置或返回匹配元素的属性和值。
removeProp()浏览器已经对他失效。
```

```html
<img alt="蔡徐坤" width="200px">
<hr>
<button>attr设置属性值</button>
<button>attr取src属性值</button>
<button>移除src属性</button>
<hr>
<button>prop设置属性值</button>
<button>prop取属性值</button>
<script src="js/jquery-3.4.1.js"></script>
<script>
  $(function () {
    $("button:eq(0)").click(function () {
      //src="./img/cxk.jpg"
      $("img").attr("src","./img/cxk.jpg");

    });
    $("button:eq(1)").click(function () {
      var url = $("img").attr("src");
      alert(url);
    });
    $("button:eq(2)").click(function () {
      $("img").removeAttr("src");
    });

    $("button:eq(3)").click(function () {
      $("img").prop("src","./img/cxk.jpg");
    });
    $("button:eq(4)").click(function () {
      var url = $("img").prop("src");
      alert(url);
    });
  });
</script>
```

- attr与prop的区别

```
attr是对dom属性节点操作
prop是对元素固有的特征
```

```html
<input type="checkbox" name="hobby">
<hr>
<button>attr设置选中</button>
<button>attr获取选中的值</button>
<hr>
<button>prop设置选中</button>
<button>prop获取选中的值</button>

<script src="js/jquery-3.4.1.js"></script>
<script>
  $(function () {

    $("button:eq(0)").click(function () {
      $("[name='hobby']").attr("checked","checked");
    });
    $("button:eq(1)").click(function () {
      var value =  $("[name='hobby']").attr("checked");
      alert(value);
    });

    $("button:eq(2)").click(function () {
      $("[name='hobby']").prop("checked",true);
    });
    $("button:eq(3)").click(function () {
      var value =  $("[name='hobby']").prop("checked");
      alert(value);
    });
  });
</script>
```

- 总结

```
不管什么属性操作，全部使用prop这个方法！
```

# 6、样式操作

- 基本样式

```
css() 设置或返回匹配元素的样式属性。 
```

- 样式类操作

```
addClass(样式类型名) 向匹配的元素添加指定的类名。 
hasClass(样式类型名) 检查匹配的元素是否拥有指定的类。 
removeClass(样式类型名) 从所有匹配的元素中删除全部或者指定的类。 
toggleClass(样式类型名) 从匹配的元素中添加或删除一个类。 
```

```html
<head>
  <meta charset="UTF-8">
  <title>Title</title>
  <style>
    .c1{
      border:5px solid red;
      border-radius: 50%;
      opacity: 0.5;
    }
  </style>
</head>
<body>

  <img src="./img/cxk.jpg" class="c2 c3 c4" width="200px">
  <hr>
  <button>css方法添加样式</button>
  <button>addClass方法添加样式类</button>
  <button>判断是否有样式c1</button>

  <script src="js/jquery-3.4.1.js"></script>
  <script>
    $(function () {
      $("button:eq(0)").click(function () {
        /*边框，边框圆角，透明度0.5*/
        $("img").css("border","3px solid yellowgreen");
        $("img").css("border-radius","50%");
        $("img").css("opacity","0.5");
      });
      $("button:eq(1)").click(function () {
        $("img").addClass("c1");
      });

      $("button:eq(2)").click(function () {
        var b = $("img").hasClass("c1");
        alert(b);
      });
    });
  </script>
</body>
```

# 7、内容操作

- 三个方法

```
val() 设置或返回匹配元素的value值。 

text() 设置或返回匹配元素的内容。 就相当于dom中的textContent属性
html() 设置或返回匹配的元素集合中的 HTML 内容。 就相当于dom中的innerHTM属性
```

```
$.text("<h1>hello world</h1>");//h1标签以文本显示

$.html("<h1>hello world</h1>");//h1会以标签形式去渲染，最终文本会变为一个标题
```

# 8、jquery中的dom操作

- 对页面上的元素，进行增删改查

- 创建jquery对象（json对象用来做配置）

```js
# 语法

var $标签名 = $("<标签名>",{
  属性名:属性值,
  text:文本值
});
```

- 添加节点

```
append(jquery对象、字符串) 向匹配元素集合中的每个元素结尾插入由参数指定的内容。 
appendTo(jquery对象、选择器) 向目标结尾插入匹配元素集合中的每个元素。 

prepend(jquery对象、字符串) 向匹配元素集合中的每个元素开头插入由参数指定的内容。 
prependTo(jquery对象、选择器) 向目标开头插入匹配元素集合中的每个元素。 
```

```html
<h1>你看过的动画片</h1>

<ul>
  <li>喜洋洋与灰太狼</li>
  <li>葫芦娃</li>
  <li>机器猫</li>
  <li>海尔兄弟</li>
  <!--<li title="dntg">大闹天宫</li>-->
</ul>

<script src="js/jquery-3.4.1.js"></script>
<script>
  $(function () {
    $("ul").append("<li class='error'>海尔兄弟1234</li>");

    //创建jquery对象
    var $li = $("<li>",{
      text:"大闹天宫",
      title:"dntg",
      class:"error"
    });
    console.log($li);
    /*在元素的末尾添加一个子元素*/
    //$("ul").append($li);

    /*把目标对象添加到指定元素的末尾*/
    //$li.appendTo($("ul"));
    $li.appendTo("ul");

    $("ul").prepend("<li class='error'>天线宝宝</li>");

  });
</script>
```

# 9、删除节点

- 方法

```
remove() 移除所有匹配的元素。 
detach() 从 DOM 中移除匹配元素集合。 
注意：detach() 会保留所有绑定的事件、附加的数据，这一点与 remove() 不同。
empty() 删除匹配的元素集合中所有的子节点。 
```

```html
<h1>你看过的动画片</h1>
<ul>
  <li>喜洋洋与灰太狼</li>
  <li id="item">葫芦娃</li>
  <li>机器猫</li>
  <li>海尔兄弟</li>
</ul>
<hr>

<button>remove</button>
<button>detach</button>
<button>empty</button>
<button>remove</button>

<script src="js/jquery-3.4.1.js"></script>
<script>
  $(function () {

    $("button:eq(0)").click(function () {
      var $li = $("#item").remove();
      $("ul").append($li);
    });

    $("button:eq(1)").click(function () {
      var $li = $("#item").detach();
      $("ul").append($li);
    });

    $("#item").click(function () {
      alert("1234");
    });

    $("button:eq(2)").click(function () {
      $("ul").empty();
    });

    $("button:eq(3)").click(function () {
      $("ul").remove();
    });
  });
</script>
```

# 10、其他文档操作

- before
- after

- 核心方法

```
...
```




















