title: Java每天十道题 - day09
date: '2019-11-13 13:50:02'
updated: '2019-11-13 13:50:02'
tags: [Java-每天十道题, Java笔记, Java面试题, Java]
permalink: /articles/2019/11/13/1573624201947.html
---
## 1.java中的8种基本数据类型是什么？各占几个字节？为什么要有包装类？什么是装箱和拆箱机制

- 基本类型
```
整数类型
	byte(-128~127) 1个字节
	short(-32768 ~ 32767) 2个字节
	int 4个字节
	long 8个字节
浮点数类型
	float 4个字节
	double 8个字节
字符类型
	char 2个字节
布尔类型
	boolean 1位bit,
```
- 为什么要有包装类
```
java中8种基本数据类型的存在导致其并不是纯粹面向对象的语言。为了弥补这一缺陷，变引入了各个基本类型的包装类。
例如int-Integer, char-Character, boolean-Boolean等
```
- 什么是装箱和拆箱机制

```
包装类转化为基本类型，这是拆箱；基本类型转化为包装类，这是装箱。基本类型和包装类型之间能够混用，就是因为装箱拆箱机制的存在。
```

## 2.如何获取-100~+100之间的10个随机数

```
new Random().nextInt(200)-100;
Math.random()
```


## 3.异常的体系结构是咋样的

```
Throwable
        Error
        Exception
            RuntimeException
                NullpointException
                ArrayIndexOutofBoundsException
                ArithmeticException
                InputMismatchException
                NumberFormatException
```

## 4.哪些接口或者类有排序功能

- 接口：

>Comparator, Comparable, SortedSet, SortedMap

- 类：

>TreeSet, TreeMap

## 5.区分字节流、字符流、缓冲流以及随机流
```
1.字节流是以字节为单位进行读写，对应的接口有InputStream(输入 读), OutputStream（输出 写）
2.字符流是以字符为单位进行读写，对应的接口有Reader(输入 读)，Writer（输出 写）
3.缓冲流是按行读写，对应的接口有BufferedReader（输入 读），BufferedWriter（输出 写）
4.随机流是根据文件指针位置读取，对应的类是RandomAccessFile
```
## 6.阐述生产者消费者模式。使用线程如何模拟

```
以一个具体的例子来看这个问题：有生产者生产馒头，消费者在吃馒头，一个放馒头的篮子，生产者和消费者就相当于两个线程，篮子相当于缓冲区；用java模拟这个问题，需要定义两个线程类Producer和Consumer，以及一个栈的类SyncStack，栈相当于篮子；生产者做好馒头放进篮子里，消费者从篮子里面拿馒头。
```

## 7.区分标的内连接、外链接以及自连接

- 内连接：

>在每个表中找出符合条件的共有记录。[x inner join y on...]
```
第一种写法：（只使用where）
第二种写法：（join .. on.. ）
第三种写法：（inner join .. on.. ）
```
- 外连接

>外连接有三种方式：左连接，右连接和全连接。
```
1.左连接：
根据左表的记录，在被连接的右表中找出符合条件的记录与之匹配，如果找不到与左表匹配的，用null表示。[x left [outer] join y on...
第一种写法：（left join .. on ..）
第二种写法：（left outer join .. on ..）
第三种写法："(+)" 所在位置的另一侧为连接的方向
2.右连接：
根据右表的记录，在被连接的左表中找出符合条件的记录与之匹配，如果找不到匹配的，用null填充。[x right [outer] join y on...]
第一种写法：（right join .. on..）
第二种写法：（right outer join .. on ..）
第三种写法："(+)" 所在位置的另一侧为连接的方向
3.全连接：
返回符合条件的所有表的记录，没有与之匹配的，用null表示（结果是左连接和右连接的并集）
第一种写法：（full join .. on ..）
第二种写法：（full outer join .. on）
```
- 自连接
```
自连接，连接的两个表都是同一个表，同样可以由内连接，外连接各种组合方式，按实际应用去组合。
```
## 8.Statement、PreparedStatement和CallableStatement 的比较

- Statement：

>用于执行不带参数的简单SQL语句，并返回它所生成的结果，每次执行SQL语句时，数据库都要编译该SQL语句。

- PreparedStatement:

>表示预编译的SQL语句的对象，用于执行带参数的预编译的SQL语句。

- CallableStatement:

>则提供了用来调用数据库中存储过程的接口，如果有输出参数要注册，说明是输出参数。

## 9.如何使用反射优化数据库查询

>实体类的属性跟数据库列名一致，然后通过反射创建对象，TODO。。。

## 10.分页的关键是什么

>总记录数、每页所需要显示的记录数、显示的页数

