title: QGIS下载Mapbox地图
date: '2024-08-26 09:20:34'
updated: '2024-08-26 09:42:35'
tags: [QGIS]
permalink: /articles/2024/08/26/1724635234666.html
---
1. 登录 https://mapbox.com/ 创建图层
2. 在QGIS中添加进去

![77d4fec26de1fa05975b253478b8a20.png](https://b3logfile.com/file/2024/08/77d4fec26de1fa05975b253478b8a20-ExJF11r.png)

4. 选择范围另存GeoTIFF（注意不要勾选创建VRT）

![1724635725733.jpg](https://b3logfile.com/file/2024/08/1724635725733-ImmyuFA.jpg)

