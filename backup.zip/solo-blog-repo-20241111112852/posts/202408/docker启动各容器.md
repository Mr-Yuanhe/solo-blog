title: docker启动各容器
date: '2024-08-26 09:36:57'
updated: '2024-09-14 22:29:00'
tags: [Docker]
permalink: /articles/2024/08/26/1724636217115.html
---
如果是小白，前往 [docker compose](https://www.runoob.com/docker/docker-compose.html) 学习后再来看

文件名：docker-compose.yml

注意格式，XX是本地映射，都需要自己填写的，这里只做简单版的

开头

```
version: '3'

services:
  xx
```

以下容器按需添加

# ftp

- 单独启动：

```
docker run -d --name ftp -p 20:20 -p 21:21 -p 21100-21110:21100-21110 -v XX:/home/vsftpd/ftp -e FTP_USER=ftp -e FTP_PASS=ftp -e PASV_ADDRESS=192.168.X.X -e PASV_MIN_PORT=21100 --restart always --privileged jiushuokj/ftp
```

- docker-compose启动

```
ftp:
    image: jiushuokj/ftp
    container_name: ftp
    ports:
      - "20:20"
      - "21:21"
      - "21100-21110:21100-21110"
    volumes:
      - "XX:/home/vsftpd/ftp"
    environment:
      FTP_USER: ftp
      FTP_PASS: ftp
      PASV_ADDRESS: 192.168.X.X
      PASV_MIN_PORT: 21100
    restart: always
    privileged: true
```

# mysql

- 单独启动：

```
docker run -d --name mysql -e MYSQL_ROOT_PASSWORD=123456 -p 3306:3306 --restart always mysql
```

- docker-compose启动

```
mysql:
    image: mysql
    container_name: mysql
    environment:
    - "MYSQL_ROOT_PASSWORD=123456"
    ports:
    - 3306:3306
    restart: always
```

# mqtt

- 单独启动：

```
docker run -d --name emqx -p 18083:18083 -p 1883:1883 -p 8084:8084 -p 8883:8883 -p 8083:8083 --restart always jiushuokj/mqtt
```

- docker-compose启动

```
emq:
    image: jiushuokj/mqtt
    container_name: emqx
    ports:
    - "18083:18083"
    - "1883:1883"
    - "8084:8084"
    - "8883:8883"
    - "8083:8083"
    restart: always
```

# tomcat

- 单独启动：

```
docker run -d --name tomcat -e TZ=Asia/Shanghai -p XX:8080 -v XX/tomcat/webapps/:/usr/local/tomcat/webapps/ -v XX/tomcat/logs:/usr/local/tomcat/logs --privileged --restart always tomcat:9
```

- docker-compose启动

```
tomcat:
    restart: always
    container_name: tomcat
    image: tomcat:9
    privileged: true
    environment:
    - TZ="Asia/Shanghai"
    ports:
    - "XX:8080"
    volumes:
    - XX/tomcat/webapps/:/usr/local/tomcat/webapps/
    - XX/tomcat/logs:/usr/local/tomcat/logs
    privileged: true
    restart: always
```

# ubuntu

- 单独启动：

```
docker run -d --name ubuntu_22 -v XX:/data -p XX:22 --privileged --restart always ubuntu:22.04
```

- docker-compose启动

```
ubuntu:
    image: ubuntu:22.04
    container_name: ubuntu_22
    volumes:
    - "XX:/data"
    ports:
    - "XX:22"
    privileged: true
    restart: always
```

# gitlab

- 单独启动：

```
docker run -d --hostname 192.168.X.X -p 80:80 --name gitlab --privileged gitlab/gitlab-ce
```

- docker-compose启动

创建后，使用下面指令查看gitlab的root密码

注意：首次启动需要很久才能登录（5-10分钟）

> docker exec -it gitlab cat /etc/gitlab/initial_root_password

```
gitlab:
    hostname: "192.168.X.X"
    image: gitlab/gitlab-ce
    container_name: gitlab
    ports:
    	- "80:80"
    privileged: true
    restart: always
```

# solo

```
docker run --detach --name solo --network=host --env RUNTIME_DB="MYSQL" --env JDBC_USERNAME="solo" --env JDBC_PASSWORD="123456" --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true" b3log/solo --listen_port=端口号（一般80） --server_scheme=http --server_host=ip地址 --server_port=
```

