title: Java Web面试题
date: '2019-10-17 16:33:34'
updated: '2019-10-17 16:33:34'
tags: [Java面试题]
permalink: /articles/2019/10/17/1571301214596.html
---
# 77. 什么是Servlet

Servlet是一种服务器端的Java应用程序，具有独立于平台和协议的特性，可以生成动态的Web页面。 它承担处理客户请求（Web浏览器或其他HTTP客户程序）与服务器响应（HTTP服务器上的数据库或应用程序）的工作。 Servlet是位于Web 服务器内部的服务器端的Java应用程序，与传统的从命令行启动的Java应用程序不同，Servlet由Web服务器进行加载，该Web服务器必须包含支持Servlet的Java虚拟机。

# 78. 说一说Servlet的生命周期?

servlet有良好的生命周期的定义，包括加载和实例化、初始化、处理请求以及服务结束四个阶段。WEB容器加载Servlet，生命周期开始。首先服务器调用Servlet的构造方法执行实例化操作，然后容器调用Servlet的init方法执行初始化操作，请求到达时运行Servlet的service方法，service方法自动调用与请求类型对应的doXXX方法（doGet，doPost）等来处理请求，当服务器决定将Servlet实例销毁前调用其destroy方法（用于释放Servlet占用资源，例如流、数据库连接等）。

# 79. Servlet的基本架构 

 Servlet的框架是由两个Java包组成:javax.servlet和javax.servlet.http。 在javax.servlet包中定义了所有的Servlet类都必须实现或扩展的的通用接口和类，在javax.servlet.http包中定义了支持HTTP[通信协议](http://baike.so.com/doc/1420003.html)的HttpServlet类。Servlet的框架的核心是javax.servlet.Servlet接口，所有的Servlet都必须实现这一接口。在[Servlet接口](http://baike.so.com/doc/5500918.html)中定义了5个方法,其中有3个方法代表了Servlet的生命周期： 

- init方法,负责初始化Servlet对象
- service方法,负责相应客户的请求
- destory方法,当Servlet对象退出生命周期时,负责释放占有的资源 
- Servlet被设计成请求驱动（根据请求来调用Servlet）。Servlet的请求可能包含多个数据项,当Web容器接收到某个Servlet请求时,Servlet把请求封装成一个HttpServletRequest对象,然后把对象传给Servlet的对应的服务方法. 

HTTP的请求方式包括DELETE,GET,OPTIONS,POST,PUT和TRACE,在HttpServlet类中分别提供了相应的服务方法,它们是doDelete(),doGet(),doOptions(),doPost(), doPut()和doTrace().不过目前很多服务器只支持get和post请求，所以通常自定义的Servlet中只需要重写doPost和doGet方法即可。

# 80. 服务器如何响应Web客户请求？

HttpServlet容器响应Web客户请求流程如下： 
 　　1）Web客户向Servlet容器发出Http请求； 
 　　2）Servlet容器解析Web客户的Http请求； 
 　　3）Servlet容器创建一个HttpRequest对象，在这个对象中封装Http请求信息； 
 　　4）Servlet容器创建一个HttpResponse对象； 
 　　5）Servlet容器调用HttpServlet的service方法，把HttpRequest和HttpResponse对象作为service方法的参数传给HttpServlet对象； 
 　　6）HttpServlet调用HttpRequest的有关方法，获取HTTP请求信息； 
 　　7）HttpServlet调用HttpResponse的有关方法，生成响应数据； 
 　　8）Servlet容器把HttpServlet的响应结果传给Web客户。

# 81. Servlet API中forward() 与sendRedirect ()的区别？（就是请求转发和重定向的区别） ？

​	请求转发：请求转发是指将请求再转发到另一资源（一般为JSP或Servlet）。此过程依然在同一个请求范围内，转发后浏览器地址栏内容不变，请求转发使用RequestDispatcher接口中的forward()方法来实现，该方法可以把请求转发到另外一个资源，并让该资源对浏览器的请求进行响应 RequestDispatcher rd = request.getRequestDispatcher(path); rd.forward(request,response);    或      request.getRequestDispatcher(path) .forward(request,response);   

​       重定向：重定向是指页面重新定位到某个新地址，之前的请求失效，进入一个新的请求，且跳转后浏览器地址栏内容将变为新的指定地址。重定向是通过HttpServletResponse对象的sendRedirect()来实现，该方法相当于浏览器重新发送一个请求 response.sendRedirect(path);  •  请求转发和重定向区别如下：

​       forward()只能将请求转发给同一个Web应用中的组件，而sendRedirect()方法不仅可以重定向到当前应用程序中的其他资源，还可以重定向到其他站点的资源。

​      请求转发和重定向是Servlet处理完数据后进行页面跳转的两种主要方式 

​      sendRedirect()方法重定向的访问过程结束后，浏览器地址栏中显示的URL会发生改变，由初始的URL地址变成重定向的目标URL；而调用forward()方法的请求转发过程结束后，浏览器地址栏保持初始的URL地址不变。forward()方法的调用者与被调用者之间共享相同的request对象和response对象；而sendRedirect()方法调用者和被调用者使用各自的request对象和response对象，它们属于两个独立的请求和响应过程。

# 82. 什么情况下调用doGet()和doPost()？

Jsp页面中的form表单标签里的method属性为get时调用doGet()，为post时调用doPost()。

# 83. request对象的几个常用方法:

_______________________________________________________________________________  方法名称                                                说明

String getParameter(String name)                       根据页面表单组件名称获取页面提交数据 

String[] getParameterValues(String name)           获取一个页面表单组件对应多个值时的用户的                                                          请求数据 

void setCharacterEncoding(String charset)           指定每个请求的编码，在request.getParameter()方法之前进行设定，可以用于解决中问乱码问题 

getRequestDispatcher(String path)                      返回一个Javax.servlet.RequestDispatcher对                                                                            象，该对象的forward方法用于转发请求

setAttribute(String name,Object)                        设置名字为name的request的参数值 

getAttribute(String name)                                  返回由name指定的属性值 

getAttributeNames()                                        返回request对象所有属性的名字集合，结果是一                                                                  个枚举的实例 

# 84. 什么是Jsp

JSP（Java Server Pages, JSP）是由Sun公司提倡，许多公司共同参与一同建立起来的一种动态网页技术标准，它在动态网页建设中有强大的而特别的功能，它具有跨平台性，易维护性，易管理性等优点。

# 85. JSP的执行过程?

1)**翻译阶段**：

当Web服务器接收到JSP请求时，首先会对JSP文件进行翻译，将编写好的JSP文件通过JSP引擎转换成可识别的Java源代码。

2)**编译阶段**：

经过翻译后的JSP文件相当于我们编写好的Java源文件，此时仅有Java源文件是不够的，必须要将Java源文件编译成可执行的字节码文件。所以Web容器处理JSP请求的第二阶段就是执行编译。

3)**执行阶段**：

​       Web容器接收了客户端的请求后，经过翻译和编译两个阶段，生成了可被执行的二进制字节码文件，此时就进入执行阶段。当执行结束后，会得到处理请求的结果，Web 容器又会再把生成的结果页面返回到客户端用户面前显示。

**注意**:**只有第一次请求** **JSP** **页面或者** **JSP** 页面内容修改后访问才会执行翻译阶段和编译阶段，所有**JSP**的执行效率并不低，只是第一次访问页面时会稍微慢一点

# 86. JSP页面由哪几部分组成？

JSP页面由：静态内容，指令，表达式，小脚本，声明，标准动作，注释等七种元素构成。

# 87. JSP指令有几种？

JSP指令主要有三种：page指令，include指令，taglib指令

# 88. page指令常用属性？

------

​         属性                  描述

​         language            指定JSP页面使用的脚本语言，默认为“Java”

 

​         import               通过该属性来引用脚本语言中使用到的类文件

 

​      contentType       用来指定JSP页面所采用的编码格式，默认为“text/html;charset=GBK”                                                                 

# 89. JSP有哪些标准动作?作用分别是什么?

JSP主要共有以下几种基本动作 

jsp:include：在页面被请求的时候引入一个文件。 

jsp:useBean：寻找或者实例化一个JavaBean。 

jsp:setProperty：设置JavaBean的属性。 

jsp:getProperty：输出某个JavaBean的属性。 

jsp:forward：把请求转到一个新的页面。 

jsp:plugin：根据浏览器类型为Java插件生成OBJECT或EMBED标记

# 90. JSP中动态Include与静态Include的区别？

动态Include用jsp:include动作实现，<jsp:include page=”included.jsp” flush=true />它总是会检查所含文件中的变化，适合用于包含动态页面，并且可以带参数 

静态Include使用include指令实现,不会检查所含文件的变化，适用于包含静态页面 

<%@ include file=”included.htm”  %>

# 91. 如何实现servlet的单线程模式

通过page指令设置<%@ page isThreadSafe="false"%>，默认Servlet支持多线程模式，即有多个客户端同时请求同一个Servlet，服务器上的Servlet只会产生一个实例，但是会启动多个线程来响应客户请求，但是这样会导致线程安全问题，编程时建议不要在Servlet中定义成员属性来共享数据，以避免出现数据同步的问题。

# 92. 在JSP中如何实现页面跳转？

1)        使用javascript中的window.location.href=”要跳转的页面”。

2)        在超链接中:href=”location=要跳转的页面”，例如<a href="index.jsp">首页</a>。

3)        form表单中提交：action=”要跳转的页面”。

4)        使用jsp内置对象request或response，执行请求转发或重定向来实现页面跳转

# 93. 在servlets和JSP之间能共享session对象吗？

当然可以，session作用域中的内容，可以在多个请求中共享数据。例如可以在Servlet中通过request.getSession()来得到HttpSession对象，然后将相应数据存储到该session对象中，在其它jsp页面上都可以通过内置对象session来获取存入的值,即使这些页面是通过重定向方式跳转过去的，也可以得到值。Session本来就是用来保障在同一客户端和服务器之间多次请求之间的数据能够共享的一种机制。

# 94. 什么是Cookie？

  Cookie，有时也用其复数形式cookies，指某些网站为了辨别用户身份、进行session跟踪而储存在用户本地终端上的数据（通常经过加密）。

​       Cookie是由服务器端生成，发送给客户端浏览器的，浏览器会将其保存成某个目录下的文本文件。

# 95. 如何设置cookie在某一时间后过期？

使用cookie的setMaxAge方法设置cookie的有效时间

代码如下：

Cookie ipAddrCookie = new Cookie(“inAddr”,””+request.getRemoteAddr());

ipAddrCookie.setMaxAge(60*10);

# 96. 在JSP中如何设置Cookie？

Cookie cookie = new Cookie("cookieName","cookieValue");

其中cookieName为Cookie对象的名称,未来获取Cookie的时候需要使用。cookieValue为Cookie

对象的值也就是储存用户的信息如用户名、 密码等。

# 97. Cookie的应用场景？

1.对特定对象的追踪，如访问者的访问次数，最后访问时间、路径等

2.统计网页浏览记录。

3.在Cookie有效期内，记录用户登入信息。

4.实现各种个性化服务，如针对不同用户喜好以不同的风格展示不同的内容

提示：由于Cookie保存在客户端，所以使用Cookie存在一定的风险，所以不建议在Cookie中保存比较重要或敏感的内容。

# 98. 什么是MVC设计模式

  MVC模式是一种流行的软件的设计模式,MVC模式将应用程序实现分为3个不同的基本部分.模型,视图和控制器.

​       **模型****(Model):**表示数据和业务处理.在MVC的三个部件中,模型拥有最多的处理任务.被模型返回的数据是中立的,就是说模型与数据格式无关,这样一个模型能为多个视图提供数据,由于应用于模型的代码只需写一次就可以被多个视图重用,所以减少了代码的重复性.对应的组件是java Bean(java类).

​       **视图****(view):** 是用户看到并与之交互的界面.MVC一个最大的好处就是它能为应用程序处理很多不同的视图,在视图中其实没有真正的处理发生,不管这些数据是什么,作为视图来讲,它只是作为一种输出数据并允许用户操作的方式.对应的组件是JSP或HTML文件.视图提供可交互的界面,向客户显示模型数据.

​       **控制器****(Controller):** 接收用户的输入并调用模型组件去完成用户的请求。当用户提交一个请求时,控制器本身不做执行业务处理.它只是接收请求并决定调用哪个模型组件去处理请求,然后确定用哪个视图来显示模型处理返回的数据.对应的组件可以是Servlet. 控制器响应客户的请求,根据客户的请求来操作模型,并把模型的响应结果经由视图展现给客户.

  MVC最重要的特点就是把显示和数据分离,提高代码的可重用性.

  MVC的处理过程:

​       首先控制器接收用户的请求,并决定应该调用哪个模型来处理,然后模型处理用户的请求并返回数据,最后控制器确定相应的视图将模型返回的数据呈现给用户.

# 99. MVC设计模式的优缺点：

1)优点：

​       各司其职、互不干涉；

​       有利于开发中的分工；       

​       有利于组建的重用；

2)缺点：

​       系统结构和实现复杂；

​       视图与控制器过于紧密；

​       不适用于小型甚至中型应用程序；

# 100. Web应用的目录结构:

------

​         目录                           说明

​         /                              Web应用的根目录，该目录下的所有文件对客户端都可以访问包括JSP、HTML​        

​         /WEB-INF                存放应用程序所使用的各种资源，该目录及其子目录对客户                                                 端都是不可以访问的，其中包括web.xml（部署表述符）

​         /WEB-INF/classes      存放应用的所有class文件

​         /WEB-INF/lib           存放Web应用使用的JAR文件

​       _____________________________________________________________________

# 101. Tomcat的目录结构:

------

​         目录           说明

​         /bin            存放各种平台下用于启动和停止Tomcat的脚本文件

​         /conf          存放Tomcat服务器的各种配置文件，其中最重要的文件时server.xml

​         /lib             存放Tomcat服务器所需的各种JAR文件

​         /logs           存放Tomcat的日志文件

​         /temp          Tomcat运行时用于存放临时文件

​         /webapps     Web应用的发布目录

​         /work         Tomcat把由JSP生成的Servler放于此目录下

​       _____________________________________________________________________

# 102. Tomcat工作原理？

Tomcat是Servlet运行环境（容器），每个Servlet执行init(),service(),destory()。

下面以分析Tomcat Server处理一个http请求的过程来解释Tomcat原理。

假设来自客户的请求为：http://localhost:8080/wsota/wsota_index.jsp

1)   请求被发送到本机端口8080，被在那里侦听的Coyote HTTP/1.1 Connector获得

2)   Connector把该请求交给它所在的Service的Engine来处理，并等待来自Engine的回应

3)   Engine获得请求localhost/wsota/wsota_index.jsp，匹配它所拥有的所有虚拟主机Host

4)   Engine匹配到名为localhost的Host（即使匹配不到也把请求交给该Host处理，因为该Host被定义为该Engine的默认主机）

5)   localhost Host获得请求/wsota/wsota_index.jsp，匹配它所拥有的所有Context

6)   Host匹配到路径为/wsota的Context（如果匹配不到就把该请求交给路径名为""的Context去处理）

7)   path="/wsota"的Context获得请求/wsota_index.jsp，在它的mapping table中寻找对应的servlet

8)   Context匹配到URL PATTERN为*.jsp的servlet，对应于JspServlet类

9)   构造HttpServletRequest对象和HttpServletResponse对象，作为参数调用JspServlet的doGet或doPost方法

10)  Context把执行完了之后的HttpServletResponse对象返回给Host

11)  Host把HttpServletResponse对象返回给Engine

12)  Engine把HttpServletResponse对象返回给Connector

13)  Connector把HttpServletResponse对象返回给客户browser

# 103. 什么是URL：

URL，是英文Uniform Resource Locator 的缩写，意思是统一资源定位符，是标准的互联网行资源（图片，Javascript脚本文件等）的地址，是用于完整的描述Internet上网页和其他资源的地址的一种标识方法。简单的说，URL就是我们常说的网址.

# 104. 什么是Session机制

会话的跟踪，就是session机制，Session机制是一种服务器端的机制，服务器使用一种类似于散列表(HashTable)的结构来保存信息，主要用于在整个会话请求过程中共享数据。

**Session****机制的实现原理****：**

1)      当程序需要为某个客户端的请求创建session的时候，服务器首先检查这个客户端的请求里是否包含一个session标识，即称为sessionid

2)      如果包含sessionid则说明该客户端创建过session，服务器就会按照sessionid把这个session检索出来使用，如果**检索不到**，会创建一个新的session对象，并生成一个新的与此session关联的sessionid。

3)      如果客户端**请求不包含**sessionid，则为此客户端创建一个session并生成一个于此session相关联的sessionid

**Sessionid****传递的方式有两种****：**

**Cookie****方式**：服务器分配的sessionid将作为Cookie发送给浏览器，浏览器保存这个Cookie。当再次发送Http请求时，浏览器将Cookie随请求一起发送，服务器从请求对象中读取sessionid，再根据sessionid找到对应的HttpSession对象。

**URL****重写：**当cookie被人禁止的时候，我们就可以使用Url重写的方式把sessionid传递回服务器。就是把sessionid附加在URL路径的后面。附加的方式有两种：一种是作为URL路径的附加信息，一种是作为查询字符串附加在URL后面。

# 105. 四种会话跟踪技术

由于HTTP事务是无状态的，因此必须采取特殊措施是服务器在系列事务期间能继续确定和记住特定用户，这就是会话跟踪的概念。

实现此功能有四种实现技术：

1、  用隐藏表单域（<input type="hidden">）

​       非常适合不需要大量数据存储的会话应用。

2、URL重写

​       URL可以在后面附加参数，和服务器的请求一起发送，服务器根据相应的参数来判断是否为同一个客户端发送的请求，一般可以直接使用HTTP会话API执行URL重写，会自动附加相应的sessionid，该技术主要使用场景是客户端的浏览器禁用cookie导致session无法使用的情况。

3、Cookie技术

​        服务器通过cookie对象来保存session对象的id，用来保证客户端每次发送请求过来都会带上sessionid以保证服务器可以识别不同客户端的请求，是session机制实现的前提，如果用户禁用cookie就只能使用url重写来保证sessionid的传递了。

4、Session技术

​        根据session对象的sessionid（唯一标识）即可识别不同的客户端请求

# 106. B/S与C/S的联系与区别

C/S是Client/Server的缩写。服务器通常采用高性能的PC、工作站或小型机，并采用大型数据库系统，如Oracle、Sybase、MySQL或 SQL Server。客户端需要安装专用的客户端软件。

B/Ｓ是Brower/Server的缩写，客户机上只要安装一个浏览器（Browser），如Netscape Navigator或Internet Explorer，服务器安装Oracle、Sybase、MySQL或 SQL Server等数据库。在这种结构下，用户界面完全通过WWW浏览器实现，一部分业务逻辑在前端实现，但是主要业务逻辑在服务器端实现。浏览器通过Ｗeb Server同数据库进行数据交互。

# 107. http协议有几种提交方式

常用的有get()、post()两种

# 108. 什么是EL表达式

 EL全称 Expression Language ，是一种借鉴了JS和XPath的表达式语言，它定义了一系列隐含对象和操作符，开发人员能方便的访问页面的上下文， 以及不同作用域的对象，无需嵌入java代码，即使开发人员不懂java代码，也能轻松编写JSP程序。

​       EL表达式的语法：${表达式} 

# 109. EL隐式对象有哪些？

1）.作用域访问对象

​              pageScope           与页面作用域（page）中属性相关联的Map类

​              requestScope        与请求作用域（request）中属性相关联的Map类

​              sessionScope        与会话作用域（session）中属性相关联的Map类

​              applicationScope    与应用程序作用域（application）中属性相关联的Map类             

​       使用例子：request.setAttribute("Student",stu);当使用EL表达式访问某个属性值时候，应该指定查找范围，如${requestScope.Student}如果不指定查找范围，会按照page->request->session->application的顺序查找

​         注意：必须将对象保存在作用域中，才可以用EL表达式访问对象。

2）.参数访问对象

​         param      按照参数名称访问单一请求值的Map对象

​            paramValues 按照参数名称访问数组请求值的Map对象

​       参数访问对象是和页面输入参数有关的隐式对象，通过它们可以得到用户的请求参数：

​       比如登录页面表单有个表单项 <input type="text" name="userName">提交用户名，

​       在登录处理页面可以通过 ${param.userName} 访问它

3）.JSP隐式对象

​         pageContext  提供对页面信息的JSP内置对象的访问

# 110. 什么是JSTL

JSTL 全称 java server pages Standard Tag Library JSP标准标签库，它包含了我们在开发JSP页面经常用到的一组标准标签

# 111. JSTL迭代标签使用？

 <c:forEach var="变量名" items="被迭代的集合对象" varStatus="statu" begin="" end="" step="1">

​            </c:forEach>

​            其中：用 statu.index获得等同for的循环变量i一样。

var 是 对当前成员的引用

​                 beigin 表示开始位置 默认为0 。 可省略

​                 end  表示结束位置，可省略

​                 step表示步长，默认为1，可以省略

​            也可以指定循环次数来循环，

​            如：<c:forEach var ="变量名" varStatus="statu" begin="0" end="10" >

​                代码块   

​               </c:forEach>

​              通过begin 和end 指定循环次数

# 112. Filter 基本工作原理

 当在 web.xml 中配置了一个 Filter 来对某个 Servlet 程序进行拦截处理时，这个 Filter 就成了 Servlet 容器与该 Servlet 程序的通信线路上的一道关卡，该 Filter 可以对 Servlet 容器发送给 Servlet 程序的请求和 Servlet 程序回送给 Servlet 容器相应进行拦截，可以决定是否将请求继续传递给 Servlet 程序，以及对请求和相应信息是否进行修改。

在一个 web 应用程序中可以注册多个 Filter 程序，每个 Filter 程序都可以对一个或一组 Servlet 程序进行拦截。

若有多个 Filter 程序对某个 Servlet 程序的访问过程进行拦截，当针对该 Servlet 的访问请求到达时，web 容器将把多个 Filter 程序组合成一个 Filter 链(过滤器链)。Filter 链中各个 Filter 的拦截顺序与它们在应用程序的 web.xml 中映射的顺序一致。

# 113. JSP 和 servlet 有什么区别？

JSP 是 servlet 技术的扩展，本质上就是 servlet 的简易方式。servlet 和 JSP 最主要的不同点在于，servlet 的应用逻辑是在 Java 文件中，并且完全从表示层中的 html 里分离开来，而 JSP 的情况是 Java 和 html 可以组合成一个扩展名为 JSP 的文件。JSP 侧重于视图，servlet 主要用于控制逻辑。

# 114. JSP 有哪些内置对象？作用分别是什么？

JSP 有 9 大内置对象：

- request：封装客户端的请求，其中包含来自 get 或 post 请求的参数；
- response：封装服务器对客户端的响应；
- pageContext：通过该对象可以获取其他对象；
- session：封装用户会话的对象；
- application：封装服务器运行环境的对象；
- out：输出服务器响应的输出流对象；
- config：Web 应用的配置对象；
- page：JSP 页面本身（相当于 Java 程序中的 this）；
- exception：封装页面抛出异常的对象。

# 115. 说一下 JSP 的 4 种作用域？

- page：代表与一个页面相关的对象和属性。
- request：代表与客户端发出的一个请求相关的对象和属性。一个请求可能跨越多个页面，涉及多个 Web 组件；需要在页面显示的临时数据可以置于此作用域。
- session：代表与某个用户与服务器建立的一次会话相关的对象和属性。跟某个用户相关的数据应该放在用户自己的 session 中。
- application：代表与整个 Web 应用程序相关的对象和属性，它实质上是跨越整个 Web 应用程序，包括多个页面、请求和会话的一个全局作用域。

# 116. session 和 cookie 有什么区别？

- 存储位置不同：session 存储在服务器端；cookie 存储在浏览器端。
- 安全性不同：cookie 安全性一般，在浏览器存储，可以被伪造和修改。
- 容量和个数限制：cookie 有容量限制，每个站点下的 cookie 也有个数限制。
- 存储的多样性：session 可以存储在 Redis 中、数据库中、应用程序中；而 cookie 只能存储在浏览器中。

# 117. 说一下 session 的工作原理？

session 的工作原理是客户端登录完成之后，服务器会创建对应的 session，session 创建完之后，会把 session 的 id 发送给客户端，客户端再存储到浏览器中。这样客户端每次访问服务器时，都会带着 sessionid，服务器拿到 sessionid 之后，在内存找到与之对应的 session 这样就可以正常工作了。

# 118. 如果客户端禁止 cookie 能实现 session 还能用吗？

可以用，session 只是依赖 cookie 存储 sessionid，如果 cookie 被禁用了，可以使用 url 中添加 sessionid 的方式保证 session 能正常使用。

# 119. spring mvc 和 struts 的区别是什么？

- 拦截级别：struts2 是类级别的拦截；spring mvc 是方法级别的拦截。
- 数据独立性：spring mvc 的方法之间基本上独立的，独享 request 和 response 数据，请求数据通过参数获取，处理结果通过 ModelMap 交回给框架，方法之间不共享变量；而 struts2 虽然方法之间也是独立的，但其所有 action 变量是共享的，这不会影响程序运行，却给我们编码和读程序时带来了一定的麻烦。
- 拦截机制：struts2 有以自己的 interceptor 机制，spring mvc 用的是独立的 aop 方式，这样导致struts2 的配置文件量比 spring mvc 大。
- 对 ajax 的支持：spring mvc 集成了ajax，所有 ajax 使用很方便，只需要一个注解 @ResponseBody 就可以实现了；而 struts2 一般需要安装插件或者自己写代码才行。

# 120. 如何避免 SQL 注入？

- 使用预处理 PreparedStatement。
- 使用正则表达式过滤掉字符中的特殊字符。

# 121. 什么是 XSS 攻击，如何避免？

XSS 攻击：即跨站脚本攻击，它是 Web 程序中常见的漏洞。原理是攻击者往 Web 页面里插入恶意的脚本代码（css 代码、Javascript 代码等），当用户浏览该页面时，嵌入其中的脚本代码会被执行，从而达到恶意攻击用户的目的，如盗取用户 cookie、破坏页面结构、重定向到其他网站等。

预防 XSS 的核心是必须对输入的数据做过滤处理。

# 122. 什么是 CSRF 攻击，如何避免？

CSRF：Cross-Site Request Forgery（中文：跨站请求伪造），可以理解为攻击者盗用了你的身份，以你的名义发送恶意请求，比如：以你名义发送邮件、发消息、购买商品，虚拟货币转账等。

防御手段：

- 验证请求来源地址；
- 关键操作添加验证码；
- 在请求地址添加 token 并验证。

# 123. css中import与link的区别

- 在页面上使用需要加载站点css样式文件

  - link 链接

    ```html
    <link rel="stylesheet" type="text/css" href="main.css" />
    ```

  - @import 导入

    ```html
    <style>
    @import url("main.css") ;
    </style>
    ```

# 124. css定位有哪四种

定位有四种

- static定位，默认
- absolute绝对定位。【脱标】相对于非static定位容器而言,如果没有则相对（页面）定位
- fixed 固定定位 。【脱标】
- relative相对定位。 【脱标】，相对于自己

# 125. css的样式怎么设置

- 三种范围:
  - 行内样式 ，sytle属性
  - 页面样式 , `<style>`标签实现的
  - 站点样式，import或link进来
- 常用 三种选择器方式
  - html选择器
  - id选择器
  - class选择器

# 126. 有哪些选择器

- html选择器
- id选择器
- class选择器
- 过滤选择器
- 表单选择器
- 复合选择器
- 属性选择器

# 127. body下div怎么设置100%

```html
<style type="text/css">
    #mainDiv {
        background-color: Green;
        height: 100%;
        width: 100%;
        position: absolute
    }

    .container {
        border: 1px solid red;
        width: 200px;
        height: 200px;
        position: relative;
    }
</style>

<div class="container">
    <div id="mainDiv">
    </div>
</div>
```

# 
