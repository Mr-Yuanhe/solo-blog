title: CentOS 7 安装MySQL 5.7
date: '2019-09-16 14:50:52'
updated: '2019-09-16 14:50:52'
tags: [Linux]
permalink: /articles/2019/09/16/1568611730681.html
---
- 如果之前安装了MySQL，或者没有卸载干净的。要先卸载或清理一下。[CentOS 7 卸载MySQL 5.7](http://106.54.54.131/articles/2019/09/16/1568616652854.html)
1. 进入/usr/local创建一个mysql目录

```
cd /usr/local                                                                                           
mkdir mysql
```
2. 进入mysql目录并下载YUM源

```
cd ./mysql
wget http://dev.mysql.com/get/mysql57-community-release-el7-8.noarch.rpm
```

3. 安装 MySQL源
```
yum localinstall mysql57-community-release-el7-8.noarch.rpm
```
4. 检查 MySQL 源是否安装成功
```
yum repolist enabled | grep "mysql.*-community.*"
```
5. 安装 MySQL
```
yum -y install mysql-community-server
```
6. 查看MySQL版本
- 若出现如下信息表示安装成功
```
[root@yh ~]# mysql -V
mysql Ver 14.14 Distrib 5.7.27, for Linux (x86_64) using EditLine wrapper
```
7. 启动 MySQL 服务

```
systemctl start mysqld
```
8. 查看 MySQL 的启动状态
```
systemctl status mysqld
```
- 若出现如下信息表示启动成功
![image.png](https://img.hacpai.com/file/2019/09/image-e137cbd5.png)
9. 设置 MySQL 服务开机自启动
```
systemctl enable mysqld
```
10. 查看初始密码
- MySQL 安装完成之后，在 /var/log/mysqld.log 文件中给 root 生成了一个默认密码。查看 /var/log/mysqld.log 文件，获取并记录 root 用户的初始密码
```
grep 'temporary password' /var/log/mysqld.log
```
```
[root@yh ~]# grep 'temporary password' /var/log/mysqld.log
2019-09-12T21:25:19.393380Z 1 [Note] A temporary password is generated for root@localhost: Ih&i0lRk9pdI  <- 初始密码
```
- 如果找不到初始密码
> 原因：原来安装过的 MySQL 有残留的数据  
解决：[CentOS 7 卸载MySQL 5.7](http://106.54.54.131/articles/2019/09/16/1568616652854.html)

**删除完成后，重启 mysqld 服务**

```
systemctl restart mysqld
```
**重新找回初始密码**
```
grep 'temporary password' /var/log/mysqld.log
```
11. 重置密码

**登录**
```
mysql -uroot -p你找到的密码
```
**重置**
```
ALTER USER 'root'@'localhost' IDENTIFIED BY '你的新密码';
```

>新密码长度为8至30个字符，必须同时包含大小写英文字母、数字和特殊符号。特殊符号可以是 ( ) `  ~ ! @ # $ % ^ & * - + = | { } [ ] : ; ‘ < > , . ? /

12. 远程访问 MySQL

**授予用户root权限**
```
grant all on *.* to 'root'@'%'IDENTIFIED BY '你的密码';
```
**刷新**
```
flush privileges;
```
**接下来你就能远程操作数据库了**
