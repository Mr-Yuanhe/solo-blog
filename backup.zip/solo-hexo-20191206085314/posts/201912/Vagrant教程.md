title: Vagrant教程
date: '2019-12-04 19:50:39'
updated: '2019-12-04 19:50:56'
tags: [Linux, 安装教程]
permalink: /articles/2019/12/04/1575460239079.html
---
# 1. Vagrant 简介概述  
  
- Vagrant 是一个用来**构建和管理虚拟机环境**的工具，为了方便的实现虚拟化环境而设计的，使用 Ruby 开发，  
  
  提供了一个可配置、轻量级的便携式虚拟开发环境。  
  
- Vagrant 运行需要**依赖**某项具体的**虚拟化技术**，最常见的有**VirtualBox以及VMWare**两款，早期，Vagrant只  
  
  支持VirtualBox，后来才加入了VMWare的支持。  
  
# 2. 准备工作，安装Virtual Box  
  
下载地址：<https://www.virtualbox.org/wiki/Downloads>  
  
安装过程很简单，傻瓜式的一步一步点下去。  
  
# 3. 准备工作，安装Vagrant  
  
下载地址：<https://www.vagrantup.com/downloads.html>  
  
安装过程依旧没什么难的，跟着提示一步一步next。  
  
# 4. 查看和下载box  
  
- 在线查找需要的box  
  
  官方网址：<https://app.vagrantup.com/boxes/search>  
  
# 5. 常用命令  
  
## 5.1.  box命令  
  
- 列出本地环境中所有的box  
  
  ```shell  
  vagrant box list  
  ```  
  
- 添加box到本地vagrant环境  
  
  ```shell  
  vagrant box add box-name  box-url  
  # 挂载自己的box，centos/7是box名称：自定义  
  vagrant box add centos7 F:\course\java134\soft\vagrant\CentOS-7-x86_64-Vagrant-1905_01.VirtualBox.box  
  ```  
  
- 更新本地环境中指定的box  
  
  ```shell  
  vagrant box update box-name  
  ```  
  
- 删除本地环境中指定的box  
  
  ```shell  
  vagrant box remove box-name  
  ```  
  
- 打包本地环境中指定的box  
  
  ```shell  
  vagrant package   
  ```  
  
  
## 5.2.  基本命令  
  
- 查看vagrant版本  
  
  ```shell  
  vagrant -v   
  ```  
  
- 在当前文件夹中创建初始化文件Vagrantfile  
  
  ```shell  
  vagrant init [box-name]  
  ```  
  
- 在初始化完的文件夹内启动虚拟机  
  
  ```shell  
  vagrant up  
  ```  
  
- 登录启动的虚拟机  
  
  ```shell  
  vagrant ssh  
  ```  
  
- 挂起启动的虚拟机  
  
  ```shell  
  vagrant suspend  
  ```  
  
- 加载虚拟机  
  
  ```shell  
  vagrant reload  
  ```  
  
- 关闭虚拟机  
  
  ```shell  
  vagrant halt  
  ```  
  
- 查找虚拟机的运行状态  
  
  ```shell  
  vagrant status  
  ```  
  
- 销毁当前虚拟机  
  
  ```shell  
  vagrant destroy  
  ```  
  
- 唤醒虚拟机  
  
  ```shell  
  vagrant resume  
  ```  
  
  
# 6. 安装centos7系统  
  
Vagrantfile  
  
```java  
Vagrant.configure("2") do |config|  
  
 # 定义redis服务器  
  config.vm.define :redis do |redis|  
      # 使用基于virtualbox虚拟化  
    redis.vm.provider "virtualbox" do |v|  
          v.customize ["modifyvm", :id, "--name", "redis", "--memory", "512"]  
    end  
    # 使用box，必须先挂载好  
    redis.vm.box = "centos7"  
    # 主机名称  
    redis.vm.hostname = "redis"  
    # 公有网络  
    redis.vm.network :public_network, ip: "192.168.67.2"  
    # 私有网络  
    redis.vm.network :private_network, ip: "11.11.11.2"  
  end  
end    
```  
  
- 操作  
  
```shell  
vagrant up # 安装虚拟机  
vagarnt ssh # 连接虚拟机，默认vagrant用户   
su # 切换root用户，密码为vagrant  
vi /etc/ssh/sshd_config # 把密码登录开放  
# vi命名==》编辑文本  
# 三个模式  
    # 命令模式 esc  
    # 末行模式 :wq（保存退出） :q!(不保存退出)  
    # 输入模式 a  o  
# 启用密码登录  
PasswordAuthentication yes  
# 重启  
systemctl restart sshd      
# 通过xshell连接上          
```  
  
# 7. 打包自己的box, 加载自己打包好的box  
  
```shell  
# 先打包  --base 要打包的虚拟机名称 --output 打包后的包名  
vagrant package   
# 挂载  
vagrant box add --name centos /xxx/mycentos.box  
```  
  
加载自己打包好的box,在vagrantfile中加多两行，否则会报一个权限问题  
  
```shell  
Vagrant.configure("2") do |config|  
    
  # 定义redis服务器  
  config.vm.define :redis do |redis|  
      # 使用基于virtualbox虚拟化  
    redis.vm.provider "virtualbox" do |v|  
          v.customize ["modifyvm", :id, "--name", "redis", "--memory", "512"]  
    end  
    # 使用box，必须先挂载好  
    redis.vm.box = "centos"  
    # 主机名称  
    redis.vm.hostname = "redis"  
    # 公有网络  
    redis.vm.network :public_network, ip: "192.168.68.2"  
    # 私有网络  
    redis.vm.network :private_network, ip: "11.11.11.2"  
    # 加上下面两行  
    redis.ssh.password = "vagrant"  
    redis.ssh.insert_key = false  
  end  
end  
```
