title: vue文件常用模板
date: '2024-10-08 19:22:59'
updated: '2024-10-08 19:23:13'
tags: [vue]
permalink: /articles/2024/10/08/1728386579764.html
---
```
<template>
  <div>

  </div>
</template>

<script>
export default {
  components: {
  },
  data() {
    return {
    };
  },
  methods: {
    
  },
  mounted() {
    
  },
  watch: {
   
  }
}
</script>

<style scoped>

</style>
```

