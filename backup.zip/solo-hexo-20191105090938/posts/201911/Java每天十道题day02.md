title: Java每天十道题 - day02
date: '2019-11-04 19:30:06'
updated: '2019-11-05 08:37:41'
tags: [Java-每天十道题]
permalink: /articles/2019/11/04/1572867006098.html
---
## 1.maven的作用是什么

```
maven是一个项目构建和管理的工具，提供了帮助管理 构建、文档、报告、依赖、scms、发布、分发的方法。可以方便的编译代码、进行依赖管理、管理二进制库等等。

maven的好处在于可以将项目过程规范化、自动化、高效化以及强大的可扩展性

利用maven自身及其插件还可以获得代码检查报告、单元测试覆盖率、实现持续集成等等。
```



## 2.pom.xml中有哪些标签.作用是什么

```
project
	groupid 组编号 
	artifactid 项目名称
	version 项目版本
	packaging 压缩的类型
	properties  当前项目依赖的jar包的版本号，用于下面的依赖
	dependencies
	   dependency
			groupid 组编号 
			artifactid 项目名称
			version 项目版本
			scope 生命周期
			exclusions  依赖当中要排除的jar包
	build
	    plugins 插件集合
	        plugin 插件
	            groupid 组编号
	            artifactid 项目名称
	            version 项目版本
	            configuration 配置
```


## 3.启动一个web项目有哪些方式

```
1.tomcat
2.maven的插件
3.打成war包放webapps中
```

## 4.dns、ip、端口的作用

```
dns:域名解析服务  主要用于域名与 IP 地址的相互转换。一个ip可以对应多个ip，一个域名只能对应一个ip

ip:网际协议，在网络上代表一个唯一的主机

端口:代表主机运行哪个程序0~65535
```

## 5.java虚拟机的内存机制


[参考](http://www.yuanheweb.com/articles/2019/10/17/1571300060790.html)



## 6.tcp与udp的异同

tcp 和 udp 是 OSI 模型中的运输层中的协议。tcp 提供可靠的通信传输，而 udp 则常被用于让广播和细节控制交给应用的通信传输。

两者的区别大致如下：

* tcp 面向连接，udp 面向非连接即发送数据前不需要建立链接；
* tcp 提供可靠的服务（数据传输），udp 无法保证；
* tcp 面向字节流，udp 面向报文；
* tcp 数据传输慢，udp 数据传输快；

## 7.引入css的三种方式

- 行内 style=""

- 内部 style标签

- 外部 
	- import页面加载后加载css
	- link页面加载时加载css  用这个好

## 8.session

- Session对象存储特定用户会话所需的属性及配置信息。

- Session保存在服务器上(内存或硬盘)，客户端只保存sessionid

- 每个来访者对应一个Session对象，所有该客户的状态信息都保存在这个Session对象里。

- Session对象是在客户端第一次请求服务器的时候创建的。

- Session的生命周期默认是30分钟

- Session也是一种key-value的属性对，通过getAttribute(Stringkey)和setAttribute(String key，Objectvalue)方法读写客户状态信息。

- Servlet里通过request.getSession()方法获取该客户的Session。

```java
HttpSession session = request.getSession();
//设置属性
session.setAttribute("name","tom");
//读取属性
session.getAttribute("name");
//移除属性
session.removeAttribute("name");
//设置有效期，单位为秒，-1代表永不过期
session.setMaxInactiveInterval(1000);
//使其失效
session.invalidate();
```



## 9.jsp的9大内置对象

```
request 请求对象 --> 作用域 Request  
response 响应对象 --> 作用域 Page  
pageContext 页面上下文对象 --> 作用域 Page  
session 会话对象 --> 作用域 Session  
application 应用程序对象 --> 作用域 Application  
out 输出对象 --> 作用域 Page  
config 配置对象（主要取得服务器的配置文件） --> 作用域 Page  
page 页面对象 --> 作用域 Page  
exception 例外对象 --> 作用域 page
```

## 10.Oracle的五个组函数

1）AVG(arg)函数：对分组数据做平均值运算。

2）SUM(arg)函数：对分组数据求和。

3）COUNT(1) 函数：返回一个表中的行数。

4）MIN(arg)函数：求分组中最小数据。

5）MAX(arg)函数：求分组中最大数据。

