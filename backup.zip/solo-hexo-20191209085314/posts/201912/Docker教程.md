title: Docker教程
date: '2019-12-04 19:52:37'
updated: '2019-12-04 19:54:26'
tags: [安装教程, Linux]
permalink: /articles/2019/12/04/1575460357179.html
---
# Docker  
  
# 1. 简介  
  
- **Docker**是一个开源的应用**容器**引擎  
  
- 镜像 : 拉软件  
- 容器 : 装软件   
  
# 2. 安装Docker  
  
## 2.1. 在linux虚拟机上安装docker  
  
步骤：  
  
```shell  
1、安装docker  
yum install docker  
2、输入y确认安装  
3、启动docker  
systemctl start docker  
docker -v  
4、开机启动docker  
systemctl enable docker  
5、停止docker  
systemctl stop docker  
```  
  
# 3. 常用命令  
  
## 3.1. 镜像命令  
  
| 操作 | 命令                                            | 说明                                                     |  
| ---- | ----------------------------------------------- | -------------------------------------------------------- |  
| 检索 | docker  search 关键字  eg：docker  search redis | 我们经常去docker  hub上检索镜像的详细信息，如镜像的TAG。 |  
| 拉取 | docker pull 镜像名:tag                          | :tag是可选的，tag表示标签，多为软件的版本，默认是latest  |  
| 列表 | docker images                                   | 查看所有本地镜像                                         |  
| 删除 | docker rmi image-id                             | 删除指定的本地镜像                                       |  
  
## 3.2. 容器命令  
  
```shell  
1、根据镜像启动容器  
    docker run --name mytomcat -d tomcat:latest  
2、docker ps   
    查看运行中的容器  
3、查看所有的容器  
    docker ps -a  
4、启动容器  
    docker start 容器id      
5、 停止运行中的容器  
    docker stop  容器的id  
8、删除一个容器  
     docker rm -f 容器id  
9、查看容器的日志  
    docker logs 容器id  
10、进入容器  
    docker exec -it 容器id /bin/bash  
```  
  
## 3.3. docker添加国内镜像  
  
- 第一步：更换镜像地址  
  
在服务器本机的/etc/docker/下新建daemon.json,并输入以下内容：如果需要更换不同的镜像地址，直接替换掉 http://hub-mirror.c.163.com 即可  
  
- vi /etc/docker/daemon.json  
  
```json  
{
"registry-mirrors": ["http://hub-mirror.c.163.com"]
}
```  
  
- 第二步：当我们新增了daemon.json文件后必须重载docker才能生效  
  
  1、systemctl daemon-reload   //载入daemon.json  
  
  2、systemctl restart docker   //重启docker  
  
- 第三步：使用docker info查看信息，红框内即为更换后的镜像地址  
  
# 4. 常用安装   
  
搜索地址 :  https://hub.docker.com/  
  
## 4.1. mysql  
  
```shell  
docker pull mysql:5.7.25   
docker run --restart=always -d -p 3306:3306  --name mysql5 -e   MYSQL_ROOT_PASSWORD=root mysql:5.7.25  
```  
  
# 5.配置私服，拉取镜像  
  
## 5.1.  拉取镜像  
  
```shell  
# 查看私服的镜像  
curl http://192.168.100.205:5000/v2/_catalog  
  
# 设置私服地址  
vi /etc/docker/daemon.json文件：  
    {"insecure-registries":["192.168.100.205:5000"]}  
      
# 重启docker      
systemctl restart docker  
  
# 拉取镜像  
docker pull 192.168.100.205:5000/mysql  
```  
  
## 5.2. 示例  
  
### 5.2.1. mysql安装   
  
```shell  
# 摘取镜像  
docker pull 192.168.100.205:5000/mysql  
# 安装容器  
docker run --restart=always -d -p 3306:3306  --name mysql5 -e   MYSQL_ROOT_PASSWORD=root 192.168.100.205:5000/mysql  
# --restart=always  开机启动  
# -d 后台启机  
# -p 端口映射  
# -name 容器名称  
# -e 参数  
# 192.168.100.205:5000/mysql 镜像  
```  
  
### 5.2.2. tomcat安装   
  
```shell  
# 拉下来的是镜像  
docker pull 192.168.100.205:5000/tomcat  
# 安装容器  
docker run -d -p 9090:8080 --restart=always --name tomcat8 192.168.100.205:5000/tomcat  
# 创建多级目录   
mkdir -p /root/docker/tomcat/webapps  
docker cp [容器id]:/usr/local/tomcat/webapps /root/docker/tomcat/  
# 删除    
docker rm -f 【容器id】    
docker run --name tomcat8.5 --restart=always --privileged=true -v /root/docker/tomcat/webapps/:/usr/local/tomcat/webapps -d -p 9090:8080 192.168.100.205:5000/tomcat  
```  
  
### 5.2.3. redis安装   
  
```shell  
docker pull 192.168.100.205:5000/redis  
mkdir -p /root/docker/redis  
cd /root/docker/redis        
mkdir data conf  
wget https://raw.githubusercontent.com/antirez/redis/5.0.3/redis.conf -O conf/redis.conf  
vi conf/redis.conf  
# 修改配置  
# bind 127.0.0.1  #所有IP都可以访问  
protected-mode no # 关闭保护模式  
docker run  -p 6379:6379 --restart=always -v /root/docker/redis/data:/data -v /root/docker/redis/conf/redis.conf:/usr/local/etc/redis/redis.conf --privileged=true  --name redis -d f7302e4ab3a8 redis-server /usr/local/etc/redis/redis.conf  
```
