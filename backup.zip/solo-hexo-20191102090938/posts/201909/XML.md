title: XML
date: '2019-09-26 23:28:17'
updated: '2019-09-26 23:28:17'
tags: [HTML]
permalink: /articles/2019/09/26/1569511697360.html
---
# 1、xml

- 什么是xml

```
XML 指可扩展标记语言（EXtensible Markup Language） 
XML 是一种标记语言，很类似 HTML 
XML 的设计宗旨是传输数据，而非显示数据 
XML 标签没有被预定义。您需要自行定义标签。 
XML 被设计为具有自我描述性。 
XML 是 W3C 的推荐标准 
```

- XML 与 HTML 之间的差异

```
XML 不是 HTML 的替代。
XML 和 HTML 为不同的目的而设计：
XML 被设计为传输和存储数据，其焦点是数据的内容。
HTML 被设计用来显示数据，其焦点是数据的外观。
HTML 旨在显示信息，而 XML 旨在传输信息。
```

- 总结

```
xml是主要用来做配置文件的，其次是传输数据
html是用来显示数据的

json是用来传输数据的，也可以用来做js方法的配置
```

- 语法

```
XML 标签对大小写敏感
XML 必须正确地嵌套
XML 文档必须有根元素
XML 的属性值须加引号
在 XML 中，空格会被保留
```

- 自定义一个xml文件（student.xml）

```xml
<student>
	<id>1001</id>
  	<name>张三</name>
  	<age>18</age>
  	<address>南京卡子门</address>
</studnet>
```

- student.json

```
{
  id:1001,
  name:"张三"
  ...
}
```

- 开发xml文件的开发工具

```
idea
eclipse
xmlspy（后期可以开发dtd和scheam文件），解压
```

- 表示多个学生students.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<students>
	<student>
		<id>1002</id>
		<name>张三</name>
		<age>18</age>
		<address>南京</address>
	</student>
	
	<student>
		<id>1003</id>
		<name>李四</name>
		<age>18</age>
		<address>南京</address>
	</student>

	<student>
		<id>1004</id>
		<name>王五</name>
		<age>18</age>
		<gender>男</gender>
		<address>南京</address>
	</student>
</students>
```

- xml文件需要申明

```
<?xml version="1.0" encoding="UTF-8"?>
```

# 2、xml验证

- xml规则

- 验证的形式有两种

```
dtd
schema
```

- 验证介绍

```
拥有正确语法的 XML 被称为“形式良好”的 XML。
通过验证的 XML 是“合法”的 XML。
```

- dtd验证

```
形式一：外部dtd文件验证（需要创建一个dtd文件，验证的xml文件需要引入dtd文件）
形式二：当前xml文件中验证（把验证代码写在当前的xml文件中）
```

- 注意点

```
1、dtd文件本省遵循xml声明
2、dtd文件中的标签是预定义好的
```

- stu.dtd

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!ELEMENT student (id,name,age,gender,address)>
<!ELEMENT id      (#PCDATA)>
<!ELEMENT name    (#PCDATA)>
<!ELEMENT age 	(#PCDATA)>
<!ELEMENT gender    (#PCDATA)>
<!ELEMENT address    (#PCDATA)>
```

- stu.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE student SYSTEM "stu.dtd">
<student>
	<id>1001</id>
	<name>李四</name>
	<age>18</age>
	<gender>女</gender>
	<address>鼓楼</address>
</student>
```

- dtd文件中的限定

```
声明只出现一次的元素
<!ELEMENT 元素名称 (子元素名称)>

声明最少出现一次的元素
<!ELEMENT 元素名称 (子元素名称+)>

声明出现零次或多次的元素
<!ELEMENT 元素名称 (子元素名称*)>

声明出现零次或一次的元素
<!ELEMENT 元素名称 (子元素名称?)>
```

- 写一个可以传输多个学生的dtd文件（students.dtd）

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!ELEMENT students (student+)>
<!ELEMENT student (id,name,age,gender,address)>
<!ELEMENT id      (#PCDATA)>
<!ELEMENT name    (#PCDATA)>
<!ELEMENT age 	(#PCDATA)>
<!ELEMENT gender    (#PCDATA)>
<!ELEMENT address    (#PCDATA)>
```

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE students SYSTEM "students.dtd">
<students>
  <student>
    <id>1001</id>
    <name>张三1</name>
    <age>18</age>
    <gender>男</gender>
    <address>南京</address>
  </student>

  <student>
    <id>1003</id>
    <name>李四</name>
    <age>18</age>
    <gender>男</gender>
    <address>南京</address>
  </student>

  <student>
    <id>1004</id>
    <name>王五</name>
    <age>18</age>
    <gender>男</gender>
    <address>南京</address>
  </student>
</students>
```

- dtd的当前xml验证

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE students [
	<!ELEMENT students (student+)>
	<!ELEMENT student (id,name,age,gender,address)>
	<!ELEMENT id      (#PCDATA)>
	<!ELEMENT name    (#PCDATA)>
	<!ELEMENT age 	(#PCDATA)>
	<!ELEMENT gender    (#PCDATA)>
	<!ELEMENT address    (#PCDATA)>
]> 

<students>
	<student>
		<id>1001</id>
		<name>张三1</name>
		<age>18</age>
		<gender>男</gender>
		<address>南京</address>
	</student>
	
	<student>
		<id>1003</id>
		<name>李四</name>
		<age>18</age>
		<gender>男</gender>
		<address>南京</address>
	</student>
</students>
```

# 3、schema验证

- 什么是schema验证

```
XML Schema 是基于 XML 的 DTD 替代者。
XML Schema 描述 XML 文档的结构。
XML Schema 语言也称作 XML Schema 定义（XML Schema Definition，XSD）。
Schema文件的后缀名为xsd
XML Schema 比 DTD 更加强大
```

```
XML Schema 可针对未来的需求进行扩展 
XML Schema 更完善，功能更强大 
XML Schema 基于 XML 编写 

XML Schema 支持数据类型（只学习它）
XML Schema 支持命名空间 
```

- 创建一个stu.xsd文件

```

```

- 元素的常用类型

```
xs:string 
xs:decimal 
xs:integer 
xs:boolean 
xs:date 
xs:time 
```

- 元素的重现次数

```
<xs:element name="student" maxOccurs="unbounded" minOccurs="1">
```

- schema中的限定
- 限定的语法

```
<xs:element name="car">

<xs:simpleType>
  <xs:restriction base="xs:string">
    <xs:enumeration value="Audi"/>
    <xs:enumeration value="Golf"/>
    <xs:enumeration value="BMW"/>
  </xs:restriction>
</xs:simpleType>

</xs:element> 
```

```xml
<car>Audi/Golf/BMW</car>
```

- 对年龄的限定

```xml
<xs:element name="age">

<xs:simpleType>
  <xs:restriction base="xs:integer">
    <xs:minInclusive value="0"/>
    <xs:maxInclusive value="120"/>
  </xs:restriction>
</xs:simpleType>

</xs:element> 
```

- student.xsd

```xml
<?xml version="1.0" encoding="UTF-8"?>
<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema"
           targetNamespace="http://www.w3school.com.cn"
           xmlns="http://www.w3school.com.cn"
           elementFormDefault="qualified">

<xs:element name="students">
  <xs:complexType>
    <xs:sequence>
      <xs:element name="student" maxOccurs="unbounded" minOccurs="1">
        <xs:complexType>
          <xs:sequence>
            <xs:element name="id" type="xs:integer"/>
            <xs:element name="name" type="xs:string"/>

            <xs:element name="age">
              <xs:simpleType>
                <xs:restriction base="xs:integer">
                  <xs:minInclusive value="0"/>
                  <xs:maxInclusive value="120"/>
                </xs:restriction>
              </xs:simpleType>
            </xs:element> 

            <xs:element name="gender">
              <xs:simpleType>
                <xs:restriction base="xs:string">
                  <xs:pattern value="[男|女]"/>
                </xs:restriction>
              </xs:simpleType>
            </xs:element>

            <xs:element name="address" type="xs:string"/>
          </xs:sequence>
        </xs:complexType>
      </xs:element>
    </xs:sequence>
  </xs:complexType>
</xs:element>

</xs:schema>
```

```xml
<?xml version="1.0" encoding="UTF-8"?>
<students xmlns="http://www.w3school.com.cn" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.w3school.com.cn stu.xsd">

  <student>
    <id>1001</id>
    <name>张三</name>
    <age>18</age>
    <gender>男</gender>
    <address>南京</address>
  </student>
  <student>
    <id>1002</id>
    <name>李四</name>
    <age>18</age>
    <gender>女</gender>
    <address>南京</address>
  </student>
</students>

```

# 4、xml解析

- users.xml

```xml
<users>
  <user>
    <username>admin</username>
    <password>123456</username>
  </user>
  <user>
    <username>root</username>
    <password>1234</username>
  </user>
  <user>
    <username>tiger</username>
    <password>1234</username>
  </user>
</users>
```

- xml一般用来做配置文件

```
1、用java代码来解析xml配置文件，读取里面的配置项
2、一般配置文件放在java项目的src目录
```

- xml解析的方式

```
dom		jdk自带
sax		引入jar
jdom	引入jar
dom4j 	引入jar（dom for java）
```

- 只学习dom4j解析

```
dom4j-1.6.1.jar
jaxen-1.1-beta-7.jar
```

~~~java
package net.wanho.test;

import java.io.InputStream;
import java.util.List;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class XML_Test {

  public static void main(String[] args) throws Exception {
    SAXReader reader =new SAXReader();
    //1、把users.xml文件变为输入流
    //反射： XML_Test.class，反射的结果是一个对象（XML_Test字节码对象）
    //getClassLoader()，获取类加载器，就是bin目录对象；字节码被编译到bin目录
    //getResourceAsStream(filename),读取类加载器中的文件
    InputStream is = XML_Test.class.getClassLoader().getResourceAsStream("users.xml");
    //2、再把文件流读取成document对象
    Document document =	reader.read(is);
    System.out.println(document);

    //3、解析document中需要获取的数据
    //获取根元素
    Element element = document.getRootElement();
    //获取根元素名
    System.out.println(element.getName());
    //获取元素中的子元素们
    List<Element> users = element.elements();
    for (int i = 0; i < users.size(); i++) {
      Element user = users.get(i);
      System.out.println(user.getName());
      
      //获取user中的每一个属性
      List<Attribute> sttrs = user.attributes();

      //获取user中的每一个元素
      List<Element> eles =user.elements();
      for (int j = 0; j < eles.size(); j++) {
        Element ele = eles.get(j);
        System.out.println(ele.getName()+":"+ele.getText());
      }
    }
  }
}# 4、xml

- 什么是xml

```
XML 指可扩展标记语言（EXtensible Markup Language） 
XML 是一种标记语言，很类似 HTML 
XML 的设计宗旨是传输数据，而非显示数据 
XML 标签没有被预定义。您需要自行定义标签。 
XML 被设计为具有自我描述性。 
XML 是 W3C 的推荐标准 
```

- XML 与 HTML 之间的差异

```
XML 不是 HTML 的替代。
XML 和 HTML 为不同的目的而设计：
XML 被设计为传输和存储数据，其焦点是数据的内容。
HTML 被设计用来显示数据，其焦点是数据的外观。
HTML 旨在显示信息，而 XML 旨在传输信息。
```

- 总结

```
xml是主要用来做配置文件的，其次是传输数据
html是用来显示数据的

json是用来传输数据的，也可以用来做js方法的配置
```

- 语法

```
XML 标签对大小写敏感
XML 必须正确地嵌套
XML 文档必须有根元素
XML 的属性值须加引号
在 XML 中，空格会被保留
```

- 自定义一个xml文件（student.xml）

```xml
<student>
	<id>1001</id>
  	<name>张三</name>
  	<age>18</age>
  	<address>南京卡子门</address>
</studnet>
```

- student.json

```
{
  id:1001,
  name:"张三"
  ...
}
```

- 开发xml文件的开发工具

```
idea
eclipse
xmlspy（后期可以开发dtd和scheam文件），解压
```

- 表示多个学生students.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<students>
	<student>
		<id>1002</id>
		<name>张三</name>
		<age>18</age>
		<address>南京</address>
	</student>
	
	<student>
		<id>1003</id>
		<name>李四</name>
		<age>18</age>
		<address>南京</address>
	</student>

	<student>
		<id>1004</id>
		<name>王五</name>
		<age>18</age>
		<gender>男</gender>
		<address>南京</address>
	</student>
</students>
```

- xml文件需要申明

```
<?xml version="1.0" encoding="UTF-8"?>
```

# 5、xml验证

- xml规则


- 验证的形式有两种

```
dtd
schema
```

- 验证介绍

```
拥有正确语法的 XML 被称为“形式良好”的 XML。
通过验证的 XML 是“合法”的 XML。
```

- dtd验证

```
形式一：外部dtd文件验证（需要创建一个dtd文件，验证的xml文件需要引入dtd文件）
形式二：当前xml文件中验证（把验证代码写在当前的xml文件中）
```

- 注意点

```
1、dtd文件本省遵循xml声明
2、dtd文件中的标签是预定义好的
```

- stu.dtd

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!ELEMENT student (id,name,age,gender,address)>
<!ELEMENT id      (#PCDATA)>
<!ELEMENT name    (#PCDATA)>
<!ELEMENT age 	(#PCDATA)>
<!ELEMENT gender    (#PCDATA)>
<!ELEMENT address    (#PCDATA)>
```

- stu.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE student SYSTEM "stu.dtd">
<student>
	<id>1001</id>
	<name>李四</name>
	<age>18</age>
	<gender>女</gender>
	<address>鼓楼</address>
</student>
```

- dtd文件中的限定

```
声明只出现一次的元素
<!ELEMENT 元素名称 (子元素名称)>

声明最少出现一次的元素
<!ELEMENT 元素名称 (子元素名称+)>

声明出现零次或多次的元素
<!ELEMENT 元素名称 (子元素名称*)>

声明出现零次或一次的元素
<!ELEMENT 元素名称 (子元素名称?)>
```

- 写一个可以传输多个学生的dtd文件（students.dtd）

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!ELEMENT students (student+)>
<!ELEMENT student (id,name,age,gender,address)>
<!ELEMENT id      (#PCDATA)>
<!ELEMENT name    (#PCDATA)>
<!ELEMENT age 	(#PCDATA)>
<!ELEMENT gender    (#PCDATA)>
<!ELEMENT address    (#PCDATA)>
```

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE students SYSTEM "students.dtd">
<students>
  <student>
    <id>1001</id>
    <name>张三1</name>
    <age>18</age>
    <gender>男</gender>
    <address>南京</address>
  </student>

  <student>
    <id>1003</id>
    <name>李四</name>
    <age>18</age>
    <gender>男</gender>
    <address>南京</address>
  </student>

  <student>
    <id>1004</id>
    <name>王五</name>
    <age>18</age>
    <gender>男</gender>
    <address>南京</address>
  </student>
</students>
```

- dtd的当前xml验证

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE students [
	<!ELEMENT students (student+)>
	<!ELEMENT student (id,name,age,gender,address)>
	<!ELEMENT id      (#PCDATA)>
	<!ELEMENT name    (#PCDATA)>
	<!ELEMENT age 	(#PCDATA)>
	<!ELEMENT gender    (#PCDATA)>
	<!ELEMENT address    (#PCDATA)>
]> 

<students>
	<student>
		<id>1001</id>
		<name>张三1</name>
		<age>18</age>
		<gender>男</gender>
		<address>南京</address>
	</student>
	
	<student>
		<id>1003</id>
		<name>李四</name>
		<age>18</age>
		<gender>男</gender>
		<address>南京</address>
	</student>
</students>
```

# 6、schema验证

- 什么是schema验证

```
XML Schema 是基于 XML 的 DTD 替代者。
XML Schema 描述 XML 文档的结构。
XML Schema 语言也称作 XML Schema 定义（XML Schema Definition，XSD）。
Schema文件的后缀名为xsd
XML Schema 比 DTD 更加强大
```

```
XML Schema 可针对未来的需求进行扩展 
XML Schema 更完善，功能更强大 
XML Schema 基于 XML 编写 

XML Schema 支持数据类型（只学习它）
XML Schema 支持命名空间 
```

- 创建一个stu.xsd文件

```

```

- 元素的常用类型

```
xs:string 
xs:decimal 
xs:integer 
xs:boolean 
xs:date 
xs:time 
```

- 元素的重现次数

```
<xs:element name="student" maxOccurs="unbounded" minOccurs="1">
```

- schema中的限定
- 限定的语法

```
<xs:element name="car">

<xs:simpleType>
  <xs:restriction base="xs:string">
    <xs:enumeration value="Audi"/>
    <xs:enumeration value="Golf"/>
    <xs:enumeration value="BMW"/>
  </xs:restriction>
</xs:simpleType>

</xs:element> 
```

```xml
<car>Audi/Golf/BMW</car>
```

- 对年龄的限定

```xml
<xs:element name="age">

<xs:simpleType>
  <xs:restriction base="xs:integer">
    <xs:minInclusive value="0"/>
    <xs:maxInclusive value="120"/>
  </xs:restriction>
</xs:simpleType>

</xs:element> 
```

- student.xsd

```xml
<?xml version="1.0" encoding="UTF-8"?>
<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema"
           targetNamespace="http://www.w3school.com.cn"
           xmlns="http://www.w3school.com.cn"
           elementFormDefault="qualified">

<xs:element name="students">
  <xs:complexType>
    <xs:sequence>
      <xs:element name="student" maxOccurs="unbounded" minOccurs="1">
        <xs:complexType>
          <xs:sequence>
            <xs:element name="id" type="xs:integer"/>
            <xs:element name="name" type="xs:string"/>

            <xs:element name="age">
              <xs:simpleType>
                <xs:restriction base="xs:integer">
                  <xs:minInclusive value="0"/>
                  <xs:maxInclusive value="120"/>
                </xs:restriction>
              </xs:simpleType>
            </xs:element> 

            <xs:element name="gender">
              <xs:simpleType>
                <xs:restriction base="xs:string">
                  <xs:pattern value="[男|女]"/>
                </xs:restriction>
              </xs:simpleType>
            </xs:element>

            <xs:element name="address" type="xs:string"/>
          </xs:sequence>
        </xs:complexType>
      </xs:element>
    </xs:sequence>
  </xs:complexType>
</xs:element>

</xs:schema>
```

```xml
<?xml version="1.0" encoding="UTF-8"?>
<students xmlns="http://www.w3school.com.cn" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.w3school.com.cn stu.xsd">

  <student>
    <id>1001</id>
    <name>张三</name>
    <age>18</age>
    <gender>男</gender>
    <address>南京</address>
  </student>
  <student>
    <id>1002</id>
    <name>李四</name>
    <age>18</age>
    <gender>女</gender>
    <address>南京</address>
  </student>
</students>

```

# 7、xml解析

- users.xml

```xml
<users>
  <user>
    <username>admin</username>
    <password>123456</username>
  </user>
  <user>
    <username>root</username>
    <password>1234</username>
  </user>
  <user>
    <username>tiger</username>
    <password>1234</username>
  </user>
</users>
```

- xml一般用来做配置文件

```
1、用java代码来解析xml配置文件，读取里面的配置项
2、一般配置文件放在java项目的src目录
```

- xml解析的方式

```
dom		jdk自带
sax		引入jar
jdom	引入jar
dom4j 	引入jar（dom for java）
```

- 只学习dom4j解析

```
dom4j-1.6.1.jar
jaxen-1.1-beta-7.jar
```

```java
package net.wanho.test;

import java.io.InputStream;
import java.util.List;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class XML_Test {

  public static void main(String[] args) throws Exception {
    SAXReader reader =new SAXReader();
    //1、把users.xml文件变为输入流
    //反射： XML_Test.class，反射的结果是一个对象（XML_Test字节码对象）
    //getClassLoader()，获取类加载器，就是bin目录对象；字节码被编译到bin目录
    //getResourceAsStream(filename),读取类加载器中的文件
    InputStream is = XML_Test.class.getClassLoader().getResourceAsStream("users.xml");
    //2、再把文件流读取成document对象
    Document document =	reader.read(is);
    System.out.println(document);

    //3、解析document中需要获取的数据
    //获取根元素
    Element element = document.getRootElement();
    //获取根元素名
    System.out.println(element.getName());
    //获取元素中的子元素们
    List<Element> users = element.elements();
    for (int i = 0; i < users.size(); i++) {
      Element user = users.get(i);
      System.out.println(user.getName());
      
      //获取user中的每一个属性
      List<Attribute> sttrs = user.attributes();

      //获取user中的每一个元素
      List<Element> eles =user.elements();
      for (int j = 0; j < eles.size(); j++) {
        Element ele = eles.get(j);
        System.out.println(ele.getName()+":"+ele.getText());
      }
    }
  }
}
```

~~~

