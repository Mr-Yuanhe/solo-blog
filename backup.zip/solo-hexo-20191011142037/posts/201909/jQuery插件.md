title: jQuery插件
date: '2019-09-24 17:52:13'
updated: '2019-09-24 17:57:01'
tags: [jQuery]
permalink: /articles/2019/09/24/1569318733397.html
---
# 1、校验插件

- validate [点击进入下载](http://package.yuanheweb.com)
	依次点击：HTML -> jQuery插件 -> validate.zip
- 校验表单的
- 需要引入第三方js文件

```
# 核心js
jquery.validate.js

# 汉化js
messages_zh.js
```

- 大部分插件都依赖jquery，需要在引入js之前，先引入jquery.js文件

```html
<script src="js/jquery-3.4.1.js"></script>
<!--validate的核心js文件-->
<script src="js/jquery.validate.js"></script>
<!--汉化的js文件-->
<script src="js/messages_zh.js"></script>
```

- 校验规则

```
required: "这是必填字段",
remote: "请修正此字段",
email: "请输入有效的电子邮件地址",
url: "请输入有效的网址",
date: "请输入有效的日期",
dateISO: "请输入有效的日期 (YYYY-MM-DD)",
number: "请输入有效的数字",
digits: "只能输入数字",
creditcard: "请输入有效的信用卡号码",
equalTo: "你的输入不相同",
extension: "请输入有效的后缀",
maxlength: $.validator.format( "最多可以输入 {0} 个字符" ),
minlength: $.validator.format( "最少要输入 {0} 个字符" ),
rangelength: $.validator.format( "请输入长度在 {0} 到 {1} 之间的字符串" ),
range: $.validator.format( "请输入范围在 {0} 到 {1} 之间的数值" ),
max: $.validator.format( "请输入不大于 {0} 的数值" ),
min: $.validator.format( "请输入不小于 {0} 的数值" )
```

- 表单与插件js整合的一个核心方法

```
$("form").validate();
```

- html的校验案例

```
把校验规则当做html的属性，去使用
```

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Title</title>

    <style>

      label{
        display: inline-block;
        width: 65px;
      }
      .error{
        display: inline;
        color: red;
      }
    </style>
  </head>
  <body>

    <form action="success.html" id="registerForm">
      <div>
        <label>用户名</label>
        <input type="text"  name="username" required maxlength="12" minlength="6">
      </div>
      <div>
        <label>密码</label>
        <input type="password"  name="password" required id="password">
      </div>
      <div>
        <label>确认密码</label>
        <input type="password"  name="rePassword" equalTo="#password">
      </div>

      <div>
        <label>爱好</label>
        <input type="checkbox"  name="hobby" value="eat">吃
        <input type="checkbox"  name="hobby" value="drink">喝
        <input type="checkbox"  name="hobby" value="sleep">睡
      </div>
      <div>
        <label>手机号码</label>
        <input type="text"  name="phone" >
      </div>
      <div>
        <input type="submit" value="注册">
      </div>
    </form>
    <script src="js/jquery-3.4.1.js"></script>
    <!--validate的核心js文件-->
    <script src="js/jquery.validate.js"></script>
    <!--汉化的js文件-->
    <script src="js/messages_zh.js"></script>
    <script>
      $(function () {
        $("#registerForm").validate();
      });
    </script>
  </body>
</html>
```

# 2、json

- json可分为json数组和json对象

```
json数组 就是 简写的js数组形式
json对象 就是 简写的js对象形式
```

- 注意点

```
# json，比js对象语法更加严格
1、属性必须加引号
2、最后一个属性后面不能添加逗号
```

```js
var student = {id:1001,name:"张三"};
```

```json
{
  "id":1001,
  "name":"张三"
}
```

- json文件

```
以.json为后缀名的文件就是json文件，json文件只能存放json数据
```

```
在json文件中，必须要遵循严格规范，js无所谓！
```

```js
var student = {id:1001,name:"张三"};

var stuJson = {
  "id":101,
  "name":"张三"
};

console.log(student);
console.log(stuJson);
```

# 3、校验插件中的js实现校验

- 从html校验的方法中，得到以下bug

```
# 校验台词太死板
# 不能给单选按钮和复选框等空间进行校验
# 不能够自定义校验规则（手机号码，邮编...）,正则
```

- 需要通过js中的扩展校验代码，完善我们的bug

```
需要手写（改）规则，通过validate(options);
```

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Title</title>

    <style>

      label{
        display: inline-block;
        width: 65px;
      }
      .error{
        display: inline;
        color: red;
      }
    </style>
  </head>
  <body>

    <form action="success.html" id="registerForm">
      <div>
        <label>用户名</label>
        <input type="text"  name="username" >
      </div>
      <div>
        <label>密码</label>
        <input type="password"  name="password" id="password">
      </div>
      <div>
        <label>确认密码</label>
        <input type="password"  name="rePassword" >
      </div>

      <div>
        <label>爱好</label>
        <input type="checkbox"  name="hobby" value="eat">吃
        <input type="checkbox"  name="hobby" value="drink">喝
        <input type="checkbox"  name="hobby" value="sleep">睡
      </div>
      <div>
        <label>手机号码</label>
        <input type="text"  name="phone" >
      </div>
      <div>
        <input type="submit" value="注册">
      </div>
    </form>

    <script src="js/jquery-3.4.1.js"></script>
    <!--validate的核心js文件-->
    <script src="js/jquery.validate.js"></script>
    <!--汉化的js文件-->
    <script src="js/messages_zh.js"></script>

    <script>
      $(function () {
        /*json形式的对象作为参数，定义validate插件的配置*/
        //json对象用来做js配置
        $("#registerForm").validate({
          //校验规则
          rules:{
            username:{
              required:true,
              minlength:6
            },
            password:{
              required:true
            },
            rePassword:{
              equalTo:"#password"
            },
            hobby:{
              required:true
            }
          },
          //消息提示
          messages:{
            username:{
              required:"用户名不能为空！",
              minlength:"用户名的长度不能小于6"
            },
            password:{
              required:"密码不能为空！"
            },
            rePassword:{
              equalTo:"重复密码要一致！"
            },
            hobby:{
              required:"至少选择一个爱好！"
            }
          },
          //this.settings.errorPlacement.call( this, place, $( element ) );
          //place.insertAfter( element );
          //element.after(place)

          //提示信息放在什么地方
          errorPlacement:function (error,element) {
            //error:表示提示信息的元素
            //element:校验的控件元素
            element.parent().append(error);
          }
        });
      });
    </script>
  </body>
</html>
```

- 一些像手机号码或者邮编等一些需要用到正则表达式校验的业务，这时候需要扩展校验

```
//添加一个新的校验方法（规则）
$.validator.addMethod(name,fn,message);
```

```js
//定义一个手机号码校验规则
$.validator.addMethod("phoneReg",function ( value, element ) {
  return this.optional( element ) || /^1[3|5|7|8|9]\d{9}$/.test( value );
},"请输入正确的手机号码！");
```

# 4、z-tree插件

- 树插件

- 官网 [点击进入](http://www.treejs.cn/v3/main.php#_zTreeInfo)
- z-tree [点击进入下载](http://package.yuanheweb.com)
	依次点击：HTML -> jQuery插件 -> z-tree.zip
- 核心js

```
jquery.ztree.all.js
```

- 需要添加核心css文件

```
zTreeStyle.css
```

```
由于核心css有背景图片样式，需要把相关的背景图片的文件夹与css文件放在同一级目录
```

- 也是一个jquery插件，依赖jquery

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="./css/zTreeStyle.css">
  </head>
  <body>
    <div>
      <ul class="ztree" id="tree">

      </ul>
    </div>
    <script src="js/jquery-3.4.1.js"></script>
    <script src="js/jquery.ztree.all.js"></script>

    <script>
      $(function () {

        //1、zTree 的参数配置，深入使用请参考 API 文档（setting 配置详解）
        var setting = {};

        //2、定义ztree中需要的数据
        var data = [];
        
        //3、核心的方法 init: function (obj, zSetting, zNodeDatas)
        $.fn.zTree.init($("#tree"),setting,data);
      });
    </script>
  </body>
</html>
```

- ztree中的数据结构

```
# 嵌套结构，普通使用，无必须设置配置
# 标准的 JSON 数据需要嵌套表示节点的父子包含关系

# 平行结构，简单实用，必须设置配置
# 所有对象在同一层次，通过对象中的属性关联父子关系
```

```json
[
  {
    name:"父节点1",
    children:[
      {name:"父节点11"},
      {name:"父节点12"},
      {name:"父节点13"}
	]
  },
  {
    name:"父节点2",
    children:[
      {name:"父节点21"},
      {name:"父节点22"},
      {name:"父节点23"}
	]
  },
  {
    name:"父节点3",
    children:[
      {name:"父节点31"},
      {name:"父节点32"},
	]
  }
]
```

```java
public class Room{
  int id;
  String name;
  List<Student> students; 
}
```

```
public class Student{
  int id;
  String name;
}
```

- 嵌套结构的案例

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="./css/zTreeStyle.css">
  </head>
  <body>

    <div>
      <ul class="ztree" id="tree">

      </ul>
    </div>

    <script src="js/jquery-3.4.1.js"></script>
    <script src="js/jquery.ztree.all.js"></script>

    <script>
      $(function () {

        //1、zTree 的参数配置，深入使用请参考 API 文档（setting 配置详解）
        var setting = {};


        //2、定义ztree中需要的数据
        var data = [
          {
            name:"父节点1",
            children:[
              {name:"父节点11"},
              {
                name:"父节点12",
                //是否是父节点
                isParent:true
              },
              {name:"父节点13"}
            ]
          },
          {
            name:"父节点2",
            children:[
              {name:"父节点21"},
              {name:"父节点22"},
              {name:"父节点23"}
            ],
            open:true
          },
          {
            name:"父节点3",
            children:[
              {name:"父节点31"},
              {name:"父节点32"},
            ]
              }
            ];

            //3、核心的方法 init: function (obj, zSetting, zNodeDatas)
            $.fn.zTree.init($("#tree"),setting,data);

          });
    </script>
  </body>
</html>
```

- 简单使用的数据

```
# 平行结构，简单使用，必须设置配置
# 所有对象在同一层次，通过对象中的属性,关联父子关系
```

```js
var data = [
  {id:1001,name:"父节点1",pId:0},
  {id:1002,name:"子节点11",pid:1001},
  {id:1003,name:"子节点12",pid:1001},
  {id:1004,name:"子节点13",pid:1001},
  {id:1005,name:"父节点2",pid:0},
  {id:1006,name:"子节点21",pid:1005},
  {id:1007,name:"子节点22",pid:1005},
  {id:1008,name:"子节点23",pid:1005},
  {id:1009,name:"父节点3",pid:0},
  {id:1010,name:"子节点31",pid:1009},
  {id:1011,name:"子节点32",pid:1009},
]
```

```js
var setting = {
  data: {
    simpleData: {
      enable: true,
      idKey: "id",
      pIdKey: "pId",
      rootPId: ""
    }
  }
};
```

- 案例

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="./css/zTreeStyle.css">
</head>
<body>

<div>
    <ul class="ztree" id="tree">

    </ul>
</div>

<script src="js/jquery-3.4.1.js"></script>
<script src="js/jquery.ztree.all.js"></script>

<script>
    $(function () {
        //1、zTree 的参数配置，深入使用请参考 API 文档（setting 配置详解）
        var setting = {
            data: {
                simpleData: {
                    enable: true,
                    idKey: "id",
                    pIdKey: "pId",
                    rootPId: "0"
                },
                key:{
                    name:"sName"
                }
            }
        };

        //2、定义ztree中需要的数据
        var data = [
            {id:1001,sName:"父节点1",pId:0},
            {id:1002,sName:"子节点11",pId:1001},
            {id:1003,sName:"子节点12",pId:1001},
            {id:1004,sName:"子节点13",pId:1001},
            {id:1005,sName:"父节点2",pId:0},
            {id:1006,sName:"子节点21",pId:1005},
            {id:1007,sName:"子节点22",pId:1005},
            {id:1008,sName:"子节点23",pId:1005},
            {id:1009,sName:"父节点3",pId:0},
            {id:1010,sName:"子节点31",pId:1009},
            {id:1011,sName:"子节点32",pId:1009},
        ];
        //3、核心的方法 init: function (obj, zSetting, zNodeDatas)
        $.fn.zTree.init($("#tree"),setting,data);
    });
</script>
</body>
</html>
```

# 5、layer插件

- layer插件介绍

```
layer是layui框架中的一个插件
layui框架是基于jquery开发的，所以layer也依赖jquery
layer是jquery弹出层插件
```

- 核心js

```
layer.js
```

- [点击进入下载](http://package.yuanheweb.com)
	依次点击：HTML -> jQuery插件 -> layer.zip
- layer也需要加入css文件

```
把theme文件夹放在js文件中
页面上不需要引入css文件
```

- 用layer实现警告框、确认框、输入框、...

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Title</title>
  </head>
  <body>
    <button>警告框</button>
    <button>确认框</button>
    <button>输入框</button>
    <script src="js/jquery-3.4.1.js"></script>
    <script src="js/layer.js"></script>

    <script>
      $(function () {
        $("button:eq(0)").click(function () {
          //警告框
          layer.alert("该用户不能够被删除！",{icon:0});
        });

        $("button:eq(1)").click(function () {
          //确认框,返回就是弹出层的唯一指定标记（1,2,3,4,5...)
          var index = layer.confirm("确定删除该用户吗？",{icon:3},function () {
            //执行确定操作
            console.log("确定");
            //关闭弹出层
            layer.close(index);
          },function () {
            //执行取消操作
            console.log("取消");
          });
        });

        $("button:eq(2)").click(function () {
          //输入框
          layer.prompt({title:"请输入一个合法的字母"},function (value,index) {
            //value就是输入的值
            console.log(value);
            //index是弹出层的唯一指定标记
            //关闭弹出层
            layer.close(index);
          });
        });
      });
    </script>
  </body>
</html>
```












