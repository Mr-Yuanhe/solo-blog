title: 华为 HCIA-Big Data 判断题
date: '2019-10-31 10:42:27'
updated: '2019-11-01 08:44:30'
tags: [HCIA-BigData]
permalink: /articles/2019/10/31/1572489747535.html
---
#### 1.Flume 的数据流可以根据 headers 的信息发送到不同的 channel 中。A

```
A. 正确
B. 错误
```

#### 2.Spark 任务的每个 stage 可划分为 job ，划分的标记是 shuffle 。B 

```
A. 正确
B. 错误
```

#### 14.FusionInsighr HD 部署 Solr 时，如果选择索引存放在本地磁盘，建议给每个 SoIrServer 实 例的数据目录单独挂载磁盘，并且磁盘配置为 RAID0 或 RAID5 。A

```
A. 对
B. 错
```

#### 4. 安装 FusionInsight HD 软件包前，必须在本节点 /etc/hosts 文件中配置集群中所有节点的主机名称与业务 IP 的映射关系。A 

```
A. 正确
B. 错误
```

#### 5.如果 YARN 集群中只有 Default 、 QueueA 和 QueueB 子队列，那么允许将他们的容 量分别设置为 60% 、 25% 和 22% 。B

```
A. 正确 
B. 错误
```

#### 6.FusionInsight Manager 支持大规模集群的安装部署、监控、告警、用户管理、权限管理、 审计、服务管理、健康检查、问题定位、升级和补丁。A

```
A. 正确
B. 错误
```

#### 7.Kafka 是一个分布式的消息发布订阅系统，它只是进行消息的转发，并不会保存消息。B 

```
A. 正确
B. 错误
```

#### 8.FusionInsight HD 的 Streaming 是基于开源 Apache Storm 开发的， Storm 是一个分布式 的离线计算框架。B

```
A. 正确
B. 错误
```

#### 9.FusionInsight HD 系统中一个集群可以管理多个服务，每个服务可以管理多个角色，每个 角色只能管理一个实例。B

```
A. 正确
B. 错误
```

#### 10.如果 FusionInsight HD 集群节点数不足以使数据节点单独部署的情况下，可以采用管理 节点 & 控制节点 & 数据节点合一部署方案，但性能会受限制。A

```
A. 正确
B. 错误
```

#### 11.Hadoop 的 NameNode 用于存储文件系统的元数据。A

```
A. 正确
B. 错误
```

#### 12.FusionInsight 集群组网设计中，二层组网指集群内二层交换，集群节点在一个子网里， 适用节点数小于 200 的集群场景。A

```
A. 正确
B. 错误
```

#### 13.FusionInsight HD 中 Loader 作业提交到 Yarn 后，作业不能手工停止。B

```
A. 正确
B. 错误
```

#### 14.Spark on YARN 模式下的 driver 只能运行在客户端。B

``` 
A. 正确
B. 错误
```

#### 15.FusionInsight HD 集群中的节点只安装了一块网卡，也可以采用双平面隔离组网方案。B

```
A. 正确
B. 错误
```

#### 16.Hadoop 系统中，如果文件系统的备份因子是 3 ，那么每次 MapReduce 任务运行的 task 所需要的文件都要从 3 个有副本的机器上传输需要处理的文件。B

```
A. 正确
B. 错误
```

#### 17.YARN 上有两个同级队列 Q1 与 Q2 ，容量都是 50 ， Q1 上已经有 10 个任务共占用 了 40 的容量， Q2 上有 2 个任务共占用了 30 的容量，那么由于 Q1 的任务数多，调度 器会优先将资源分配给 Q1 。B

```
A. 正确
B. 错误
```

#### 18.HDFS 的 Client 写入文件时，数据的第一副本写入位置是由 NameNode 确定，其他副本 的写入位置由 DataNode 确定。B

```
A. 正确
B. 错误
```

#### 19.RDD 可以从 Hadoop 兼容的文件系统生成，生成之后可以通过调用 RDD 的算子对 RDD 的数据进行部分更新。A

```
A. 正确
B. 错误
```

#### 20.HDFS 支持大文件存储，同时支持多个用户对同一个文件的写操作，以及在文件任意位置 进行修改。B

```
A. 正确
B. 错误
```

#### 21.FusionInsight HD 用户管理系统仅支持管理人机账号。B

``` 
A. 正确
B. 错误
```

#### 22.Flume 的 properties 配置文件中可以配置多个 channel 来传输数据。A

```
A. 正确
B. 错误
```

#### 23.FusionInsight HD 部署过程中，执行 precheck 检查每一个节点时必须调用 checkNodes.Configd 配置文件。A

```
A. 正确
B. 错误
```

#### 24.Spark 是基于内存的计算，所有 Spark 程序运行过程中的数据只能存储在内存中。B

```
A. 正确
B. 错误
```

#### 25.FusionInsight HD 系统中 HBase 支持动态扩展列。A

```
A. 正确
B. 错误
```

#### 26.FusionInsight HD 的 Streaming 对于 Zookeeper 弱依赖，即使 Zookeeper 故障 Streaming 也可以正常提供服务。B

```
A. 正确
B. 错误
```

#### 27.Loader 的作业执行失败，则此作业运行过程中导入的数据不会被删除，必须手动删除。 B

```
A. 正确
B. 错误
```

#### 28.FusionInsight HD 系统中，在创建 Kafka 的 Topic 时必须设置 Partition 个数和副本个数， 设置多副本可以增强 Kafka 服务的容灾能力。A

```
A. 正确
B. 错误
```

#### 29.Loader 仅支持关系型数据库与 Hadoop HBase 之间的数据导入和导出。B

```
A. 正确
B. 错误
```

#### 30.FusionInsight HD 中使用 HBase 进行数据读写服务时需要连接 HMaster 。B

```
A. 正确
B. 错误
```

#### 31.Solr 创建 Collection 时，推荐选用路由算法为 compositId Router ，那么该 Collection 可 以扩展 shard 。B

```
A. 正确
B. 错误
```


#### 32.华为 FusionInsight HD 系统中，对存储副本为 3 个的数据块，当有一个节点上该数据 块丢失时，需要手动复制一个副本到该节点。B

```
A. 正确
B. 错误
```

#### 33.Spark 应用运行时，如果某个 task 运行失败则导致整个 app 运行失败。B

```
A. 正确
B. 错误
```


#### 34.Flume 传输数据过程中， Sink 取走数据并写入目的地后，会将 event 从 channel 中删 除。A

```
A. 正确
B. 错误
```


#### 35.HDFS 机制中 NameNode 负责管理元数据， Client 端每次读请求都需要从 NameNode 的元数据磁盘中读取元数据信息以此获取所读文件在 DataNode 的位置。B

```
A. 正确
B. 错误
```


#### 36.FusionInsight HD 扩容时，添加到集群中的新节点，主机 OS 的 root 用户密码与集群原 所有节点 root 用户密码可以不用保持一致。B

```
A. 正确
B. 错误
```


#### 37.Kerberos 协议中 TGT 主要用于应用侧与需要访问的服务之间的安全会话。B 

```
A. 正确
B. 错误
```


#### 38.FusionInsight HD 集群三层组网时，管理节点、控制节点、数据节点建议安装在不同网段内，可以提高可靠性。B 

```
A. 正确
B. 错误
```


#### 39.FusionInsight HD 系统中，集群中其中一个 Loader 节点异常，其他服务没有异常的情况 下，不会影响 Loader 服务功能的正常使用。A

```
A. 正确
B. 错误
```


#### 40.Spark on YARN 模式下，没有 NodeManager 的节点不能启动 executor 执行 task 。A 

```
A. 正确
B. 错误
```


#### 41.Kerberos 系统设计上采用客户端 / 服务器结构与 DES 加密技术，能够进行相互认证，客户端和服务器端均可对对方进行身份认证。A

```
A. 正确
B. 错误
```

#### 42.YARN 上有两个同级队列 Q1 与 Q2 ，容量都是 50 ， Q1 上已经有 10 个任务共占用 了 40 的容量， Q2 上有 2 个任务共占用了 30 的容量，那么由于 Q1 的任务数多，调度 器会优先将资源分配给 Q1 。B

```
A. 正确
B. 错误
```

#### 43.Kerberos 只能对集群内的服务提供安全认证。B 

```
A. 正确
B. 错误
```

#### 44.Solr 可以对结构化、半结构化、非结构化数据建立索引，并提供全文检索的能力。A

```
A. 正确
B. 错误
```

#### 45.Spark 和 Hadoop 都不适用于迭代计算的场景。B 

```
A. 正确
B. 错误
```

#### 46.FusionInsight HD 管理节点提供双机 HA 机制，主节点故障之后，主备节点需要手动实 现 Failover 。B

```
A. 正确
B. 错误
```

#### 47.Spark 任务的 Executor 可以运行多个 task 。A

```
A. 正确
B. 错误
```

#### 48.使用配置规划工具对 FusionInsight HD V100R002C50 集群进行规划时，可以用 V100R002C60 版本的配置规划工具来规划。B

```
A. 正确
B. 错误
```

#### 49.FusionInsight HD 集群安装成功后，不允许修改服务、角色和实例的配置。B 

```
A. 正确
B. 错误
```

#### 50.大数据需要传统行业思维方式的转变，要把数据收集、分析作为业务流程的重要组成 部分，数据驱动业务流程优化，实现智能化和自动化，并依托数据资产实现跨界拓展。A

```
A. 正确
B. 错误
```

#### 51.FusionInsight HD 系统中，可以通过多个 Flume 连接从其部署的节点上采集数据。A 

```
A. 正确
B. 错误
```

#### 52.FusionInsight HD 安装不支持非 root 用户的安装方式。B 

```
A. 正确
B. 错误
```

#### 53.FusionInsight HD 的 Loader 中，一个连接器( Connector )只可以分配给一个作业使 用。B

```
A. 正确
B. 错误
```

#### 54.FusionInsight Manager 对外支持 REST 接口、 SNMP 接口、 SYSLOG 接口。A 

```
A. 正确
B. 错误
```


#### 55.FusionInsight HD Loader 进行数据导入和导出，必须经过 Reduce 阶段进行数据处理。B

```
A. 正确
B. 错误 
```

#### 56.Spark SQL 运行过程中，如果采取了 shuffle，会带来性能上的下降。B

```
A. 正确 
B. 错误

解析:因为 Spark SQL 的 DataFrame 自带 scheme 信息，进行了优化


```

#### 57.Flink 只能部署在 Local 和 Cluster，暂不支持其他部署。B

```
A. 正确 
B. 错误
解析:Flink 能部署 Local，Cluster，Cloud 上
```

#### 58.Flink中的checkpoint机制不断绘制流应用的快照，流应用的状态快照只能保存在HDFS 文件系统。错误。

```
A. 正确 
B. 错误
```

#### 59.Flink 适用于高并发处理数据、毫秒级时延的应用。 正确

```
A. 正确 
B. 错误
```

#### 60.zookeeper 的节点使用 ACL 控制访问策略，ACL 可应用于集群中的任意中任一 znode 节点 上。错误

```
A. 正确 
B. 错误
```

#### 61.FusionInsight HD 平台中，HBase 暂不支持二级索引。正确

```
A. 正确 
B. 错误
```

#### 62.Hadoop 系统中 YARN 分配给 Container 的内存大小，可以通过参数 yarn.app.mapreduce.am.resource.mb 来设置。B

```
A. 正确 
B. 错误
```

#### 63.F1ink 程序的两个关键要素是 stream 数据和 transformation 算子。A

```
A. 正确 
B. 错误
```

#### 64.Flink 与 Spark Streaming 类似，属于时间驱动型实时流系统。A

```
A. 正确 
B. 错误
```

#### 65.在 ZooKeeper 的服务模型中，Leader 节点以主备模式存在，其他节点都属于 Follower 节 点。B

```
A. 正确 
B. 错误
```

#### 66.FusionInsight Manager 支持多租户统一管理。A

```
A. 正确 
B. 错误
```

#### 67.Spark SOL 表中，经常会存在很多小文件(大小远小于 DFS 块大小)，在这种情况下，Spark 会启动更多的 Task 来处理这些小文件，当 SQL 逻辑中存在 Shuffle 操作时，会大大增加 hash 分桶数，从而严重影响性能。A

```
A. 正确 
B. 错误
```

#### 68.Spark on YARN 模式下，没有部署 NodeManager 的节点不能启动 executor 执行 task。A 

```
A. 正确 
B. 错误

```

#### 69.zookeeper 所有节点都可以处理读请求。正确

```
A. 正确 
B. 错误
```
#### 70.FusionInsight HD 系统中， Kerberos 仅用于组件间服务安全认证。B

```
A. 正确
B. 错误
```

#### 71.FusionInsight Manager 界面上，当收到 Kafka 盘容量不足告警，且该告警的原因已经排 除硬盘硬件故障时，系统管理员需要考虑扩容解决此问题。A

```
A. 正确
B. 错误
```
